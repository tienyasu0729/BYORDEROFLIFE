import React, { useEffect, useState } from 'react';
import TopBar from './../TopBar/TopBar';
import { Link, useNavigate } from 'react-router-dom';
import { Dropdown } from 'react-bootstrap';
import { f_getAllCategory_api, f_getCartItem_api, f_getWishlistItem_api } from '../../config/api';
import { toast } from 'react-toastify';

const Navbar = () => {
    const token = localStorage.getItem('token');
    const [listCategories, setCategories] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const navigate = useNavigate();
    const [cartItem, setCartItem] = useState([]);
    const [wishlistItem, setWishlistItem] = useState([]);

    const handleCartClick = () => {
        if (!token) {
            navigate("/login", { replace: true });
        } else {
            navigate("/cart");
        }
    };

    const handleWishlistClick = () => {
        if (!token) {
            navigate("/login", { replace: true });
        } else {
            navigate("/wishlist");
        }
    };

    const totalItemsCart = cartItem.length;
    const totalItemsWishlist = wishlistItem.length;

    const getCartItem = async () => {
        setIsLoading(true);
        try {
            const res = await f_getCartItem_api();
            if (res.data.status === 'success') {
                setCartItem(res.data.result);
            }
        } catch (error) {
            // toast.error('Failed to fetch cart items');
        } finally {
            setIsLoading(false);
        }
    };

    const getWishlistItems = async () => {
        setIsLoading(true);
        try {
            const res = await f_getWishlistItem_api();
            if (res.data.status === 'success') {
                setWishlistItem(res.data.result);
            }
        } catch (error) {
            // toast.error('Failed to fetch wishlist items');
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        getCartItem();
        getWishlistItems();
    }, []);

    const getListCategories = async () => {
        setIsLoading(true);
        try {
            const res = await f_getAllCategory_api();
            if (res.data.status === 'not found') {
                toast.warning(res.data.message);
            } else if (res.data.status === 'success') {
                setCategories(res.data.result);
            }
        } catch (error) {
            toast.error(error.message);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        getListCategories();
    }, []);

    return (
        <>
            <TopBar />
            <div className="row px-xl-5" style={{ backgroundColor: "#0d0d0d", paddingBottom: "10px" }}>
                <div className="col-lg-3 d-none d-lg-block">
                    <Dropdown>
                        <Dropdown.Toggle id="dropdown-basic" className="btn d-flex align-items-center justify-content-between bg-primary w-100"
                            style={{ height: "65px", padding: "0 30px", transition: "ease-out 0.7s", backgroundColor: "#0d0d0d" }}>
                            <h6 className="text-dark m-0"><i className="fa fa-bars mr-2"></i>Categories</h6>
                        </Dropdown.Toggle>

                        <Dropdown.Menu className='collapse position-absolute navbar navbar-vertical navbar-light align-items-start p-0 bg-light'
                            style={{ width: "calc(100%)", zIndex: "999" }}>
                            {listCategories && listCategories.map((category) => (
                                <ul className='navbar-nav w-100' key={category.id}>
                                    <Dropdown.Item href="#/action-1" className="nav-item nav-link w-100">{category.nameCategory}</Dropdown.Item>
                                </ul>
                            ))}
                        </Dropdown.Menu>
                    </Dropdown>
                </div>
                <div className="col-lg-9">
                    <nav className="navbar navbar-expand-lg navbar-dark py-3 py-lg-0 px-0">
                        <Link to="" className="text-decoration-none d-block d-lg-none">
                            <span className="h1 text-uppercase text-dark bg-light px-2">Electronics</span>
                            <span className="h1 text-uppercase text-light bg-primary px-2 ml-n1">Store</span>
                        </Link>
                        <button type="button" className="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse align-items-center flex-row justify-content-between" style={{ backgroundColor: "#0d0d0d" }} id="navbarCollapse">
                            <div className="navbar-nav mr-auto py-0">
                                <Link to="/" className="nav-item nav-link">Home</Link>
                                <Link to="/list-product" className="nav-item nav-link">Product</Link>
                                <Link to="/contact" className="nav-item nav-link">Contact</Link>
                            </div>
                            <div className="navbar-nav ml-auto py-0 d-none d-lg-block" onClick={handleWishlistClick}>
                                <Link to="/wishlist" className="btn px-0 ml-3">
                                    <i className="fa-solid fa-heart" style={{ color: "#FFD333", fontSize: "28px" }}></i>
                                    <span className="badge text-secondary border border-secondary rounded-circle" style={{ paddingBottom: "2px" }}>{totalItemsWishlist}</span>
                                </Link>
                            </div>
                            <div className="d-flex align-items-center">
                                <div className="navbar-nav ml-auto py-0 d-none d-lg-block" onClick={handleCartClick}>
                                    <Link to="/cart" className="btn px-0 ml-3" style={{ marginRight: "10px" }}>
                                        <i className="fas fa-shopping-cart text-primary" style={{ fontSize: "28px" }}></i>
                                        <span className="badge text-secondary border border-secondary rounded-circle" style={{ paddingBottom: "2px" }}>{totalItemsCart}</span>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </>
    );
};

export default Navbar;
