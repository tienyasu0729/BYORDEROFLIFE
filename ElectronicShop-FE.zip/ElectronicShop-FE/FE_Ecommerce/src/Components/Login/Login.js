import React, { useEffect, useState } from 'react';
import './login.css';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import wave from '../../assets/IMG/wave.png';
import bg from '../../assets/IMG/bg.svg';
import logo from '../../assets/IMG/LOGO.png';
import { toast } from 'react-toastify';
import { f_login_api } from '../../config/api';
import axios from "../../config/customAxios"
import { GoogleLogin } from 'react-google-login';
import FacebookLogin from 'react-facebook-login';
import { gapi } from 'gapi-script';
import ForgotPassword from "../../View/pass/ForgotPassword";

function Login() {
  const [focusedInput, setFocusedInput] = useState(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isShowPassword, setIsShowPassword] = useState(false);
  const [loadingApi, setLoadingApi] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  const navigate = useNavigate();
  const  clientId= "333632614563-afkr3g3h5h43bb0hrf6ou5ojs9rabes0.apps.googleusercontent.com"
  const loginContext = (email, token, name, authority, phone, dob, avatar, gender, address) => {
    localStorage.setItem('token', token);
    localStorage.setItem(
      'current-account',
      JSON.stringify({
        email: email,
        name: name,
        authority: authority,
        tel: phone,
        dob: dob,
        avatar: avatar,
        gender: gender,
        address: address,
      })
    );
  };

  const handleFocus = (inputName) => {
    setFocusedInput(inputName);
  };

  const handleBlur = () => {
    setFocusedInput(null);
  };

  const handleLogin = async () => {
    if (!username || !password) {
      toast.warning("Please enter a username and password")
      return;
    }
    setLoadingApi(true)
    try {
      const res = await f_login_api(username, password)
      if (res.data.status === "error") {
        toast.error(res.data.message)
      } else if (res.data.status === "success") {
        const token = res.data.result.token;
        axios.defaults.headers['Authorization'] = `Bearer ${token}`;
        loginContext(res.data.result.account.email, token, res.data.result.account.name, res.data.result.account.authority, res.data.result.account.tel, res.data.result.account.dob, res.data.result.account.avatar, res.data.result.account.gender, res.data.result.account.address);
        toast.success(res.data.message)
        navigate('/admin-page')
      } else if (res.data.status === "not found") {
        toast.warning(res.data.message)
      }
    } catch (error) {
      toast.error(error.message)
    }
    finally {
      setLoadingApi(false);
      setUsername('');
      setPassword('');
    }
  }
  const handleForgotPassword = () => {
    navigate('/');
  };
  const responseGoogle = async (response) => {
    if (response.profileObj && response.tokenObj) {
      const { email, name, imageUrl } = response.profileObj;
      const token = response.tokenId;
      

      try {
        // Send user data to backend
        const res = await axios.post("account/social-login", { 
          email, 
          name, 
          imageUrl, 
          loginType: 'GOOGLE',
          token: token
        });

        if (res.data.status === 'success') {
          axios.defaults.headers['Authorization'] = `Bearer ${res.data.result.token}`;
          loginContext(email, res.data.result.token, name, res.data.result.account.authority);
          toast.success("Google login successful!");
          navigate('/account');
        } else {
          toast.error(res.data.message || "Login failed");
        }
      } catch (error) {
        console.error("Error during Google login:", error);
        toast.error("An error occurred during login");
      }
    } else {
      const errorMessage = response.error || "Google login failed";
      console.error("Google login failed:", errorMessage);
      toast.error(errorMessage);
    }
  };
  const responseFacebook = async (response) => {
    if (response.status !== 'unknown') {
      const { email, name, picture } = response;
      const token = response.accessToken;
      try {
        // Send user data to backend
        const res = await axios.post('/account/social-login', { 
          email, 
          name, 
          imageUrl: picture.data.url, 
          loginType: 'FACEBOOK' 
        });

        if (res.data.status === 'success') {
          axios.defaults.headers['Authorization'] = `Bearer ${res.data.result.token}`;
          loginContext(email, res.data.result.token, name, res.data.result.account.authority);
          toast.success("Facebook login successful!");
          navigate('/account');
        } else {
          toast.error(res.data.message || "Login failed");
        }
      } catch (error) {
        console.error("Error during Facebook login:", error);
        toast.error("An error occurred during login");
      }
    } else {
      console.log("Facebook login failed");
      toast.error("Facebook login failed");
    }
  };

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      navigate('/');
    }
  }, [navigate]);

  useEffect(() => {
    document.body.style.backgroundColor = "#f0f0f0"; 
    return () => {
      document.body.style.backgroundColor = "";
    };
  }, []);

  return (
    <div className="container-login" /* style={{backgroundColor:"#fff"}} */>
      <img className="wave" src={wave} alt="Wave" />
      <div className="img">
        <img src={bg} alt="Background" />
      </div>
      <div className="login-content">
        <div className="login-form">
          <form>
            <NavLink className="nav-link text-center link-login fadeInUp" to="/">
              <img className="logo-config" src={logo} alt="Avatar" />
            </NavLink>
            <h2 className="title fadeInUp">Welcome</h2>
            <div
              className={`input-div fadeInUp one ${focusedInput === 'username' || username ? 'focus' : ''}`}
              onClick={() => handleFocus('username')}
            >
              <div className="i">
                <i className="fas fa-user"></i>
              </div>
              <div className="div">
                <h5 >Username</h5>
                <input
                  type="text"
                  className="input"
                  onFocus={() => handleFocus('username')}
                  onBlur={handleBlur}
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
            </div>
            <div
              className={`input-div fadeInUp pass ${focusedInput === 'password' || password ? 'focus' : ''}`}
              onClick={() => handleFocus('password')}
            >
              <div className="i">
                <i className={isShowPassword === true ? 'fa-solid fa-lock-open' : 'fa-solid fa-lock'} onClick={() => setIsShowPassword(!isShowPassword)}></i>
              </div>
              <div className="div">
                <h5>Password</h5>
                <input
                  type={isShowPassword === true ? 'text' : 'password'}
                  className="input"
                  onFocus={() => handleFocus('password')}
                  onBlur={handleBlur}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>
            <div className="d-flex justify-content-end fadeInUp">
            <button type="button" className="forgot-password-btn" onClick={(e) => {e.preventDefault(); setShowForgotPassword(true);}}>Forgot Password?</button>
              <ForgotPassword
                show={showForgotPassword}
                handleClose={() => setShowForgotPassword(false)}
              />
            </div>

            <button type="button" className="btn-login fadeInUp" onClick={() => handleLogin()}>
              Login &nbsp;
              {loadingApi ? (
                <i className="fa-solid fa-spinner fa-spin-pulse fa-spin-reverse"></i>
              ) : (
                <i className="fa-solid fa-right-to-bracket"></i>
              )}
            </button>
            <div className="d-flex justify-content-start fadeInUp">
              <NavLink className="text-decoration-none link-login" to='/register'>
                <span style={{ color: 'red' }}>Don't have an account?</span> Register
              </NavLink>
            </div>
            <div className='d-flex justify-content-between mt-2 gg-fb '>
              <div>
                <GoogleLogin
                  clientId= {clientId}
                  buttonText="Log in with Google"
                  onSuccess={responseGoogle}
                  cssClassName="btn-login-gg fadeInUp"
                  onFailure={responseGoogle}
                  cookiePolicy={'single_host_origin'}
                  
                />
              </div>
              <div>
                  <FacebookLogin
            appId="504677565549759"
            autoLoad={false}
            fields="name,email,picture"
            callback={responseFacebook}
            cssClass="btn-login-fb fadeInUp"
            textButton="Log in with Facebook"
            redirectUri="http://localhost:3000/auth/facebook/callback" 
          />

              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
