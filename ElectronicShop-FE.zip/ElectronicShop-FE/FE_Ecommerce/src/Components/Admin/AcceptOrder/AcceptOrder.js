import React, { useEffect, useState } from 'react';
import Sidebar from './../SideBar/SideBar';
import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tooltip, IconButton, TextField } from '@mui/material';
import { f_updateStatus_api, f_getAllOrderAdmin_api, f_getAllOrderdetaillByOrderID_api } from '../../../config/api';
import { toast } from 'react-toastify';
import { formatCurrency, formatDateTime } from '../../../Validate/Validate';
import Pagination from 'react-paginate';
import { Button, Modal } from 'react-bootstrap';
import { FaEdit, FaTrash, FaEye, FaTruck, FaCheck, FaShippingFast, FaBoxOpen, FaBan } from 'react-icons/fa';
import './AcceptOrder.css'; // Đảm bảo bạn đã nhập tệp CSS vào

const AcceptOrder = () => {
    const [orderStatus, setOrderStatus] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isOpen, setIsOpen] = useState(false);
    const [selectedID, setSelectedID] = useState(null);
    const [page, setPage] = useState(0);
    const [statusUpdate, setStatusUpdate] = useState({ status: '' });
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredOrders, setFilteredOrders] = useState([]);
    const [orderDetails, setOrderDetails] = useState([]);
    const [isDetailOpen, setIsDetailOpen] = useState(false);

    const itemsPerPage = 8;

    const getAllCart = async () => {
        setIsLoading(true);
        try {
            const res = await f_getAllOrderAdmin_api();
            if (res.data.status === 'not found') {
                toast.warning(res.data.message);
            } else if (res.data.status === 'success') {
                const sortedOrders = res.data.result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
                setOrderStatus(sortedOrders);
                setFilteredOrders(sortedOrders);
                setPage(0);
            } else {
                toast.error(res.data.message);
            }
        } catch (error) {
            toast.error(error.message);
        } finally {
            setIsLoading(false);
        }
    };

    const getOrderDetails = async (id) => {
        console.log(`Fetching details for order ID: ${id}`);
        setIsLoading(true);
        try {
            const res = await f_getAllOrderdetaillByOrderID_api(id);
            if (res.data.status === 'success') {
                setOrderDetails(res.data.result);
                setIsDetailOpen(true);
            } else {
                toast.error(res.data.message);
                console.error(`Error fetching order details for ID ${id}: ${res.data.message}`);
            }
        } catch (error) {
            toast.error(`Error fetching order details: ${error.message}`);
            console.error(`Error fetching order details for ID ${id}:`, error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        getAllCart();
    }, []);

    useEffect(() => {
        const lowercasedQuery = searchQuery.toLowerCase();
        const filtered = orderStatus.filter(order =>
            order.nameOrder.toLowerCase().includes(lowercasedQuery) ||
            order.address.toLowerCase().includes(lowercasedQuery) ||
            order.paymentMethod.toLowerCase().includes(lowercasedQuery) ||
            order.note.toLowerCase().includes(lowercasedQuery) ||
            order.status.toLowerCase().includes(lowercasedQuery)
        );
        setFilteredOrders(filtered);
    }, [searchQuery, orderStatus]);

    const handleOpen = (id) => {
        setSelectedID(id);
        setIsOpen(true);
    };

    const handCancel = () => {
        setIsOpen(false);
        setStatusUpdate({ status: '' });
    };

    const handleConfirmUpdate = async () => {
        setIsLoading(true);
        try {
            const res = await f_updateStatus_api(selectedID, statusUpdate.status);
            if (res.data.status === 'not found') {
                toast.warning(res.data.message);
            } else if (res.data.status === 'success') {
                toast.success(res.data.message);
                getAllCart();
            }
        } catch (error) {
            toast.error(error.message);
        } finally {
            setIsLoading(false);
            handCancel();
        }
    };

    const makeStyle = (status) => {
        if (status === 'Processing') {
            return { background: '#FFFF00', color: 'black' };
        } else if (status === 'Confirmed') {
            return { background: '#7CFC00', color: 'black' };
        } else if (status === 'Shipping') {
            return { background: '#00BFFF', color: 'black' };
        } else if (status === 'Delivered') {
            return { background: '#C0C0C0', color: 'black' };
        } else {
            return { background: '#FF0000', color: 'white' };
        }
    };

    const renderStatusIcon = (status) => {
        if (status === 'Processing') {
            return <FaBoxOpen />;
        } else if (status === 'Confirmed') {
            return <FaCheck />;
        } else if (status === 'Shipping') {
            return <FaShippingFast />;
        } else if (status === 'Delivered') {
            return <FaTruck />;
        } else {
            return <FaBan />;
        }
    };

    const handlePageClick = (event) => {
        const newPage = event.selected;
        setPage(newPage);
    };

    const offset = page * itemsPerPage;
    const pageData = filteredOrders.slice(offset, offset + itemsPerPage);

    return (
        <div className='admin'>
            <div className='adminGlass' style={{ minHeight: "100vh" }}>
                <Sidebar />
                <div className='py-5' style={{paddingLeft:"205px", width:"100vw"}}>
                                        <h3 className='text-center py-3'>Accept Order</h3>
                    <div className="search-container text-center mb-4">
                        <TextField
                            label="Search Orders"
                            variant="outlined"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            style={{ width: '50%' }}
                        />
                    </div>
                    <TableContainer
                component={Paper}
                style={{
                  boxShadow: "0px 13px 20px 0px #80808029",
                  borderRadius: "20px",
                  width: "98%",
                  backgroundColor: "#F0FFF0",
                }}
            >                        <Table sx={{ minWidth: 650 }} aria-label="simple table">
                            <TableHead>
                            <TableRow style={{backgroundColor:"#ff9200"}}>
                                    <TableCell align="left">No.</TableCell>
                                    <TableCell align="left">Order Code</TableCell>
                                    <TableCell align="left">Address</TableCell>
                                    <TableCell align="left">Note</TableCell>
                                    <TableCell align="left">Payment Method</TableCell>
                                    <TableCell align="left">Subtotal</TableCell>
                                    <TableCell align="left">Date Time</TableCell>
                                    <TableCell align="left">Total Quantity</TableCell>
                                    <TableCell align="left">Status</TableCell>
                                    <TableCell align="left">Action</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody style={{ color: "white" }}>
                                {isLoading ? (
                                    <TableRow className="d-flex justify-content-center">
                                        <TableCell colSpan={10} align="center">
                                            <div className="custom-loader"></div>
                                        </TableCell>
                                    </TableRow>
                                ) : pageData.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={10} align="center">No data</TableCell>
                                    </TableRow>
                                ) : (
                                    pageData.map((row, index) => (
                                        <TableRow key={row.id} sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                            <TableCell scope="row" style={{verticalAlign: "middle", paddingLeft:"25px"}}>
                                                {index + 1 + offset}
                                            </TableCell>
                                            <TableCell align="left">{row.nameOrder}</TableCell>
                                            <TableCell align="left">{row.address}</TableCell>
                                            <TableCell align="left">{row.note}</TableCell>
                                            <TableCell align="left">{row.paymentMethod}</TableCell>
                                            <TableCell align="left">{formatCurrency(row.subtotal)}</TableCell>
                                            <TableCell align="left">{formatDateTime(row.createdAt)}</TableCell>
                                            <TableCell align="left">{row.totalQuantity}</TableCell>
                                            <TableCell align="left">
                                                <span className="status" style={makeStyle(row.status)}>
                                                    {renderStatusIcon(row.status)} {row.status}
                                                </span>
                                            </TableCell>
                                            <TableCell align="left" className="Details">
                                                <div className='d-flex'>
                                                    <Tooltip title="Update">
                                                        <IconButton color="primary" onClick={() => handleOpen(row.id)}>
                                                            <FaEdit />
                                                        </IconButton>
                                                    </Tooltip>
                                                    {/* <Tooltip title="Delete">
                                                        <IconButton color="secondary">
                                                            <FaTrash />
                                                        </IconButton>
                                                    </Tooltip> */}
                                                    <Tooltip title="View Details">
                                                        <IconButton color="default" onClick={() => getOrderDetails(row.id)}>
                                                            <FaEye />
                                                        </IconButton>
                                                    </Tooltip>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                            {isOpen && (
                                <Modal show={isOpen} onHide={handCancel}>
                                    <Modal.Header closeButton>
                                        <Modal.Title>Update Order Status</Modal.Title>
                                    </Modal.Header>
                                    <div className="inputGroup1 py-3 col-md-12 d-flex flex-column">
                                        <label>Status<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                                        <select
                                            id="status"
                                            value={statusUpdate.status}
                                            onChange={(e) => setStatusUpdate({ status: e.target.value })}
                                            className="form-control"
                                        >
                                            <option value="Processing" className='text-uppercase'>Processing</option>
                                            <option value="Confirmed" className='text-uppercase'>Confirmed</option>
                                            <option value="Shipping" className='text-uppercase'>Shipping</option>
                                            <option value="Delivered" className='text-uppercase'>Delivered</option>
                                            <option value="Canceled" className='text-uppercase'>Canceled</option>
                                        </select>
                                    </div>
                                    <Modal.Footer>
                                        <Button variant="secondary" onClick={handCancel}>Cancel</Button>
                                        <Button variant="danger" onClick={handleConfirmUpdate}>Update</Button>
                                    </Modal.Footer>
                                </Modal>
                            )}
                            {isDetailOpen && (
                                <Modal show={isDetailOpen} onHide={() => setIsDetailOpen(false)} dialogClassName="product-detail-modal" >
                                    <Modal.Header closeButton>
                                        <Modal.Title>Order Details</Modal.Title>
                                    </Modal.Header>
                                    <Modal.Body>
                                        <TableContainer component={Paper} className="table-container">
                                            <Table sx={{ minWidth: 650 }} aria-label="simple table">
                                                <TableHead>
                                                    <TableRow>
                                                        <TableCell align="left">Product Image</TableCell>
                                                        <TableCell align="left">Product Name</TableCell>
                                                        <TableCell align="left">Color</TableCell>
                                                        <TableCell align="left">Quantity</TableCell>
                                                        <TableCell align="left">Price</TableCell>
                                                        <TableCell align="left">Total</TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {orderDetails.map((detail, index) => (
                                                        <TableRow key={index}>
                                                            <TableCell align="left">
                                                                <img src={detail.image} alt={detail.nameProduct} className="additional-info-imgs" />
                                                            </TableCell>
                                                            <TableCell align="left">{detail.nameProduct}</TableCell>
                                                            <TableCell align="left">{detail.color}</TableCell>
                                                            <TableCell align="left">{detail.quantityProduct}</TableCell>
                                                            <TableCell align="left">{formatCurrency(detail.priceProduct)}</TableCell>
                                                            <TableCell align="left">{formatCurrency(detail.quantityProduct * detail.priceProduct)}</TableCell>
                                                        </TableRow>
                                                    ))}
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </Modal.Body>
                                    <Modal.Footer>
                                        <Button variant="secondary" onClick={() => setIsDetailOpen(false)}>Close</Button>
                                    </Modal.Footer>
                                </Modal>
                            )}
                        </Table>
                        <Pagination
                            pageCount={Math.ceil(filteredOrders.length / itemsPerPage)}
                            pageRangeDisplayed={5}
                            marginPagesDisplayed={2}
                            onPageChange={handlePageClick}
                            containerClassName={'pagination'}
                            activeClassName={'active'}
                        />
                    </TableContainer>
                </div>
            </div>
        </div>
    );
};

export default AcceptOrder;
