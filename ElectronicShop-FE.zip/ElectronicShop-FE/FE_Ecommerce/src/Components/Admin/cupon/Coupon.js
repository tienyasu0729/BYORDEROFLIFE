import React, { useEffect, useState } from "react";
import Sidebar from "../SideBar/SideBar";
import { useNavigate } from 'react-router-dom';
import { Paper, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import { Button, Modal, Table } from "react-bootstrap";
import { toast } from "react-toastify";
import axios from 'axios';
import { f_deleteCoupon_api, f_getCupon_api, f_updateCoupon_api } from "../../../config/api";

const Coupon = () => {
  const [listCoupons, setCoupons] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCouponId, setSelectedCouponId] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [dataCouponUpdate, setDataCouponUpdate] = useState({
    code: '',
    description: '',
    discount: '',
    startDate: '',
    endDate: '',
    usageLimit: ''
  });
  const [code, setCode] = useState('');
  const [description, setDescription] = useState('');
  const [discount, setDiscount] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [usageLimit, setUsageLimit] = useState('');
  const token = localStorage.getItem('token');

  // Get all coupons
  const getListCoupons = async () => {
    setIsLoading(true);
    try {
      const res = await f_getCupon_api();
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'success') {
        setCoupons(res.data.result);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    getListCoupons();
  }, []);

  // Create a new coupon
  const handleAdd = () => {
    setShowAddModal(true);
  };

  const navigate = useNavigate();

  const handleAddCoupon = async (e) => {
    e.preventDefault();
    if (!token) {
      navigate("/login");
      return;
    }

    if (!code || !description || !discount || !startDate || !endDate || !usageLimit) {
      toast.warning("Input is not blank. Please enter again!");
      return;
    }

    setIsLoading(true);

    const dataCoupon = {
      code,
      description,
      discount,
      startDate,
      endDate,
      usageLimit
    };

    try {
      const res = await axios.post("http://localhost:8080/api/coupons/create-coupon", dataCoupon, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (res.data.status === 'error') {
        toast.error(res.data.message);
      } else if (res.data.status === "success") {
        toast.success(res.data.message);
        getListCoupons();
        resetFormFields();
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
      setShowAddModal(false);
    }
  };

  const resetFormFields = () => {
    setCode('');
    setDescription('');
    setDiscount('');
    setStartDate('');
    setEndDate('');
    setUsageLimit('');
  };

  const handCancelAdd = () => {
    resetFormFields();
    setShowAddModal(false);
  };

  // Update the coupon
  const handleUpdate = (id) => {
    setSelectedCouponId(id);
    const couponToUpdate = listCoupons.find((coupon) => coupon.id === id);
    setDataCouponUpdate({
      code: couponToUpdate.code,
      description: couponToUpdate.description,
      discount: couponToUpdate.discount,
      startDate: couponToUpdate.startDate,
      endDate: couponToUpdate.endDate,
      usageLimit: couponToUpdate.usageLimit
    });
    setShowUpdateModal(true);
  };

  const handleUpdateCoupon = async () => {
    setIsLoading(true);

    try {
      const res = await f_updateCoupon_api(selectedCouponId, dataCouponUpdate, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (res.data.status === "success") {
        toast.success(res.data.message);
        getListCoupons();
      } else {
        toast.error(res.data.message);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
      setShowUpdateModal(false);
    }
  };

  const handCancelUpdate = () => {
    setShowUpdateModal(false);
  };

  // Delete the existing coupon
  const handleDelete = (id) => {
    setSelectedCouponId(id);
    setShowDeleteModal(true);
  };

  const handleConfirmDeleteCoupon = async () => {
    setIsLoading(true);
    try {
      const res = await f_deleteCoupon_api(selectedCouponId, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (res.data.status === 'success') {
        toast.success(res.data.message);
        getListCoupons();
      } else {
        toast.warning(res.data.message);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
      setShowDeleteModal(false);
    }
  };

  const handCancelDelete = () => {
    setShowDeleteModal(false);
  };

  return (
    <div className="admin">
      <div className="adminGlass" style={{ minHeight: "100vh" }}>
        <Sidebar />
        <div className='py-5' style={{paddingLeft:"205px", width:"100vw"}}>
            <div className="d-flex justify-content-between align-items-end py-3">
            <div>
              <h3>Coupons Manager</h3>
            </div>
            <div>
              <button className="btn btn-info" style={{ margin:"0 30px" }} onClick={handleAdd}>Add New Coupon <i style={{ color: "white" }} className="fa-solid fa-circle-plus fa-spin"></i></button>
            </div>
          </div>
          <TableContainer
                component={Paper}
                style={{
                  boxShadow: "0px 13px 20px 0px #80808029",
                  borderRadius: "20px",
                  width: "98%",
                  backgroundColor: "#F0FFF0",
                }}
            >
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
              <TableRow style={{backgroundColor:"#ff9200"}}>
                  <TableCell align="left">No.</TableCell>
                  <TableCell align="left">Code</TableCell>
                  <TableCell align="left">Description</TableCell>
                  <TableCell align="left">Discount</TableCell>
                  <TableCell align="left">Start Date</TableCell>
                  <TableCell align="left">End Date</TableCell>
                  <TableCell align="left">Usage Limit</TableCell>
                  <TableCell align="center">Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody style={{ color: "white" }}>
                {isLoading ? (
                  <TableRow className="d-flex justify-content-center">
                    <TableCell colSpan={8} align="center">
                      <div className="custom-loader"></div>
                    </TableCell>
                  </TableRow>
                ) : listCoupons && listCoupons.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} align="center">No data</TableCell>
                  </TableRow>
                ) : (
                  listCoupons &&
                  listCoupons.map((coupon, index) => (
                    <TableRow
                      key={coupon.id}
                      sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    >
                    <TableCell scope="row" style={{verticalAlign: "middle", paddingLeft:"25px"}}>
                        {index + 1}
                    </TableCell>
                      <TableCell align="left" style={{ verticalAlign: "middle" }}>{coupon.code}</TableCell>
                      <TableCell align="left" style={{ verticalAlign: "middle" }}>{coupon.description}</TableCell>
                      <TableCell align="left" style={{ verticalAlign: "middle" }}>{coupon.discount}</TableCell>
                      <TableCell align="left" style={{ verticalAlign: "middle" }}>{coupon.startDate}</TableCell>
                      <TableCell align="left" style={{ verticalAlign: "middle" }}>{coupon.endDate}</TableCell>
                      <TableCell align="left" style={{ verticalAlign: "middle" }}>{coupon.usageLimit}</TableCell>
                      <TableCell align="left" style={{justifyContent:"center"}} className="Details d-flex">
                        <div>
                          <button className="btn btn-primary" onClick={() => handleUpdate(coupon.id)}>Update</button>
                        </div>
                        <div className="mx-3">
                          <button className="btn btn-danger" onClick={() => handleDelete(coupon.id)}>Delete</button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
              {showAddModal && (
                <Modal show={showAddModal} onHide={handCancelAdd}>
                  <Modal.Header closeButton >
                    <Modal.Title>Create Coupon</Modal.Title>
                  </Modal.Header>
                  <form onSubmit={handleAddCoupon}>
                    <div className="d-flex">
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="code">Code<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          value={code}
                          onChange={(e) => setCode(e.target.value)}
                          name="text"
                          id="code"
                          placeholder="SALE10"
                          type="text" />
                      </div>
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="description">Description<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          name="text"
                          id="description"
                          placeholder="10% off"
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          type="text"
                        />
                      </div>
                    </div>
                    <div className="d-flex">
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="discount">Discount<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          value={discount}
                          onChange={(e) => setDiscount(e.target.value)}
                          name="text"
                          id="discount"
                          placeholder="10"
                          type="number" />
                      </div>
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="usageLimit">Usage Limit<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          name="text"
                          id="usageLimit"
                          placeholder="100"
                          value={usageLimit}
                          onChange={(e) => setUsageLimit(e.target.value)}
                          type="number"
                        />
                      </div>
                    </div>
                    <div className="d-flex">
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="startDate">Start Date<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          value={startDate}
                          onChange={(e) => setStartDate(e.target.value)}
                          name="text"
                          id="startDate"
                          type="date" />
                      </div>
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="endDate">End Date<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          name="text"
                          id="endDate"
                          value={endDate}
                          onChange={(e) => setEndDate(e.target.value)}
                          type="date"
                        />
                      </div>
                    </div>
                    <Modal.Footer>
                      <Button variant="secondary" onClick={handCancelAdd}>
                        Cancel
                      </Button>
                      <Button variant="danger" type="submit">
                        Create
                      </Button>
                    </Modal.Footer>
                  </form>
                </Modal>
              )}
              {showUpdateModal && (
                <Modal show={showUpdateModal} onHide={handCancelUpdate}>
                  <Modal.Header closeButton >
                    <Modal.Title>Confirm Update Coupon</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    <div className="d-flex">
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="code">Code<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          value={dataCouponUpdate.code}
                          onChange={(e) => setDataCouponUpdate((prevData) => ({ ...prevData, code: e.target.value }))}
                          name="text"
                          id="code"
                          placeholder="SALE10"
                          type="text" />
                      </div>
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="description">Description<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          name="text"
                          id="description"
                          placeholder="10% off"
                          value={dataCouponUpdate.description}
                          onChange={(e) => setDataCouponUpdate((prevData) => ({ ...prevData, description: e.target.value }))}
                          type="text"
                        />
                      </div>
                    </div>
                    <div className="d-flex">
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="discount">Discount<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          value={dataCouponUpdate.discount}
                          onChange={(e) => setDataCouponUpdate((prevData) => ({ ...prevData, discount: e.target.value }))}
                          name="text"
                          id="discount"
                          placeholder="10"
                          type="number" />
                      </div>
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="usageLimit">Usage Limit<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          name="text"
                          id="usageLimit"
                          placeholder="100"
                          value={dataCouponUpdate.usageLimit}
                          onChange={(e) => setDataCouponUpdate((prevData) => ({ ...prevData, usageLimit: e.target.value }))}
                          type="number"
                        />
                      </div>
                    </div>
                    <div className="d-flex">
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="startDate">Start Date<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          value={dataCouponUpdate.startDate}
                          onChange={(e) => setDataCouponUpdate((prevData) => ({ ...prevData, startDate: e.target.value }))}
                          name="text"
                          id="startDate"
                          type="date" />
                      </div>
                      <div className="inputGroup1 py-3 col-md-6">
                        <label htmlFor="endDate">End Date<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                        <input
                          className="input-category"
                          name="text"
                          id="endDate"
                          value={dataCouponUpdate.endDate}
                          onChange={(e) => setDataCouponUpdate((prevData) => ({ ...prevData, endDate: e.target.value }))}
                          type="date"
                        />
                      </div>
                    </div>
                  </Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handCancelUpdate}>
                      Cancel
                    </Button>
                    <Button variant="danger" onClick={handleUpdateCoupon}>
                      Update
                    </Button>
                  </Modal.Footer>
                </Modal>
              )}
              {showDeleteModal && (
                <Modal show={showDeleteModal} onHide={handCancelDelete}>
                  <Modal.Header closeButton >
                    <Modal.Title>Confirm Deletion</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    Are you sure you want to delete?
                  </Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handCancelDelete}>
                      Cancel
                    </Button>
                    <Button variant="danger" onClick={handleConfirmDeleteCoupon}>
                      Delete
                    </Button>
                  </Modal.Footer>
                </Modal>
              )}
            </Table>
          </TableContainer>
        </div>
      </div>
    </div>
  );
};

export default Coupon;
