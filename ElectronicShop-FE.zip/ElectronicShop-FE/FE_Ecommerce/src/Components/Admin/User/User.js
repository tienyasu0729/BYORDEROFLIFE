import React from "react";
import SideBar from "../SideBar/SideBar";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Switch from '@mui/material/Switch';
import { styled } from '@mui/material/styles';
import axios from 'axios';
import { f_getAllUser_api } from "../../../config/api";
import { toast } from "react-toastify";
import './User.css';
import { Button, Modal } from "react-bootstrap";
import Pagination from "react-paginate";
import { useNavigate } from "react-router-dom";

// Custom Switch using Material-UI styled API
const CustomSwitch = styled(Switch)(({ theme }) => ({
  width: 42,
  height: 26,
  padding: 0,
  display: 'flex',
  '&:active': {
    '& .MuiSwitch-thumb': {
      width: 15,
    },
    '& .MuiSwitch-switchBase.Mui-checked': {
      transform: 'translateX(9px)',
    },
  },
  '& .MuiSwitch-switchBase': {
    padding: 2,
    '&.Mui-checked': {
      transform: 'translateX(16px)',
      color: '#fff',
      '& + .MuiSwitch-track': {
        opacity: 1,
        backgroundColor: theme.palette.mode === 'dark' ? '#2ECA45' : '#65C466',
      },
    },
  },
  '& .MuiSwitch-thumb': {
    boxShadow: '0 2px 4px 0 rgba(0, 35, 11, 0.2)',
    width: 22,
    height: 22,
    borderRadius: 11,
    transition: theme.transitions.create(['width'], {
      duration: 200,
    }),
  },
  '& .MuiSwitch-track': {
    borderRadius: 26 / 2,
    opacity: 1,
    backgroundColor: theme.palette.mode === 'dark' ? '#39393D' : '#E9E9EA',
    boxSizing: 'border-box',
  },
}));

const User = () => {
  const [showUpdateModal, setShowUpdateModal] = React.useState(false);
  const [selectedUserId, setSelectedUserId] = React.useState(null);
  const [selectedUserStatus, setSelectedUserStatus] = React.useState(null);
  const [page, setPage] = React.useState({ number: 0, size: 10, totalPages: 1 });
  const [listUser, setListUser] = React.useState([]);
  const [isLoading, setIsLoading] = React.useState(false);
  const navigate = useNavigate();

  const token = localStorage.getItem('token');

  const getListUser = async (pageNumber = 0, size = 10) => {
    setIsLoading(true);
    try {
      const res = await f_getAllUser_api(pageNumber, size);
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'success') {
        setListUser(res.data.result.content);
        setPage(res.data.result);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    getListUser(0, 10);
  }, []);

  const makeStyle = (role) => {
    if (role === '["ROLE_CUSTOMER"]') {
      return {
        color: '#33CC00',
        borderRadius: "50% 10%",
      };
    } else if (role === '["ROLE_ADMIN"]') {
      return {
        color: 'red',
        borderRadius: "50% 10%",
      };
    }
  };

  const role = (role) => {
    if (role === '["ROLE_ADMIN"]') {
      return "ADMIN";
    } else if (role === '["ROLE_CUSTOMER"]') {
      return "CUSTOMER";
    }
  };

  const handleStatusChange = (id, status) => {
    setSelectedUserId(id);
    setSelectedUserStatus(status);
    setShowUpdateModal(true);
  };

  const handleConfirmUpdate = async () => {
    if (!token) {
      navigate("/login");
      return;
    }

    setIsLoading(true);
    try {
      const newStatus = !selectedUserStatus; // Toggle the status
      const formData = new FormData();
      formData.append('status', newStatus.toString());
      
      console.log(`Sending payload for user ${selectedUserId}:`, newStatus);
      const res = await axios.post(`http://localhost:8080/api/account/update-admin/${selectedUserId}`, formData, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (res.data.status === 'not-found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'success') {
        toast.success(res.data.message);
        getListUser(page.number, page.size);  // giữ nguyên trang hiện tại
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
      setShowUpdateModal(false);
    }
  };

  const handleCancelUpdate = () => {
    setShowUpdateModal(false);
  };

  return (
    <div className="admin">
      <div className="adminGlass" style={{ minHeight: "100vh" }}>
        <SideBar />
        <div className="py-5" style={{paddingLeft:"205px", width:"100vw"}}>
            <h3 className="text-center py-3">MANAGE ACCOUNT</h3>
            <TableContainer
                component={Paper}
                style={{
                  boxShadow: "0px 13px 20px 0px #80808029",
                  borderRadius: "20px",
                  width: "97%",
                  backgroundColor: "#F0FFF0"
                }}
          >
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead style={{backgroundColor:"#ff9200"}}>
                              <TableRow>
                  <TableCell>No. </TableCell>
                  <TableCell align="left">Name</TableCell>
                  <TableCell align="left">Phone</TableCell>
                  <TableCell align="left">Gmail</TableCell>
                  <TableCell align="left">Address</TableCell>
                  <TableCell align="left">Role</TableCell>
                  <TableCell align="left">Active</TableCell>
                </TableRow>
              </TableHead>
              <TableBody style={{ color: "white" }}>
              {isLoading ? (
                <TableRow className="d-flex justify-content-center">
                  <TableCell colSpan={8} align="center">
                    <div className="custom-loader"></div>
                  </TableCell>
                </TableRow>
              ) : listUser && Array.isArray(listUser) && listUser.length > 0 ? (
                listUser.map((user, index) => (
                  <TableRow key={user.id} sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                    <TableCell style={{paddingLeft:"25px !important"}} scope="row">{index + 1}</TableCell>
                    <TableCell align="left">{user.name}</TableCell>
                    <TableCell align="left">{user.tel}</TableCell>
                    <TableCell align="left">{user.email}</TableCell>
                    <TableCell align="left">{user.address}</TableCell>
                    <TableCell align="left" style={makeStyle(user.authority)}>{role(user.authority)}</TableCell>
                    <TableCell align="left" className="Details d-flex">
                        <CustomSwitch
                        checked={user.active}
                        onChange={() => handleStatusChange(user.id, user.active)}
                        color="primary"
                      />
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={8} align="center">No data</TableCell>
                </TableRow>
              )}
              </TableBody>
              {showUpdateModal && (
                <Modal show={showUpdateModal} onHide={handleCancelUpdate}>
                  <Modal.Header closeButton>
                    <Modal.Title>Update Status</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    Are you sure you want to {selectedUserStatus ? "deactivate" : "activate"} this account?
                  </Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handleCancelUpdate}>
                      Cancel
                    </Button>
                    <Button variant="danger" onClick={handleConfirmUpdate}>
                      Update
                    </Button>
                  </Modal.Footer>
                </Modal>
              )}
            </Table>
            <Pagination
              pageCount={page.totalPages}
              pageRangeDisplayed={5}
              marginPagesDisplayed={2}
              onPageChange={({ selected }) => getListUser(selected, page.size)}
              containerClassName={'pagination'}
              activeClassName={'active'}
            />
          </TableContainer>
        </div>
      </div>
    </div>
  );
};

export default User;
