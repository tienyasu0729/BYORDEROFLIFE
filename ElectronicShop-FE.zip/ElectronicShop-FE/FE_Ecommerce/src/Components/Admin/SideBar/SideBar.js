import React, { useState, useEffect } from "react";
import "./Sidebar.css";
import Logo from "../../../assets/IMG/logo-admin.png";
import { UilBars } from "@iconscout/react-unicons";
import { motion } from "framer-motion";
import { Link, useLocation } from "react-router-dom";
import {
    UilEstate,
    UilUsersAlt,
    UilPackage,
    UilClipboardNotes,
    UilTicket,
    UilBox,
    UilLayerGroup,
    UilTrademark,
    UilUserCheck,
    UilDashboard,
} from "@iconscout/react-unicons";

const Sidebar = () => {
    const location = useLocation();
    const currentPath = location.pathname;

    return (
        <>
            <div className="bars">
                <UilBars />
            </div>
            <motion.div className="sidebar" style={{width:"176px", height:"832px"}}>
                <Link  className="logo text-decoration-none">
                    <img src={Logo} alt="logo" />
                    <span className="text-dark">
                        AD<span>M</span>IN
                    </span>
                </Link>

                <div className="menu">
                    <div className="selected d-flex flex-column">
                        <Link
                            className={`text-dark text-decoration-none py-4 sidebar-hover-admin ${
                                currentPath === "/admin-page" ? "actived" : ""
                            }`}
                            to="/admin-page"
                        >
                            <span className="mx-3 fs-4">
                                <UilEstate /> Dashboard
                            </span>
                        </Link>
                        <Link
                            className={`text-dark text-decoration-none py-4 sidebar-hover-admin${
                                currentPath === "/list-user" ? "actived" : ""
                            }`}
                            to="/list-user"
                        >
                            <span className="mx-3 fs-4">
                                <UilUserCheck /> Customer
                            </span>
                        </Link>
                        <Link
                            className={`text-dark text-decoration-none py-4 sidebar-hover-admin${
                                currentPath === "/category-admin" ? "actived" : ""
                            }`}
                            to="/category-admin"
                        >
                            <span className="mx-3 fs-4">
                                <UilLayerGroup /> Categories
                            </span>
                        </Link>
                        <Link
                            className={`text-dark text-decoration-none py-4 sidebar-hover-admin${
                                currentPath === "/brands-admin" ? "actived" : ""
                            }`}
                            to="/brands-admin"
                        >
                            <span className="mx-3 fs-4">
                                <UilTrademark /> Brands
                            </span>
                        </Link>
                        <Link
                            className={`text-dark text-decoration-none py-4 sidebar-hover-admin${
                                currentPath === "/product-admin" ? "actived" : ""
                            }`}
                            to="/product-admin"
                        >
                            <span className="mx-3 fs-4">
                                <UilBox /> Products
                            </span>
                        </Link>
                        <Link
                            className={`text-dark text-decoration-none py-4 sidebar-hover-admin${
                                currentPath === "/accept-order" ? "actived" : ""
                            }`}
                            to="/accept-order"
                        >
                            <span className="mx-3 fs-4">
                                <UilClipboardNotes /> Accept Order
                            </span>
                        </Link>
                        <Link
                            className={`text-dark text-decoration-none py-4 sidebar-hover-admin${
                                currentPath === "/coupon-admin" ? "actived" : ""
                            }`}
                            to="/coupon-admin"
                        >
                            <span className="mx-3 fs-4">
                                <UilTicket /> Coupon
                            </span>
                        </Link>
                    </div>
                </div>
            </motion.div>
        </>
    );
};

export default Sidebar;
