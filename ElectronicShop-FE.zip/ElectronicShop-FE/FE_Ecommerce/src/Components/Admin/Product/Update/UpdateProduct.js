import React, { useEffect, useState } from 'react';
import Sidebar from '../../SideBar/SideBar';
import { useNavigate, useParams } from 'react-router-dom';
import { f_getAllBrands_api, f_getAllCategory_api, f_getAllColor_api, f_getAllProductId_api } from '../../../../config/api';
import { toast } from 'react-toastify';
import axios from '../../../../config/customAxios';
import { convertBase64ToBlob } from '../../../../Validate/Validate';

const UpdateProduct = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [listBrand, setListBrand] = useState([]);
  const [listCategory, setListCategory] = useState([]);
  const { id } = useParams();
  const [imgProduct1, setImgProduct1] = useState(null);
  const [imgProduct2, setImgProduct2] = useState(null);
  const [imgProduct3, setImgProduct3] = useState(null);
  const [previewImage1, setPreviewImage1] = useState('');
  const [previewImage2, setPreviewImage2] = useState('');
  const [previewImage3, setPreviewImage3] = useState('');
  const navigate = useNavigate();
  const [colorName, setColorName] = useState([]);
  const [color, setColors] = useState([]);
  const [productData, setProductData] = useState({
    name: "",
    information: "",
    description: "",
    slug: "",
    summary: "",
    stock: "",
    price: "",
    discountedPrice: "",
    brandsId: "",
    categoriesId: "",
    colorId: [],
    image: "",
    image2: "",
    image3: "",
    status: "",
    promotionId: 1 // Giá trị mặc định cho promotionId
  });

  const getColors = async () => {
    setIsLoading(true);
    try {
      const res = await f_getAllColor_api();
      if (res.data.status === 'not-found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'success') {
        setColorName(res.data.result);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleColorChange = (colorId) => {
    const updatedColorIds = [...productData.colorId];
    if (updatedColorIds.includes(colorId)) {
      updatedColorIds.splice(updatedColorIds.indexOf(colorId), 1);
    } else {
      updatedColorIds.push(colorId);
    }
    setProductData({ ...productData, colorId: updatedColorIds });
  };

  useEffect(() => {
    getListBrand();
    getListCategory();
    getProductById();
    getColors();
  }, []);

  const getProductById = async () => {
    setIsLoading(true);
    try {
      const res = await f_getAllProductId_api(id);
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'success') {
        const { product, colors } = res.data.result;
        const colorIds = colors.map((color) => color.id);
        setProductData({ ...product, colorId: colorIds, promotionId: product.promotionId || 1 });
        setColors(colors);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const getListBrand = async () => {
    setIsLoading(true);
    try {
      const res = await f_getAllBrands_api();
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'success') {
        setListBrand(res.data.result);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const getListCategory = async () => {
    setIsLoading(true);
    try {
      const res = await f_getAllCategory_api();
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'success') {
        setListCategory(res.data.result);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageChangeUpdate = (e, setImgProduct, setPreviewImage) => {
    const selectedImage = e.target.files[0];
    if (selectedImage) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(selectedImage);
      setImgProduct(selectedImage);
    }
  };

  const handleUpdateProduct = async () => {
    if (!productData.name || !productData.slug || !productData.description || !productData.information 
      || !productData.summary || !productData.price || !productData.discountedPrice || !productData.stock) {
      toast.warning('Input not blank, Please');
      return;
    } else if (!imgProduct1) {
      toast.warning('Please choose at least one image');
      return;
    }

    const formData = new FormData();
    formData.append('image', imgProduct1);
    if (imgProduct2) formData.append('image2', imgProduct2);
    if (imgProduct3) formData.append('image3', imgProduct3);
    formData.append('product', JSON.stringify({
      'name': productData.name,
      'slug': productData.slug,
      'description': productData.description,
      'information': productData.information,
      'summary': productData.summary,
      'stock': productData.stock,
      'price': productData.price,
      'discountedPrice': productData.discountedPrice,
      'brandsId': productData.brandsId,
      'categoriesId': productData.categoriesId,
      'colorId': productData.colorId,
      'status': productData.status,
      'promotionId': productData.promotionId // Gửi promotionId
    }));

    setIsLoading(true);
    try {
      console.log(formData);
      const res = await axios.put(`/product/update-product/${id}`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'error') {
        toast.error(res.data.message);
      } else if (res.data.status === 'success') {
        toast.success(res.data.message);
        navigate("/product-admin");
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    navigate("/product-admin");
  };

  return (
    <div className='admin'>
      <div className='adminGlass' style={{ minHeight: "100vh" }}>
        <Sidebar />
        <div className="py-5" style={{paddingLeft:"205px", width:"100vw"}}>
          <h1 className="text-center fw-bolder">Update Product</h1>
          <div className="d-flex justify-content-around">
            <div className="col-md-5">
              <div className="inputGroup1 py-3">

                <label htmlFor="productDescription" style={{ userSelect: "none" }}>Product Description<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                <textarea id="productDescription" cols="25"
                  value={productData.description}
                  onChange={(e) => setProductData({ ...productData, description: e.target.value })}
                  rows="5" className="col-md-12 form-control">
                </textarea>

                <label htmlFor="productInformation" style={{ userSelect: "none" }}>Product Information<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                <textarea id="productInformation" cols="25"
                  value={productData.information}
                  onChange={(e) => setProductData({ ...productData, information: e.target.value })}
                  rows="5" className="col-md-12 form-control">
                </textarea>

                <label htmlFor="productSummary" style={{ userSelect: "none" }}>Product Summary<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                <textarea id="productSummary" cols="25"
                  value={productData.summary}
                  onChange={(e) => setProductData({ ...productData, summary: e.target.value })}
                  rows="5" className="col-md-12 form-control">
                </textarea>
              </div>
              <div className="d-flex">
                <div>
                  <button className="btn btn-success" onClick={handleUpdateProduct}>Update
                    &nbsp;
                    {isLoading ? (
                      <i className="fa-solid fa-spinner fa-spin-pulse fa-spin-reverse"></i>
                    ) : (
                      <i className="fa-solid fa-circle-plus"></i>
                    )}
                  </button>
                </div>
                <div className="mx-4">
                  <button className="btn btn-danger" onClick={handleCancel}>Cancel</button>
                </div>
              </div>
            </div>
            <div className="col-md-5">
              <div className="inputGroup1 py-3">
                <label htmlFor="nameCate" style={{ userSelect: "none" }}>Product Name<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                <input
                  className="input-category col-md-12"
                  value={productData.name}
                  onChange={(e) => setProductData({ ...productData, name: e.target.value })}
                  name="text"
                  id="nameCate"
                  placeholder="how you like that...."
                  type="text"
                />

                <label htmlFor="slugCate" style={{ userSelect: "none" }}>Product Slug<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                <input
                  className="input-category col-md-12"
                  value={productData.slug}
                  onChange={(e) => setProductData({ ...productData, slug: e.target.value })}
                  name="text"
                  id="slugCate"
                  placeholder="how you like that...."
                  type="text"
                />

                <label htmlFor="stockCate" style={{ userSelect: "none" }}>Product Stock<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                <input
                  className="input-category col-md-12"
                  value={productData.stock}
                  onChange={(e) => setProductData({ ...productData, stock: e.target.value })}
                  name="text"
                  id="stockCate"
                  placeholder="how you like that...."
                  type="text"
                />

                <label htmlFor="priceCate" style={{ userSelect: "none" }}>Product Price<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                <input
                  className="input-category col-md-12"
                  value={productData.price}
                  onChange={(e) => setProductData({ ...productData, price: e.target.value })}
                  name="text"
                  id="priceCate"
                  placeholder="how you like that...."
                  type="text"
                />

                <label htmlFor="discountCate" style={{ userSelect: "none" }}>Product Discount<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                <input
                  className="input-category col-md-12"
                  value={productData.discountedPrice}
                  onChange={(e) => setProductData({ ...productData, discountedPrice: e.target.value })}
                  name="text"
                  id="discountCate"
                  placeholder="how you like that...."
                  type="text"
                />
                <div className="d-flex justify-content-around py-2">
                  {colorName?.map((color, index) => {
                    return (
                      <div key={index} className="d-flex flex-column align-items-center">
                        <label htmlFor={color.name}>{color.name}</label>
                        <input
                          id={color.name}
                          className="checkbox"
                          type="checkbox"
                          value={color.id}
                          onChange={() => handleColorChange(color.id)}
                          checked={productData.colorId.includes(color.id)}
                        />
                      </div>
                    );
                  })}
                </div>
                <div className="d-flex justify-content-around">
                  <div className="flex-column col-md-4">
                    <label>Brand<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                    <select
                      id="brand"
                      value={productData.brandsId}
                      onChange={(e) => setProductData({ ...productData, brandsId: e.target.value })}
                      className="form-control"
                    >
                      {listBrand?.map((brands) => (
                        <option key={brands.id} value={brands.id}>{brands.nameBrand}</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex-column col-md-4">
                    <label>Category<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                    <select
                      id="category"
                      value={productData.categoriesId}
                      onChange={(e) => setProductData({ ...productData, categoriesId: e.target.value })}
                      className="form-control"
                    >
                      {listCategory?.map((categories) => (
                        <option key={categories.id} value={categories.id}>{categories.nameCategory}</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex-column col-md-4">
                    <label>Status<span className="text-danger" style={{ fontSize: "15px", fontWeight: "bolder" }}>*</span></label>
                    <select
                      id="status"
                      value={productData.status}
                      onChange={(e) => setProductData({ ...productData, status: e.target.value })}
                      className="form-control"
                    >
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </div>
                <div className="inputGroup1 py-3 col-md-12 d-flex flex-column">
                  <input
                    className="input-category"
                    name="text"
                    type="file"
                    style={{minHeight: "0px", backgroundColor: "transparent"}}
                    onChange={(e) => handleImageChangeUpdate(e, setImgProduct1, setPreviewImage1)}
                  />
                  {previewImage1 ? (
                    <img src={previewImage1} alt="Preview 1" style={{ marginTop: '10px', maxWidth: '100%' }} />
                  ) : (
                    <img
                      src={convertBase64ToBlob(productData.image)}
                      alt="bug" style={{ marginTop: '10px', maxWidth: '100%' }} />
                  )}
                </div>
                <div className="inputGroup1 py-3 col-md-12 d-flex flex-column">
                  <input
                    className="input-category"
                    name="text"
                    type="file"
                    style={{minHeight: "0px", backgroundColor: "transparent"}}
                    onChange={(e) => handleImageChangeUpdate(e, setImgProduct2, setPreviewImage2)}
                  />
                  {previewImage2 && (
                    <img src={convertBase64ToBlob(productData.image2)}
                     alt="Preview 2" style={{ marginTop: '10px', maxWidth: '100%' }} />
                  )}
                </div>
                <div className="inputGroup1 py-3 col-md-12 d-flex flex-column">
                  <input
                    className="input-category"
                    name="text"
                    type="file"
                    style={{minHeight: "0px", backgroundColor: "transparent"}}
                    onChange={(e) => handleImageChangeUpdate(e, setImgProduct3, setPreviewImage3)}
                  />
                  {previewImage3 && (
                    <img src={convertBase64ToBlob(productData.image3)}
                     alt="Preview 3" style={{ marginTop: '10px', maxWidth: '100%' }} />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdateProduct;
