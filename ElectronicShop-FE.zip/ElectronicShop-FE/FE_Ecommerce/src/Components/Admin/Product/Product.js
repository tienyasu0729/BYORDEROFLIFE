import React, { useEffect, useState } from "react";
import Sidebar from "../SideBar/SideBar";
import {
  Paper,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import { Button, Modal, Table } from "react-bootstrap";
import { f_deleteProduct_api, f_getAllProduct_api, f_getAllReviewByProduct_api } from "../../../config/api";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import Pagination from "react-paginate";
import { formatCurrency } from "../../../Validate/Validate";
import { FaEye, FaStar, FaTrash } from "react-icons/fa";
import axios from "axios";

const ProductAdmin = () => {
  const token = localStorage.getItem('token');
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [products, setProducts] = useState([]);
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [reviews, setReviews] = useState([]);
  const [reviewToDelete, setReviewToDelete] = useState(null);
  const [page, setPage] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [totalPages, setTotalPages] = useState(0);

  const itemsPerPage = 6;

  const makeStyle = (status) => {
    if (status === 'Active' || status === 'available') {
      return {
        borderRadius: '10px',
        background: 'rgb(145 254 159 / 47%)',
        color: '#33CC00',
        padding: '0.5rem 1rem',
        display: 'inline-block',
      };
    } else if (status === 'Inactive') {
      return {
        borderRadius: '5px',
        background: '#ffadad8f',
        color: '#DD0000',
        padding: '0.5rem 1rem',
        display: 'inline-block',
      };
    }
  };

  // add product
  const handleAddProduct = () => {
    navigate("/add-product");
  };

  // update product
  const handleUpdate = (id) => {
    navigate(`/update-product/${id}`);
  };

  // delete product
  const handleDelete = async (id) => {
    try {
      const res = await f_deleteProduct_api(id);
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'error') {
        toast.error(res.data.message);
      } else if (res.data.status === 'success') {
        toast.success(res.data.message);
        fetchProducts(page, itemsPerPage); // Reload the current page after delete
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setShowDeleteModal(false);
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setShowDeleteModal(false);
  };

  const handleConfirmDelete = async () => {
    setIsLoading(true);
    try {
      const res = await f_deleteProduct_api(selectedProductId);
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'error') {
        toast.error(res.data.message);
      } else if (res.data.status === 'success') {
        toast.success(res.data.message);
        fetchProducts(page, itemsPerPage); // Reload the current page after delete
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setShowDeleteModal(false);
      setIsLoading(false);
    }
  };

  // get all products
  const fetchProducts = async (pageNumber = 0, size = itemsPerPage) => {
    setIsLoading(true);
    try {
      const res = await f_getAllProduct_api(pageNumber, size);
      if (res.data.status === "not found") {
        toast.warning(res.data.message);
      } else if (res.data.status === "error") {
        toast.error(res.data.message);
      } else if (res.data.status === "success") {
        setProducts(res.data.result.content);
        setFilteredProducts(res.data.result.content);
        setTotalPages(res.data.result.totalPages);
        setPage(pageNumber);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts(0, itemsPerPage);
  }, []);

  useEffect(() => {
    if (searchQuery === '') {
      setFilteredProducts(products);
    } else {
      const lowercasedQuery = searchQuery.toLowerCase();
      const filtered = products.filter(product =>
        product.name.toLowerCase().includes(lowercasedQuery) ||
        (product.description && product.description.toLowerCase().includes(lowercasedQuery)) ||
        (product.summary && product.summary.toLowerCase().includes(lowercasedQuery)) ||
        (product.information && product.information.toLowerCase().includes(lowercasedQuery)) ||
        product.status.toLowerCase().includes(lowercasedQuery)
      );
      setFilteredProducts(filtered);
    }
  }, [searchQuery, products]);

  const handlePageClick = (event) => {
    fetchProducts(event.selected, itemsPerPage);
  };

  // Fetch reviews for a product
  const fetchReviews = async (productId) => {
    setIsLoading(true);
    try {
      const res = await f_getAllReviewByProduct_api(productId);
      if (res.data.status === 'success') {
        setReviews(res.data.result);
        setShowReviewModal(true);
      } else {
        toast.warning(res.data.message);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleViewReviews = (productId) => {
    fetchReviews(productId);
  };

  const handleCloseReviewModal = () => {
    setShowReviewModal(false);
    setReviews([]);
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const handleDeleteReview = async () => {
    if (!reviewToDelete) return;

    setIsLoading(true);
    console.log("Attempting to delete review with ID:", reviewToDelete); // Debug log

    try {
      const baseURL = "http://localhost:8080/api"; // Ensure this is correct
      const url = `${baseURL}/reviews/delete-review/${reviewToDelete}`;
      console.log("DELETE request URL:", url); // Log the URL being called

      const res = await axios.delete(url, {
        headers: { Authorization: `Bearer ${token}` }
      });

      console.log("API response:", res); // Debug log
      if (res.data.status === 'success') {
        toast.success('Review deleted successfully');
        setReviews(reviews.filter(review => review.id !== reviewToDelete));
      } else {
        toast.error('Failed to delete review');
      }
    } catch (error) {
      console.error('Error during delete review API call:', error); // Debug log
      toast.error(error.message);
    } finally {
      setIsLoading(false);
      setShowConfirmModal(false);
    }
  };

  const confirmDeleteReview = (reviewId) => {
    setReviewToDelete(reviewId);
    setShowConfirmModal(true);
  };

  const cancelDeleteReview = () => {
    setReviewToDelete(null);
    setShowConfirmModal(false);
  };

  return (
    <div className="admin">
      <div className="adminGlass" style={{ minHeight: "100vh" }}>
        <Sidebar />
        <div className="py-5" style={{paddingLeft:"205px", width:"100vw"}}>
          <div className="d-flex flex-row justify-content-between">
            <div className="py-3">
              <h3>List Product</h3>
            </div>
            <div className="py-3">
              <button className="btn btn-info" onClick={handleAddProduct} style={{ margin:"0 30px" }}>Add New Product <i style={{color: "white"}} className="fa-solid fa-circle-plus fa-spin"></i></button>
            </div>
          </div>
          <div className="search-container text-center mb-4">
            <TextField
              label="Search Products"
              variant="outlined"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ width: '50%' }}
            />
          </div>
          <TableContainer component={Paper} className="table-container" style={{
              boxShadow: "0px 13px 20px 0px #80808029",
              borderRadius: "20px",
              width: "98%",
              backgroundColor: "#F0FFF0",
            }}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow style={{backgroundColor:"#ff9200"}}> 
                  <TableCell style={{paddingLeft:"20px"}} align="left">No.</TableCell>
                  <TableCell align="left">Name</TableCell>
                  <TableCell align="left">Product Image</TableCell>
                  <TableCell align="left">Stock</TableCell>
                  <TableCell align="left">Price</TableCell>
                  <TableCell align="left">Discounted</TableCell>
                  <TableCell align="left">Brand</TableCell>
                  <TableCell align="left">Category</TableCell>
                  <TableCell align="left">Status</TableCell>
                  <TableCell align="left">Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody style={{ color: "white" }}>
                {isLoading ? (
                  <TableRow className="d-flex justify-content-center">
                    <TableCell colSpan={10} align="center" >
                      <div className="custom-loader"></div>
                    </TableCell>
                  </TableRow>
                ) : filteredProducts.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} align="center">No data</TableCell>
                  </TableRow>
                ) : (
                  filteredProducts.map((listProduct, index) => (
                    <TableRow
                      key={listProduct.id}
                      sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    >
                      <TableCell className="table-cell" style={{paddingLeft:"25px"}} scope="row">
                        {index + 1 + (page * itemsPerPage)}
                      </TableCell>
                      <TableCell align="left" style={{verticalAlign: "middle"}}>{listProduct.name}</TableCell>
                      <TableCell align="left" style={{verticalAlign: "middle"}}>
                        <img src={listProduct.image} alt={listProduct.name} style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '5px' }} />
                      </TableCell>
                      <TableCell align="left" style={{verticalAlign: "middle"}}>{listProduct.stock}</TableCell>
                      <TableCell align="left" style={{verticalAlign: "middle"}}>{formatCurrency(listProduct.price)}</TableCell>
                      <TableCell align="left" style={{verticalAlign: "middle"}}>{formatCurrency(listProduct.discountedPrice)}</TableCell>
                      <TableCell align="left" style={{verticalAlign: "middle"}}>{listProduct.brandsName}</TableCell>
                      <TableCell align="left" style={{verticalAlign: "middle"}}>{listProduct.categoriesName}</TableCell>
                      <TableCell align="left" style={{verticalAlign: "middle"}}>
                        <span className="status" style={makeStyle(listProduct.status)}>{listProduct.status}</span>
                      </TableCell>
                      <TableCell className="table-cell action-buttons" align="left">
                        <button className="btn btn-primary" style={{  padding: "0.375rem 0.6rem", marginRight: '0.5rem' }} onClick={() => handleUpdate(listProduct.id)}>
                          Update
                        </button>
                        <button className="btn btn-danger" style={{  padding: "0.375rem 0.6rem", marginRight: '0.5rem' }} onClick={() => setSelectedProductId(listProduct.id) & setShowDeleteModal(true)}>
                          Delete
                        </button>
                        <button className="btn btn-info" style={{  padding: "0.375rem 0.6rem" }} onClick={() => handleViewReviews(listProduct.id)}>
                          <FaEye />
                        </button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
              {showDeleteModal && (
                <Modal show={showDeleteModal} onHide={handleCancel}>
                  <Modal.Header closeButton >
                    <Modal.Title>Confirm Delete Product</Modal.Title>
                  </Modal.Header>
                  <div className="py-3 text-center">
                    Are you sure you want to delete this product?
                  </div>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handleCancel}>
                      Cancel
                    </Button>
                    <Button variant="danger" onClick={handleConfirmDelete}>
                      Delete
                    </Button>
                  </Modal.Footer>
                </Modal>
              )}
              {showReviewModal && (
                <Modal show={showReviewModal} onHide={handleCloseReviewModal}>
                  <Modal.Header closeButton>
                    <Modal.Title>Product Reviews</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    {reviews.length > 0 ? (
                      <ul style={{ listStyleType: 'none', padding: '0' }}>
                        {reviews.map(review => (
                          <li key={review.id} style={{ marginBottom: '1rem', padding: '1rem', border: '1px solid #ddd', borderRadius: '5px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <strong>{review.nameUser}</strong>
                                <span style={{ fontSize: '0.875rem', color: '#888', marginLeft: '1rem' }}>{formatDate(review.createdAt)}</span>
                              </div>
                              <div style={{ margin: '0.5rem 0' }}>
                                {Array(review.rating).fill().map((_, i) => (
                                  <FaStar key={i} style={{ color: '#FFD700' }} />
                                ))}
                              </div>
                              <p style={{ margin: '0' }}>{review.comment}</p>
                            </div>
                            <button className="btn btn-danger" style={{ padding: '0.375rem 0.6rem' }} onClick={() => confirmDeleteReview(review.id)}>
                              <FaTrash />
                            </button>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p>No reviews available for this product.</p>
                    )}
                  </Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseReviewModal}>
                      Close
                    </Button>
                  </Modal.Footer>
                </Modal>
              )}
              {showConfirmModal && (
                <Modal show={showConfirmModal} onHide={cancelDeleteReview}>
                  <Modal.Header closeButton>
                    <Modal.Title>Confirm Delete Review</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    Are you sure you want to delete this review?
                  </Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={cancelDeleteReview}>
                      Cancel
                    </Button>
                    <Button variant="danger" onClick={handleDeleteReview}>
                      Delete
                    </Button>
                  </Modal.Footer>
                </Modal>
              )}
            </Table>
            <Pagination
              pageCount={totalPages}
              pageRangeDisplayed={5}
              marginPagesDisplayed={2}
              onPageChange={handlePageClick}
              containerClassName={'pagination'}
              activeClassName={'active'}
              previousLabel={'Previous'}
              nextLabel={'Next'}
              breakLabel={'...'}
              breakClassName={'break-me'}
              pageClassName={'page-item'}
              pageLinkClassName={'page-link'}
              previousClassName={'page-item'}
              previousLinkClassName={'page-link'}
              nextClassName={'page-item'}
              nextLinkClassName={'page-link'}
              activeClassName={'active'}
            />
          </TableContainer>
        </div>
      </div>
    </div>
  );
};

export default ProductAdmin;
