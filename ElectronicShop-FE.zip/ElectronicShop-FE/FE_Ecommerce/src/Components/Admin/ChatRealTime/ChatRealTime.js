import React, { useEffect, useState } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import './ChatRealTime.css';
import Sidebar from "../SideBar/SideBar";
var stompClient = null;

const ChatRealTime = () => {
    const [privateChats, setPrivateChats] = useState(new Map(JSON.parse(localStorage.getItem('privateChats')) || []));
    const [tab, setTab] = useState(null);
    const [userData, setUserData] = useState({
        username: 'Admin',
        connected: false,
        message: ''
    });

    useEffect(() => {
        connect();
    }, []);

    useEffect(() => {
        localStorage.setItem('privateChats', JSON.stringify(Array.from(privateChats.entries())));
    }, [privateChats]);

    const connect = () => {
        let socket = new SockJS('http://localhost:8080/ws');
        stompClient = new Client({
            webSocketFactory: () => socket,
            onConnect: onConnected,
            onStompError: onError,
        });
        stompClient.activate();
    }

    const onConnected = () => {
        setUserData(prevState => ({ ...prevState, connected: true }));
        stompClient.subscribe('/user/' + userData.username + '/private', onPrivateMessage);
    }

    const onPrivateMessage = (payload) => {
        var payloadData = JSON.parse(payload.body);
        if (privateChats.get(payloadData.senderName)) {
            privateChats.get(payloadData.senderName).push(payloadData);
            setPrivateChats(new Map(privateChats));
        } else {
            let list = [];
            list.push(payloadData);
            privateChats.set(payloadData.senderName, list);
            setPrivateChats(new Map(privateChats));
        }
    }

    const onError = (err) => {
        console.log(err);
    }

    const handleMessage = (event) => {
        const { value } = event.target;
        setUserData(prevState => ({ ...prevState, message: value }));
    }

    const sendValue = () => {
        if (stompClient && tab) {
            var chatMessage = {
                senderName: userData.username,
                receiverName: tab,
                message: userData.message,
                status: "MESSAGE",
                timestamp: new Date().toLocaleTimeString()
            };
            if (privateChats.get(tab)) {
                privateChats.get(tab).push(chatMessage);
            } else {
                privateChats.set(tab, [chatMessage]);
            }
            setPrivateChats(new Map(privateChats));
            stompClient.publish({
                destination: "/app/private-message",
                body: JSON.stringify(chatMessage),
            });
            setUserData(prevState => ({ ...prevState, message: '' }));
        }
    }

    const handleKeyPress = (event) => {
        if (event.key === 'Enter') {
            sendValue();
        }
    };

    const getAvatar = (name) => {
        return name ? name.charAt(0).toUpperCase() : '';
    };

    return (
        <div className="py-5">
            <h3 className="text-center py-3">Chat Management</h3>    
            <div className="chat-realtime">
                {userData.connected ?
                    <div className="chat-box">
                        <div className="member-list">
                            <ul>
                                {[...privateChats.keys()].map((name, index) => (
                                    <li onClick={() => { setTab(name) }} className={`member ${tab === name && "active"}`} key={index}>{name}</li>
                                ))}
                            </ul>
                        </div>
                        {tab && <div className="chat-content">
                            <ul className="chat-messages">
                                {[...privateChats.get(tab)].map((chat, index) => (
                                    <li className={`message ${chat.senderName === userData.username && "self"}`} key={index}>
                                        {chat.senderName !== userData.username && <div className="avatar">{getAvatar(chat.senderName)}</div>}
                                        <div className="message-data">
                                            {chat.message}
                                            <span className="timestamp">{chat.timestamp}</span>
                                        </div>
                                        {chat.senderName === userData.username && <div className="avatar self">{getAvatar(chat.senderName)}</div>}
                                    </li>
                                ))}
                            </ul>
                            <div className="send-message">
                                <input 
                                    type="text" 
                                    className="input-message" 
                                    placeholder="Enter the message" 
                                    value={userData.message} 
                                    onChange={handleMessage} 
                                    onKeyPress={handleKeyPress} 
                                />
                                <button type="button" className="send-button" onClick={sendValue}>
                                    <i className="fa-regular fa-paper-plane"></i>
                                </button>
                            </div>
                        </div>}
                    </div>
                    :
                    <div className="register">
                        <input
                            id="user-name"
                            placeholder="Enter your name"
                            name="userName"
                            value={userData.username}
                            readOnly
                            margin="normal"
                        />
                        <button type="button" onClick={connect}>Connect</button>
                    </div>}
            </div>
        </div>
    )
}

export default ChatRealTime;
