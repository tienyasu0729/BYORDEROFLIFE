import React, { useEffect, useState } from "react";
import Chart from 'chart.js/auto';
import './Dashboard.css';
import ChatRealTime from '../ChatRealTime/ChatRealTime';
import { f_getAllOrderAdmin_api, f_getReveneu_api, f_getAllProduct_api, f_getAllUser_api, f_getAllOrder_api } from "../../../config/api";
import { toast } from 'react-toastify';
import { NavLink, useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const navigate = useNavigate();
const [totalUsers, setTotalUsers] = useState(0);
  const [totalProducts, setTotalProducts] = useState(0);
  const [adminName, setAdminName] = useState("");
  const [adminAvatar, setAdminAvatar] = useState("");
  const [totalItemsSold, setTotalItemsSold] = useState(0);  
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [totalOrders, setTotalOrders] = useState(0);
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: []
  });
  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('current-account');
    toast.success("Log out successfully");
    navigate("/");
};
  const [timeRange, setTimeRange] = useState("September");

  const formatCurrency = (amount) => {
    const formatter = new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    });
    return formatter.format(amount);
  };

  const fetchTotalRevenue = async () => {
    try {
      const response = await f_getReveneu_api();
      console.log("API Response:", response); // Debugging: Check API response
      if (response.data && response.data.status === "success") {
        setTotalRevenue(response.data.result.totalRevenue);
      } else {
        console.error("Failed to fetch total revenue:", response.data ? response.data.message : "No data");
      }
    } catch (error) {
      console.error("Error fetching total revenue:", error);
    }
  };

  const getAllCart = async () => {
    try {
      const res = await f_getAllOrderAdmin_api();
      console.log("Order API Response:", res); // Debugging: Check API response
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'success') {
        setTotalOrders(res.data.result.length); // Set total orders
      } else {
        toast.error(res.data.message);
      }
    } catch (error) {
      toast.error(error.message);
    }
  };

  const fetchChartData = () => {
    // This is a mock function. Replace it with your actual data fetching logic.
    const labels = [
      "Sept 1",
      "Sept 3",
      "Sept 6",
      "Sept 9",
      "Sept 12",
      "Sept 15",
      "Sept 18",
      "Sept 21",
      "Sept 24",
      "Sept 27",
      "Sept 30",
    ];
    const dataViews = [0, 30, 60, 25, 60, 25, 50, 10, 50, 90, 120];
    const dataWatchTime = [0, 60, 25, 100, 20, 75, 30, 55, 20, 60, 20];
    setChartData({
      labels,
      datasets: [
        {
          label: "Views",
          borderColor: "green",
          backgroundColor: "rgba(235, 247, 245, 0.5)",
          data: dataViews,
        },
        {
          label: "Watch time",
          borderColor: "blue",
          backgroundColor: "rgba(233, 238, 253, 0.5)",
          data: dataWatchTime,
        }
      ]
    });
  };

  const initializeChart = () => {
    Chart.defaults.font.family = "Poppins";
    const ctx = document.querySelector("#revenueChart");
    if (!ctx) return;
    if (ctx.chart) {
      ctx.chart.destroy();
    }
    ctx.chart = new Chart(ctx, {
      type: "line",
      data: chartData,
      options: {
        responsive: true,
        tooltips: {
          intersect: false,
          mode: "index",
        },
      },
    });
  };
  const fetchTotalUsers = async () => {
    try {
      const res = await f_getAllUser_api(0, 1); // Fetch a large number to get all users
      if (res.data.status === 'success') {
        setTotalUsers(res.data.result.totalElements);
      } else {
        console.error(res.data.message);
      }
    } catch (error) {
      console.error(error.message);
    }
  };

  const fetchTotalProducts = async () => {
    try {
      const res = await f_getAllProduct_api(0, 1); // Fetch the first page to get total number of products
      if (res.data.status === 'success') {
        setTotalProducts(res.data.result.totalElements);
      } else {
        console.error(res.data.message);
      }
    } catch (error) {
      console.error(error.message);
    }
  };
  const fetchItemsSold = async () => {
    try {
      const res = await f_getAllOrderAdmin_api(0, 1000); // Fetch all orders or a large number
      if (res.data.status === 'success') {
        const orders = res.data.result.content;
        const totalItemsSold = orders.reduce((acc, order) => acc + order.totalQuantity, 0); // Sum up the quantity of all orders
        setTotalItemsSold(totalItemsSold);
      } else {
        console.error(res.data.message);
      }
    } catch (error) {
      console.error(error.message);
    }
  };
  useEffect(() => {
    fetchTotalRevenue();
    getAllCart();
    fetchChartData();
    fetchTotalUsers();
    fetchTotalProducts();
    fetchItemsSold();
    const currentAccount = JSON.parse(localStorage.getItem('current-account'));
    if (currentAccount && currentAccount.name) {
      setAdminName(currentAccount.name);
    }
    if (currentAccount && currentAccount.avatar) {
      setAdminAvatar(currentAccount.avatar)
    }
  }, []);

  useEffect(() => {
    initializeChart();
  }, [chartData]);

  const handleTimeRangeChange = (event) => {
    setTimeRange(event.target.value);
    // Update chart data based on selected time range
    fetchChartData();
  };

  return (
    <div className="py-5 dashboard-container">
<div className="main-content" style={{paddingLeft:"205px"}}>
          <header>
          <div className="header-wrapper">
            <label htmlFor="menu-toggle">
              <span className="las la-bars"></span>
            </label>
            <div className="header-title">
              <h1>Dashboard</h1>
              <p>
              Electronics Store's Overview <span className="fas fa-chart-line"></span>
              </p>
            </div>
          </div>
          <div className="header-action">
            <button className="btn btn-success" onClick={handleLogout}>
              <span className="fas fa-video"></span>
              Log Out
            </button>
          </div>
        </header>
        <main>
          <section>
            <div className="analytics">
              <div className="analytic">
                <div className="analytic-icon">
                  <span className="fas fa-shopping-cart"></span>
                </div>
                <div className="analytic-info">
                  <h4>Total Orders</h4>
                  <h1>{totalOrders}</h1>
                </div>
              </div>
              <div className="analytic">
                <div className="analytic-icon">
                  <span className="fas fa-sack-dollar"></span>
                </div>
                <div className="analytic-info">
                  <h4>Items Sold</h4>
                  <h1 >
                  {totalItemsSold.toLocaleString()}<small className="text-danger"> items</small>
                  </h1>
                </div>
              </div>
              <div className="analytic">
                <div className="analytic-icon">
                  <span className="fas fa-users"></span>
                </div>
                <div className="analytic-info">
                  <h4>Customers</h4>
                  <h1>
                  {totalUsers.toLocaleString()} <small className="text-success">12%</small>
                  </h1>
                </div>
              </div>
              <div className="analytic">
                <div className="analytic-icon">
                  <span className="fas fa-box"></span>
                </div>
                <div className="analytic-info">
                  <h4>Total Product</h4>
                  <h1>{totalProducts.toLocaleString()}<small style={{color:"#6883db"}}> products</small></h1>                </div>
              </div>
            </div>
          </section>
          <section style={{width:"96%"}}>
              <div className="block-grid">
              <div className="revenue-card">
                <h3 className="section-head">Total Revenue</h3>
                <div className="rev-content">
                  {/* <img>{adminAvatar}</img> */}
                  <div className="rev-info">
                    <h3>{adminName}</h3>
                    {/* <h1>
                    {totalUsers.toLocaleString()} <small>Users</small>
                    </h1> */}
                  </div>
                  <div className="rev-sum">
                    <h4>Total income</h4>
                    <h2 style={{color:"green", paddingLeft:"0px"}}>{formatCurrency(totalRevenue)}</h2> 
                   </div>
                </div>
              </div>
              <div className="graph-card">
                <h3 className="section-head">Graph</h3>
                <div className="graph-content">
                  <div className="graph-head">
                    <div className="icon-wrapper">
                      <div className="icon">
                        <span className="las la-eye text-main"></span>
                      </div>
                      <div className="icon">
                        <span className="las la-clock text-success"></span>
                      </div>
                    </div>
                    <div className="graph-select">
                      <select name="" id="" value={timeRange} onChange={handleTimeRangeChange}>
                        <option value="September">September</option>
                        <option value="October">October</option>
                        <option value="Last 7 Days">Last 7 Days</option>
                        <option value="Last 30 Days">Last 30 Days</option>
                      </select>
                    </div>
                  </div>
                  <div className="graph-board">
                    <canvas id="revenueChart" width="100%"></canvas>
                  </div>
                </div>
              </div>
            </div>
            <ChatRealTime/>
          </section>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
