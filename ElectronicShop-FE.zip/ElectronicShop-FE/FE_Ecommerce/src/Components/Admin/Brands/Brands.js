import React, { useEffect, useState } from "react";
import Sidebar from "../SideBar/SideBar";
import { TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import { Button, Modal, Table } from "react-bootstrap";
import { f_addBrand_api, f_deleteBrand_api, f_getAllBrands_api, f_updateBrand_api } from "../../../config/api";
import { toast } from "react-toastify";
import "./Brand.css"

const Brands = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [listBrands, setListBrands] = useState([]);
  const [selectedBrandId, setSelectedBrandId] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const [nameBrand,setNameBrand] = useState('');
  const [slugBrand, setSlugBrand] = useState('');
  const [statusBrand, setStatusBrand] = useState('Active');
  const [brandUpdate, setBrandUpdate] = useState({
    nameBrand: '',
    slugBrand: '',
    statusBrand: '',
  })

    // common
    const makeStyle=(status)=>{
        if(status === 'Active')
        {
          return {
            background: '#7CFC00',
            color: 'black',
          }
        }
        else if(status === 'Inactive')
        {
          return{
            background: '#C0C0C0',
            color: 'black',
          }
        }
      }

    // get list brands
    const getListBrand = async() =>{
        setIsLoading(true)
        try {
            const res = await f_getAllBrands_api();
            if(res.data.status === " not found"){
                toast.warning(res.data.message)
            }else if(res.data.status === "success"){
                setListBrands(res.data.result)
            }
        } catch (error) {
            toast.error(error.message)
        }finally{
            setIsLoading(false)
        }
    }
    useEffect(()=>{
        getListBrand()
    },[])


    // add brands
    const openModel = () =>{
        setShowAddModal(true)
    }

    const closeModel = () =>{
        setNameBrand("")
        setSlugBrand("")
        setStatusBrand("Active")
        setShowAddModal(false);
    }
    const handleAdd = async() =>{
        if(!nameBrand || !slugBrand){
            toast.warning("Please enter name and slug brand")
            return;
        }
        setIsLoading(true)
        try {
            const res = await f_addBrand_api(nameBrand, slugBrand, statusBrand);
            if(res.data.status === 'error'){
                toast.error(res.data.message)
            }else if(res.data.status === 'success'){
                toast.success(res.data.message)
            }
        } catch (error) {
            toast.error(error.message)
        }finally{
            setNameBrand("")
            setSlugBrand("")
            setStatusBrand("Active")
            getListBrand();
            setIsLoading(false)
            setShowAddModal(false)
        }
    }

    // update brands
    const handleUpdate = (id) => {
        setSelectedBrandId(id)
        const brandUpdate = listBrands.find((brand) => brand.id === id);
            setBrandUpdate({
                nameBrand: brandUpdate.nameBrand,
                slugBrand: brandUpdate.slugBrand,
                status: brandUpdate.statusBrand,
            });
        setShowUpdateModal(true);
    }

    const handCancelUpdate = () =>{
        setShowUpdateModal(false);
    }

    const handConfirmUpdateBrands = async() =>{
        if(!brandUpdate.nameBrand || !brandUpdate.slugBrand){
            toast.warning("Please enter name and slug brand")
            return
        }
        setIsLoading(true)
        try {
            const res = await f_updateBrand_api(selectedBrandId, brandUpdate.nameBrand, brandUpdate.slugBrand, brandUpdate.statusBrand)
            if(res.data.status === 'error'){
                toast.error(res.data.message)
            }else if(res.data.status === "success"){
                toast.success(res.data.message)
            }
        } catch (error) {
            toast.error(error.message)
        }finally{
            setIsLoading(false)
            setShowUpdateModal(false)
            getListBrand()
        }
    }
 
    


    // delete brands
    const handleDelete = (id) =>{
        setSelectedBrandId(id);
        setShowDeleteModal(true);
    }

    const handleCancel = () => {
        setShowDeleteModal(false);
    }
    const handConfirmDeleteBrands = async() =>{
        setIsLoading(true)
        try {
            const res = await f_deleteBrand_api(selectedBrandId);
            if(res.data.status === 'error'){
                toast.error(res.data.message)
            }else if (res.data.status === 'not found'){
                toast.warning(res.data.message)
            }else if(res.data.status === 'success'){
                toast.success(res.data.message)
            }
        } catch (error) {
            toast.error(error.message)
        }finally{
            setIsLoading(false)
            setShowDeleteModal(false)
            getListBrand();
        }
    }
   
  return (
    <div className="admin">
      <div className="adminGlass" style={{ minHeight: "100vh" }}>
        <Sidebar />
        <div className="py-5" style={{paddingLeft:"205px", width:"100vw"}}>
                    <div className="d-flex justify-content-between">
            <div className="py-2">
              <h3>Brands</h3>
            </div>
            <div className="py-2">
            <button className="btn btn-info" style={{ margin:"0 30px" }} onClick={openModel}>Add New Brands <i style={{ color: "white" }} className="fa-solid fa-circle-plus fa-spin"></i></button>            </div>
          </div>
          <TableContainer
            style={{
              boxShadow: "0px 13px 20px 0px #80808029",
              borderRadius: "20px",
              width: "98%",
              backgroundColor: "#F0FFF0",
            }}
          >
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead style={{backgroundColor:"#ff9200"}}>
                              <TableRow>
                    <TableCell align="left">No. </TableCell>
                    <TableCell align="left">Name</TableCell>
                    <TableCell align="left">Slug</TableCell>
                    <TableCell align="left">Status</TableCell>
                    <TableCell align="center">Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody style={{ color: "white" }}>
                {isLoading ? (
                    <TableRow className="d-flex justify-content-center">
                        <TableCell colSpan={8} align="center" >
                            <div className="custom-loader"></div>
                        </TableCell>
                    </TableRow>
                ) : listBrands && listBrands.length === 0 ?(
                    <TableRow>
                        <TableCell colSpan={8} align="center">No data</TableCell>
                    </TableRow>
                ) :(
                    listBrands && listBrands.map((brands, index) =>(
                        <TableRow
                        key={brands.id}
                        sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                      >
                      <TableCell  scope="row" style={{verticalAlign: "middle", paddingLeft:"25px"}}>
                      {index + 1}
                        </TableCell>
                        <TableCell align="left" style={{verticalAlign: "middle"}}>{brands.nameBrand}</TableCell>
                        <TableCell align="left" style={{verticalAlign: "middle"}}>{brands.slugBrand}</TableCell>
                        <TableCell align="left" style={{verticalAlign: "middle"}}>
                          <span className="status" style={makeStyle(brands.status)}>{brands.status}</span>
                        </TableCell>
                        <TableCell align="left" style={{justifyContent:"center"}} className="Details d-flex">
                          <div>
                              <button className="btn btn-primary" onClick={() => handleUpdate(brands.id)}>Update</button>
                          </div>
                          <div className="mx-3">
                              <button className="btn btn-danger" onClick={() => handleDelete(brands.id)}>Delete</button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
              {showAddModal && (
                  <Modal show={showAddModal} onHide={closeModel}>
                  <Modal.Header closeButton >
                    <Modal.Title>Create Brand</Modal.Title>
                  </Modal.Header>
                  <div className="d-flex">
                    <div className="inputGroup1 py-3 col-md-6">
                      <label htmlFor="nameCate">Name Brand<span className="text-danger" style={{fontSize: "15px", fontWeight:"bolder"}}>*</span></label>
                      <input 
                      class= "input-category" 
                      value={nameBrand} 
                      onChange={(e) => setNameBrand(e.target.value)} 
                      name="text" 
                      id="nameCate" 
                      placeholder="Acer...." 
                      type="text"/>
                    </div>
                    <div className="inputGroup1 py-3 col-md-6">
                      <label htmlFor="slugCate">Slug Brand<span className="text-danger" style={{fontSize: "15px", fontWeight:"bolder"}}>*</span></label>
                      <input 
                      class="input-category" 
                      name="text" 
                      id="slugCate" 
                      placeholder="ACER..." 
                      value={slugBrand}
                      onChange={(e) => setSlugBrand(e.target.value)}
                      type="search"
                      />
                    </div>
                  </div>
                  <div className="inputGroup1 py-3 col-md-12 d-flex flex-column">
                    <label>Status<span className="text-danger" style={{fontSize: "15px", fontWeight:"bolder"}}>*</span></label>
                        <select
                            id="gender"
                            value={statusBrand}
                            onChange={(e) => setStatusBrand(e.target.value)}
                            className="form-control"
                        >
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                  </div> 
                  <Modal.Footer>
                    <Button variant="secondary" onClick={closeModel}>
                      Cancel
                    </Button>
                    <Button variant="danger" onClick={handleAdd}>
                      Create
                    </Button>
                  </Modal.Footer>
                </Modal>
                )}
              {showDeleteModal && (
                  <Modal show={showDeleteModal} onHide={handleCancel}>
                  <Modal.Header closeButton >
                    <Modal.Title>Confirm Delete Brand</Modal.Title>
                  </Modal.Header>
                    <div className="py-3 text-center">
                        Are you sure you want to delete ?
                    </div>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handleCancel}>
                      Cancel
                    </Button>
                    <Button variant="danger" onClick={handConfirmDeleteBrands}>
                      Delete
                    </Button>
                  </Modal.Footer>
                </Modal>
                )}
                {showUpdateModal && (
                  <Modal show={showUpdateModal} onHide={handCancelUpdate}>
                  <Modal.Header closeButton >
                    <Modal.Title>Update Brand</Modal.Title>
                  </Modal.Header>
                  <div className="d-flex">
                    <div className="inputGroup1 py-3 col-md-6">
                      <label htmlFor="nameCate">Name Brand<span className="text-danger" style={{fontSize: "15px", fontWeight:"bolder"}}>*</span></label>
                      <input 
                      class= "input-category" 
                      value={brandUpdate.nameBrand}
                      onChange={(e) => setBrandUpdate((prevData)=> ({...prevData, nameBrand: e.target.value}))} 
                      name="text" 
                      id="nameCate" 
                      placeholder="Jeans...." 
                      type="text"/>
                    </div>
                    <div className="inputGroup1 py-3 col-md-6">
                      <label htmlFor="slugCate">Slug Brand<span className="text-danger" style={{fontSize: "15px", fontWeight:"bolder"}}>*</span></label>
                      <input 
                      class="input-category" 
                      name="text" 
                      id="slugCate" 
                      placeholder="JEANS..." 
                      value={brandUpdate.slugBrand}
                      onChange={(e) => setBrandUpdate((prevData)=> ({...prevData, slugBrand: e.target.value}))}
                      type="text"
                      />
                    </div>
                  </div>
                  <div className="inputGroup1 py-3 col-md-12 d-flex flex-column">
                    <label>Status<span className="text-danger" style={{fontSize: "15px", fontWeight:"bolder"}}>*</span></label>
                        <select
                            id="gender"
                            value={brandUpdate.statusBrand}
                            onChange={(e) => setBrandUpdate((prevData)=> ({...prevData, statusBrand: e.target.value}))}
                            className="form-control"
                        >
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                  </div> 
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handCancelUpdate}>
                      Cancel
                    </Button>
                    <Button variant="danger" onClick={handConfirmUpdateBrands}>
                      Update
                    </Button>
                  </Modal.Footer>
                </Modal>
                )}
            </Table>
          </TableContainer>
        </div>
      </div>
    </div>
  );
};

export default Brands;
