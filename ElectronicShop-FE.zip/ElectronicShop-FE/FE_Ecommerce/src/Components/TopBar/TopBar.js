import React, { useState, useEffect, useRef } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { f_getAllProduct_api,f_getDetaiAccout_api } from '../../config/api';
import "./Topbar.css";

const TopBar = () => {
    const token = localStorage.getItem('token');
    const currentAccount = JSON.parse(localStorage.getItem('current-account'));
    const [query, setQuery] = useState('');
    const [avatar, setAvatar] = useState(null);
    const [searchResults, setSearchResults] = useState([]);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const navigate = useNavigate();
    const searchRef = useRef();

    useEffect(() => {
        fetchUserAvatar();
        document.addEventListener('click', handleClickOutside, true);
        return () => {
            document.removeEventListener('click', handleClickOutside, true);
        };
    }, []);

    const fetchUserAvatar = async () => {
        try {
            const response = await f_getDetaiAccout_api();
            if (response.data.status === 'success' && response.data.result.length > 0) {
                const userAvatar = response.data.result[0].avatar;
                setAvatar(userAvatar);
            } else {
                console.error('Failed to fetch user avatar');
            }
        } catch (error) {
            console.error('Error fetching user avatar:', error);
        }
    };

    const handleInputChange = async (event) => {
        setQuery(event.target.value);
        if (event.target.value === '') {
            setSearchResults([]);
            return;
        }

        try {
            const response = await f_getAllProduct_api();
            if (response.data.status === 'success') {
                const filteredProducts = response.data.result.content.filter(product =>
                    product.name.toLowerCase().includes(event.target.value.toLowerCase())
                );
                setSearchResults(filteredProducts);
            } else {
                console.error('Lỗi khi tìm kiếm sản phẩm:', response.data.message);
            }
        } catch (error) {
            console.error('Lỗi khi tìm kiếm sản phẩm:', error.message);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('current-account');
        toast.success("Log out successfully");
        navigate("/");
    };

    const checkRole = (role) => {
        if (currentAccount && currentAccount.authority.includes("ROLE_ADMIN")) {
            return true;
        }
        return false;
    };

    const handleClickOutside = (event) => {
        if (searchRef.current && !searchRef.current.contains(event.target)) {
            setSearchResults([]);
        }
    };

    return (
        <div className="container-fluid">
            <div className="row py-1 px-xl-5" style={{ backgroundColor: "#0d0d0d" }}>
                <div className="col-lg-6 d-none d-lg-block">
                    <div className="d-inline-flex align-items-center h-100">
                        <NavLink className="text-body" to="/about" style={{ color: "#6C757D", marginRight: "1rem", textDecoration: "none" }}>About</NavLink>
                        <NavLink className="text-body" to="/contact" style={{ color: "#6C757D", marginRight: "1rem", textDecoration: "none" }}>Contact</NavLink>
                        {checkRole('ROLE_ADMIN') && (
                            <NavLink className="text-body" to="/admin-page" style={{ color: "#6C757D", marginRight: "1rem", textDecoration: "none" }}>Admin</NavLink>
                        )}
                    </div>
                </div>
                <div className="col-lg-6 text-center text-lg-right">
                    <div className="d-inline-flex align-items-center">
                        {token ? (
                            <div className="btn-group d-flex align-items-center flex-row">
                                <div 
                                    className="nav-link text-dark text-uppercase text-body profile-container"
                                    onMouseEnter={() => setIsDropdownOpen(true)}
                                    onMouseLeave={() => setIsDropdownOpen(false)}
                                >
                                    {currentAccount ? (
                                        <>
                                            <span>Hello, {currentAccount.name}</span>
                                            {avatar && (
                                                <img
                                                    src={avatar}
                                                    alt="avatar"
                                                    style={{ 
                                                        width: "35px",
                                                        height: "35px",
                                                        borderRadius: "50%",
                                                        objectFit: "cover",
                                                        marginLeft: "0.5rem"
                                                    }}
                                                    className='img-avatar mx-1'
                                                />
                                            )}
                                        </>
                                    ) : (
                                        'User Account'
                                    )}
                                    {isDropdownOpen && (
                                        <div className="dropdown-menu">
                                            <NavLink to="/account" className="dropdown-item">Account</NavLink>
                                            <button className="dropdown-item" onClick={handleLogout}>Logout</button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ) : (
                            <div className="btn-group">
                                <NavLink className="dropdown-item text-body" type="button" style={{ outline: "none" }} to='/login'>Sign in</NavLink>
                                <NavLink className="dropdown-item text-body" type="button" style={{ outline: "none" }} to='/register'>Sign up</NavLink>
                            </div>
                        )}
                    </div>
                    <div className="d-inline-flex align-items-center d-block d-lg-none">
                        <NavLink to="/cart" className="btn px-0 ml-2">
                            <i className="fas fa-shopping-cart text-dark"></i>
                            <span className="badge text-dark border border-dark rounded-circle" style={{ paddingBottom: "2px" }}>0</span>
                        </NavLink>
                    </div>
                </div>
            </div>
            <div className="row align-items-center py-3 px-xl-5 d-none d-lg-flex" style={{ backgroundColor: "#0d0d0d" }}>
                <div className="col-lg-4">
                    <NavLink to="/" className="text-decoration-none">
                        <span className="h1 text-uppercase text-primary bg-dark px-2" style={{ userSelect: "none" }}>E</span>
                        <span className="h1 text-uppercase text-dark bg-primary px-2 ml-n1" style={{ userSelect: "none" }}>Store</span>
                    </NavLink>
                </div>
                <div className="col-lg-4 col-6 text-left">
                    <div className="search" ref={searchRef}>
                        <input
                            type="text"
                            className="form-control search-input"
                            placeholder="Search for products"
                            onChange={handleInputChange}
                            value={query}
                        />
                        {searchResults.length > 0 && (
                            <div className="search-result">
                                <ul>
                                    {searchResults.map((result) => (
                                        <li key={result.id}>
                                            <NavLink to={`/product-detail/${result.id}`}>
                                                <img src={result.image} alt={result.name} />
                                                <div className="product-info">
                                                    <span className="product-name">{result.name}</span>
                                                </div>
                                            </NavLink>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                </div>
                <div className="col-lg-4 col-6 text-right text-body">
                    <p className="m-0">Customer Service</p>
                    <h6 className="m-0">+84 32 655 8386</h6>
                </div>
            </div>
        </div>
    );
};

export default TopBar;
