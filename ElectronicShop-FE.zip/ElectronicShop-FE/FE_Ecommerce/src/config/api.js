import axios from "./customAxios";


const f_regiter_api = (name, email, password) => {
  return axios.post("account/register", {
    name: name,
    email: email,
    password: password,
  });
};

const f_login_api = (email, password) => {
  return axios.post("account/login", { email: email, password: password });
};

const f_getAllUser_api = (page, size) => {
  return axios.get(`/account/get-all-user?page=${page}&size=${size}`);
};
const f_updateUser_api = (id, name,address, password,tel,gender,dob,avatar) => {
  return axios.put(`account/update-account/${id}`, {
    name: name,
    address: address,
    tel: tel,
    gender: gender,
    dob: dob,
    avatar: avatar,
    password: password,
  });
};
const f_deleteUser_api = (id) => {
  return axios.delete(`/account/delete-user/${id}`);
};


// const f_updateRole_api = (id) => {
//   return axios.post(`/account/update-admin/${id}`);
// };

const f_changePassword_api = (oldPass, newPass, rePass) =>{
  return axios.post("account/change-password", { oldPass: oldPass, newPass: newPass, rePass: rePass})
}


const f_getAllCategory_api = () => {
  return axios.get("/categories/get-all-category");
};

const f_deleteCategory_api = (id) => {
  return axios.delete(`/categories/delete-category/${id}`);
};

const f_getAllBrands_api = () => {
  return axios.get("/brands/get-all-brands");
}

const f_addBrand_api = (nameBrand, slugBrand, status) =>{
  return axios.post("/brands/create-brands", {nameBrand: nameBrand, slugBrand: slugBrand, status: status})
}

const f_deleteBrand_api = (id) =>{
  return axios.delete(`brands/delete-brand/${id}`)
}
const f_updateBrand_api = (id, nameBrand, slugBrand, status) =>{
  return axios.put(`/brands/update-brand/${id}`, {nameBrand: nameBrand, slugBrand: slugBrand, status: status})
}

const f_getAllProduct_api = (page, size) => {
  return axios.get(`/product/get-all-product?page=${page}&size=${size}`)
}

const f_getAllProductId_api = (id) => {
  return axios.get(`/product/get-product-id/${id}`)
}

const f_deleteProduct_api = (id) =>{
  return axios.delete(`/product/delete-product/${id}`)
}

const f_getCartItem_api = () =>{
  return axios.get("/carts/get-all-carts")
}
const f_deleteCartItem_api = (id) =>{
  return axios.delete(`/carts/delete-cart/${id}`)
}

const f_getCartItemByUser_api = () =>{
  return axios.get("/carts/get-wish-list")
}
const f_updateStatus_api = (id, status) =>{
  return axios.put(`/orders/update-order/${id}`, {status: status})
}

const f_getCartItemPurchased_api = () =>{
  return axios.get("/order/get-order-delivered")
}
const f_getCartItemCancel_api = () =>{
  return axios.get("/order/get-order-canceled")
}
const f_getCartItemShipping_api = () =>{
  return axios.get("/order/get-order-shipping")
}
const f_getCartItemComfirmed_api = () =>{
  return axios.get("/order/get-order-confirmed")
}
const f_getCartItempProcessing_api = () =>{
  return axios.get("/order/get-order-processing")
}
const f_getAllOrder_api = () =>{
  return axios.get(`/orders/get-all-orders`)
}
const f_getAllOrderAdmin_api = () =>{
  return axios.get(`/orders/get-all-orders`)
}
const f_getAllSize_api = () =>{
  return axios.get(`/sizes/get-all-size`)
}
const f_getAllColor_api = () =>{
  return axios.get(`/colors/get-all-colors`)
}

const f_order_api = (user_id, product_id, wishListID, quantity) =>{
  return axios.post("/order/create-order", {user_id: user_id, products_id: product_id, wishlist_id: wishListID, quantity: quantity})
}
const f_getWishlistItem_api = () =>{
  return axios.get("/wishlists/get-all-wishlists")
}//lấy hết iteam
const f_deleteWishlist_api = (id) =>{
  return axios.delete(`/wishlists/delete-wishlist/${id}`)
}
const f_getAllReviewByProduct_api =(id) =>{
    return axios.get(`/reviews/get-all-reviews-by-product/${id}`)
}//lấy review by product ID
const f_getAllReviewByUser_api =() =>{
  return axios.get(`/reviews/get-all-reviews-by-user`)
}//lấy review by user ID
const f_deleteReview_api = (id) =>{
  return axios.delete(`/reviews/delete-review${id}`)
}//xóa review của mình đã cmt

const f_getAllOrderdetaillByOrderID_api =(id) =>{
  return axios.get(`/order-details/get-order-details-by-order/${id}`)
}
const f_getAllOderByUser_api =() =>{
  return axios.get(`/orders/get-orders-by-user`)
}//lấy order by user ID xác thực bằng token lưu ở local store
const f_deleteAllCartByUser_api =() =>{
  return axios.delete(`/carts/delete-all-cart`)
}//lấy order by user ID xác thực bằng token lưu ở local store
const f_getDetaiAccout_api =() =>{
  return axios.get(`/account/get-all-info`)
}//lấy thông tin accout
const f_getCupon_api =() =>{
  return axios.get(`/coupons/get-all-coupons`)
}//lấy thông tin accout
const f_getProduct_popular_api =() =>{
  return axios.get(`/product/get-all-product-popular`)
}//lấy thông tin accout
const f_getReveneu_api =() =>{
  return axios.get(`/order-details/get-reveneu`)
}//lấy thông tin accout
const f_updateCoupon_api = (id, couponData, config) => {
  return axios.put(`/coupons/update-coupon/${id}`, couponData, config);
};

const f_deleteCoupon_api = (id, config) => {
  return axios.delete(`/coupons/delete-coupon/${id}`, config);
};
const f_forgotPassword_api = (email) =>{
  return axios.post("/account/forgot-password", {email: email})
}

const f_resetPassword_api = (token, password, rePassword) => {
  return axios.post("/account/reset-password", {token: token, password: password, rePassword: rePassword})
}

export {
  f_regiter_api,
  f_login_api,
  f_getAllUser_api,
  f_deleteUser_api,
  f_changePassword_api,
  f_getAllCategory_api,
  f_deleteCategory_api,
  f_getAllBrands_api,
  f_addBrand_api,
  f_deleteBrand_api,
  f_updateBrand_api,
  f_getAllProduct_api,
  f_getAllProductId_api,
  f_deleteProduct_api,
  f_getCartItem_api,
  f_deleteCartItem_api,
  f_getCartItemByUser_api,
  f_getAllOrder_api,
  f_updateStatus_api,
  f_order_api,
  f_getCartItemPurchased_api,
  f_getCartItemCancel_api,
  f_getCartItemShipping_api,
  f_getAllSize_api,
  f_getAllColor_api,
  f_getCartItemComfirmed_api,
  f_getCartItempProcessing_api,
  f_deleteWishlist_api,
  f_getWishlistItem_api,
  f_getAllReviewByProduct_api,
  f_getAllReviewByUser_api,
  f_deleteReview_api,
  f_getAllOrderAdmin_api,
  f_getAllOrderdetaillByOrderID_api,
  f_getAllOderByUser_api,
  f_deleteAllCartByUser_api,
  f_getDetaiAccout_api,
  f_getCupon_api,
  f_getProduct_popular_api,
  f_getReveneu_api,
  f_deleteCoupon_api,
  f_updateCoupon_api,
  f_forgotPassword_api,
  f_resetPassword_api

};
