import React, { useState } from 'react';
import { Modal, Button } from 'react-bootstrap';
import { toast } from 'react-toastify';
import axios from "../../config/customAxios";


function ForgotPassword({ show, handleClose:propHandleClose }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleClose = () => {
    setEmail(''); 
    propHandleClose();
  };

  const handleForgotPassword = async (e) => {
    e.preventDefault();
    if (!email) {
      toast.warning("Please enter your email");
      return;
    }
    setLoading(true);
    try {
      const res = await axios.post('/account/forgot-password', { email });
      if (res.data.status === 'success') {
        toast.success("Password reset instructions sent to your email!");
        handleClose(); 
      } else {
        toast.error(res.data.message || "Failed to send reset instructions");
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
  <Modal show={show} onHide={handleClose}>
    <Modal.Header>
      <Modal.Title>Forgot Password</Modal.Title>
      <Button variant="secondary" onClick={handleClose} style={{ position: 'absolute', top: '10px', right: '10px' }}>
        x
      </Button>
    </Modal.Header>
    <Modal.Body>
      <form onSubmit={handleForgotPassword}>
        <div className="flex-container">
          <div className="input-div one focus">
            <div className="div">
              <h5>Email</h5>
              <input
                type="email"
                className="input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>
          <Button variant="primary" type="submit" disabled={loading}>
            Send Reset Request
          </Button>
        </div>
      </form>
    </Modal.Body>
  </Modal>
  );
}
export default ForgotPassword;