import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { toast } from 'react-toastify';
import axios from "../../config/customAxios";
import wave from '../../assets/IMG/wave.png';
import bg from '../../assets/IMG/bg.svg';
import logo from '../../assets/IMG/LOGO.png';

function ResetPassword() {
  const [password, setPassword] = useState('');
  const [rePassword, setRePassword] = useState('');
  const [token, setToken] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const tokenFromUrl = params.get('token');
    if (tokenFromUrl) {
      setToken(tokenFromUrl);
    }
  }, [location]);

  const handleResetPassword = async (e) => {
    e.preventDefault();
    if (!password || !rePassword) {
      toast.warning("Please fill in all fields");
      return;
    }
    if (password !== rePassword) {
      toast.error("Passwords do not match");
      return;
    }
    if (password.length < 8) {
      toast.error("Password must be at least 8 characters long");
      return;
    }
    setLoading(true);
    try {
      const res = await axios.post('/account/reset-password', { token, password, rePassword });
      if (res.data.status === 'success') {
        toast.success("Password reset successful!");
        navigate('/login');
      } else {
        toast.error(res.data.message || "Reset password failed");
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-login">
      <img className="wave" src={wave} alt="Wave" />
      <div className="img">
        <img src={bg} alt="Background" />
      </div>
      <div className="login-content">
        <div className="login-form">
          <form onSubmit={handleResetPassword}>
            <NavLink className="nav-link text-center link-login fadeInUp" to="/">
              <img src={logo} alt="Avatar" />
            </NavLink>
            <div className="input-div fadeInUp pass focus">
              <div className="i">
                <i className="fas fa-lock"></i>
              </div>
              <div className="div">
                <h5>New Password</h5>
                <input
                  type="password"
                  className="input"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={8}
                />
              </div>
            </div>
            <div className="input-div fadeInUp pass focus">
              <div className="i">
                <i className="fas fa-lock"></i>
              </div>
              <div className="div">
                <h5>Confirm New Password</h5>
                <input
                  type="password"
                  className="input"
                  value={rePassword}
                  onChange={(e) => setRePassword(e.target.value)}
                  required
                />
              </div>
            </div>
            <button type="submit" className="btn-login fadeInUp" disabled={loading}>
              Reset Password &nbsp;
              {loading ? (
                <i className="fa-solid fa-spinner fa-spin-pulse fa-spin-reverse"></i>
              ) : (
                <i className="fa-solid fa-right-to-bracket"></i>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ResetPassword;