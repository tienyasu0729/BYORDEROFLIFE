import React, { useEffect, useState } from "react";
import "./about.css";
import { Link, useNavigate } from "react-router-dom";
const About = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    const currentAccount = JSON.parse(localStorage.getItem('current-account'));

    if (!token) {
      navigate('/login');
    } else if (currentAccount && currentAccount.authority.includes("ROLE_ADMIN")) {
      navigate('/admin-page');
    }else{
        navigate('/');
    }
  }, [navigate]);
  return (
    <div className="about-page" style={{backgroundColor: "#1a1a1a"}}>
      <div className="about-page" style={{ backgroundColor: "#1a1a1a" }}>
  <div className="about-header">
    <h1 className="about-title" style={{color: "#ffffff"}}>About Us</h1>
    <nav className="breadcrumbx">
      <a href="http://localhost:3000/" className="breadcrumbx-item" style={{ color: "#1a1a1a", textDecoration: "none" }}>
        Home
      </a>
      <span className="breadcrumbx-item active" style={{ color: "#1a1a1a" }}>
        | About Us
      </span>
    </nav>
  </div>
</div>

      <div className="about-content">
        <div className="container">
          <div className="row">
            <div className="col-lg-6" style={{color:"#F5F5F5"}}>
              <h7 className="about-subtitle">Who We Are</h7>
              <p className="about-text">Welcome to E_SHOP! We are more than just an online tech store; we are a community of tech enthusiasts dedicated to providing you with the ultimate shopping experience.</p>
              <p className="about-text">Our journey began with a simple vision: to revolutionize the way people shop for technology online. We believe that tech shopping should be convenient, enjoyable, and hassle-free. That's why we've built E_SHOP to offer a wide range of products, from the latest gadgets and cutting-edge electronics to essential tech accessories, all in one place.</p>
              <p className="about-text">At E_SHOP, we are committed to quality. We meticulously select each product to ensure it meets our high standards of excellence. Whether you're looking for the newest smartphones, advanced laptops, innovative smart home devices, or must-have accessories, you can trust that you'll find only the best at E_SHOP.</p>
              <p className="about-text">But we're more than just a retailer; we're your partners in technology. Our dedicated team is here to assist you every step of the way, from helping you find the perfect product to providing expert advice and support after your purchase. Thank you for choosing E_SHOP. We're excited to embark on this journey with you and to redefine the way you shop for technology online.</p>
            </div>
            <div className="col-lg-6">
              <img className="about-image img-fluid h-100" src="https://i.pinimg.com/originals/5f/b4/7a/5fb47a2efba55db091f11429b5d84a41.jpg" alt="About Us" />
            </div>
          </div>

        </div>
      </div>
      <div className="services-section">
        <div className="container">
          <div className="row">
            <div className="col-md-4">
              <div className="service-block" style={{backgroundColor: "#262626", color:"#F5F5F5"}}>
                <h3 className="service-title" style={{color:"#F5F5F5"}}>Trusted</h3>
                <p className="service-description">We strive to build trust with our customers by delivering reliable products and services.</p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="service-block" style={{backgroundColor: "#262626", color:"#F5F5F5"}}>
                <h3 className="service-title"style={{color:"#F5F5F5"}}>Professional</h3>
                <p className="service-description">Our team consists of experienced professionals dedicated to providing you with expert guidance and support.</p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="service-block" style={{backgroundColor: "#262626", color:"#F5F5F5"}}>
                <h3 className="service-title"style={{color:"#F5F5F5"}}>Expert</h3>
                <p className="service-description">We offer expert advice and assistance to help you make informed decisions about your purchases.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
