import React, { useEffect, useState } from "react";
import { Carousel } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import {
  f_getAllCategory_api,
  f_getAllProduct_api,
  f_getAllReviewByProduct_api,
  f_getProduct_popular_api,
} from "../../config/api";
import { toast } from "react-toastify";
import { formatCurrency } from "../../Validate/Validate";
import axios from "../../config/customAxios";
import "react-multi-carousel/lib/styles.css";
import "./home.css";
import CustomerChat from "../ChatCustomer/CustomerChat";
import MultiCarousel from "react-multi-carousel";

const Home = () => {
  const [index, setIndex] = useState(0);
  const [listCategories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [products, setProducts] = useState([]);
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [carouselItems, setCarouselItems] = useState([]);
  const token = localStorage.getItem("token");

  useEffect(() => {
    getListCategories();
    getAllProducts();
    loadCarouselItems();
    loadFeaturedProducts();
  }, []);

  const getListCategories = async () => {
    setIsLoading(true);
    try {
      const res = await f_getAllCategory_api();
      if (res.data.status === "not found") {
        toast.warning(res.data.message);
      } else if (res.data.status === "success") {
        setCategories(res.data.result);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const getAllProducts = async (pageNumber = 0, size = 12) => {
    setIsLoading(true);
    try {
      const res = await f_getAllProduct_api(pageNumber, size);
      if (res.data.status === "not found") {
        toast.warning(res.data.message);
      } else if (res.data.status === "error") {
        toast.error(res.data.message);
      } else if (res.data.status === "success") {
        const productsWithReviews = await Promise.all(
          res.data.result.content.map(async (product) => {
            const reviewsResponse = await f_getAllReviewByProduct_api(
              product.id
            );
            if (reviewsResponse.data.status === "success") {
              const reviews = reviewsResponse.data.result;
              const totalReviews = reviews.length;
              const averageRating =
                totalReviews > 0
                  ? Math.floor(
                      reviews.reduce((acc, review) => acc + review.rating, 0) /
                        totalReviews
                    )
                  : 0;
              return { ...product, totalReviews, averageRating };
            } else {
              return { ...product, totalReviews: 0, averageRating: 0 };
            }
          })
        );
        const sortedProducts = productsWithReviews
          .sort((a, b) => b.id - a.id)
          .slice(0, 8);
        setProducts(sortedProducts);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const loadFeaturedProducts = async () => {
    setIsLoading(true);
    try {
      const res = await f_getProduct_popular_api();
      if (res.data.status === "success") {
        setFeaturedProducts(res.data.result);
      } else {
        toast.warning(res.data.message);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const loadCarouselItems = () => {
    const items = [
      {
        img: "https://storage-asset.msi.com/global/picture/banner/banner_1695693289ebeb1f0bb341626b2d0bf870d3cb9254.jpeg",
        alt: "Laptops",
        title: "Laptops",
        description:
          "Lorem rebum magna amet lorem magna erat diam stet. Sadips duo stet amet amet ndiam elitr ipsum diam",
        link: "/list-product",
      },
      {
        img: "https://dlcdnwebimgs.asus.com/gain/42D19EB1-BCC0-4497-A128-FC9193764AC0/w2560/h777//fwebp",
        alt: "Phone",
        title: "Smart Phones",
        description:
          "Lorem rebum magna amet lorem magna erat diam stet. Sadips duo stet amet amet ndiam elitr ipsum diam",
        link: "/list-product",
      },
      {
        img: "https://akkogear.com.vn/wp-content/uploads/2024/04/MOD007v3-HE-Dragon.png",
        alt: "keybroad",
        title: "Key Broad",
        description:
          "Lorem rebum magna amet lorem magna erat diam stet. Sadips duo stet amet amet ndiam elitr ipsum diam",
        link: "/list-product",
      },
    ];
    setCarouselItems(items);
  };

  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };

  const handleAddToWishlist = async (productId, price) => {
    if (!token) {
      toast.error("Bạn cần đăng nhập để thêm sản phẩm vào danh sách yêu thích", {
        position: toast.POSITION.TOP_CENTER,
        autoClose: 2000,
      });
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost:8080/api/wishlists/create-wishlist",
        {
          productId,
          price,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.data.status === "success") {
        if (response.data.message === "Đã Có Trong Wishlist") {
          toast.warning(response.data.message, {
            position: toast.POSITION.TOP_CENTER,
            autoClose: 2000,
          });
        } else {
          toast.success("Đã thêm sản phẩm vào danh sách yêu thích", {
            position: toast.POSITION.TOP_CENTER,
            autoClose: 2000,
          });
        }
      } else {
        toast.error("Không thể thêm sản phẩm vào danh sách yêu thích", {
          position: toast.POSITION.TOP_CENTER,
          autoClose: 2000,
        });
      }
    } catch (error) {
      toast.error("Có lỗi xảy ra, vui lòng thử lại sau", {
        position: toast.POSITION.TOP_CENTER,
        autoClose: 2000,
      });
    }
  };

  const responsive = {
    superLargeDesktop: {
      breakpoint: { max: 4000, min: 1024 },
      items: 5,
    },
    desktop: {
      breakpoint: { max: 1024, min: 768 },
      items: 4,
    },
    tablet: {
      breakpoint: { max: 768, min: 464 },
      items: 2,
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
    },
  };
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    const currentAccount = JSON.parse(localStorage.getItem('current-account'));

    if (!token) {
      navigate('/');
    } else if (currentAccount && currentAccount.authority.includes("ROLE_ADMIN")) {
      navigate('/admin-page');
    }else{
        navigate('/');
    }
  }, [navigate]);
  return (
    <>
      <div className="container-fluid px-0 mb-3">
        <div className="row no-gutters">
          <div className="col-lg-12">
            <Carousel
              activeIndex={index}
              onSelect={handleSelect}
              indicators={false}
              fade={true} // Add fade effect
              prevIcon={
                <span className="carousel-control-prev-icon custom-prev-icon" />
              }
              nextIcon={
                <span className="carousel-control-next-icon custom-next-icon" />
              }
            >
              {carouselItems.map((item, idx) => (
                <Carousel.Item key={idx}>
                  <img
                    className="d-block w-100"
                    src={item.img}
                    alt={item.alt}
                    style={{ height: "550px", objectFit: "cover" }}
                  />
                  <Carousel.Caption className="carousel-caption d-flex flex-column align-items-center justify-content-center">
                    {/* <div className="p-3" style={{ maxWidth: "500px" }}>
                      <Link
                        className="btn btn-warning py-2 px-4 mt-3 animate__animated animate__fadeInUp"
                        to={item.link}
                      >
                        Shop Now
                      </Link>
                    </div> */}
                  </Carousel.Caption>
                </Carousel.Item>
              ))}
            </Carousel>
          </div>
        </div>
      </div>

      <div className="container-fluid pt-5 text-center" id="category">
        <h2 className="section-title position-relative text-uppercase mx-xl-5 mb-4">
          <span className="pr-3" style={{ backgroundColor: "#1a1a1a", color: "#fff" }}>
            Shop by Category
          </span>
        </h2>
        <MultiCarousel 
          responsive={responsive} 
          infinite={true} // Enable infinite loop
          itemClass="carousel-item-padding-40-px"
        >
          {listCategories &&
            listCategories.map((category, index) => (
              <div className="cat-item-wrapper" key={index}>
                <Link
                  className="text-decoration-none"
                  to={`/category/${category.slugCategory}`}
                >
                  <div
                    className="cat-item d-flex flex-column align-items-center mb-4"
                    style={{ backgroundColor: "#262626", borderRadius: "10px" }}
                  >
                    <div
                      className="overflow-hidden"
                      style={{ width: "100%", height: "150px" }}
                    >
                      <img
                        className="img-fluid h-100 w-100"
                        style={{ objectFit: "contain", padding: "10px" }}
                        src={category.imgCategory}
                        alt={category.nameCategory}
                      />
                    </div>
                    <div className="flex-fill text-center">
                      <h6 className="text-white">{category.slugCategory}</h6>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
        </MultiCarousel>
      </div>

      <div className="container-fluid pt-5 pb-3 text-center">
        <h2 className="section-title position-relative text-uppercase mx-xl-5 mb-4">
          <span className="pr-3" style={{ backgroundColor: "#1a1a1a", color: "#fff" }}>
            New Products
          </span>
        </h2>
        <div className="row px-xl-5">
          {products &&
            products.map((listProduct) => (
              <div className="col-lg-3 col-md-4 col-sm-6 pb-1" key={listProduct.id}>
                <div className="product-item mb-4" style={{ backgroundColor: "#262626" }}>
                  <div className="product-img position-relative overflow-hidden">
                    <img
                      className="img-fluid w-100"
                      style={{ height: "300px" }}
                      src={listProduct.image}
                      alt={listProduct.name}
                    />
                    <div className="product-action">
                      <Link
                        className="btn btn-outline-dark btn-square"
                        to={`/product-detail/${listProduct.id}`}
                      >
                        <i className="fa fa-search"></i>
                      </Link>
                    </div>
                    <div className="new-badge">New</div>
                  </div>
                  <div className="text-left py-4" style={{ color: "#fff" }}>
                    <Link
                      className="h6 text-decoration-none text-truncate product-name"
                      style={{ color: "#fff" }}
                      to={`/product-detail/${listProduct.id}`}
                    >
                      {listProduct.name}
                    </Link>
                    <div className="d-flex align-items-center justify-content-between mt-2">
                      <div>
                        <h5>{formatCurrency(listProduct.discountedPrice)}</h5>
                        <h6
                          className="text-muted"
                          style={{ textDecoration: "line-through" }}
                        >
                          <del>{formatCurrency(listProduct.price)}</del>
                        </h6>
                      </div>
                      <div
                        className="heart-icon"
                        onClick={() =>
                          handleAddToWishlist(listProduct.id, listProduct.discountedPrice)
                        }
                      >
                        <i
                          className="fa-solid fa-heart"
                          style={{
                            color: "#FFD333",
                            fontSize: "30px",
                            cursor: "pointer",
                          }}
                        ></i>
                      </div>
                    </div>
                    <div className="d-flex align-items-center justify-content-start mb-1">
                      {Array(listProduct.averageRating)
                        .fill()
                        .map((_, i) => (
                          <small key={i} className="fa fa-star text-primary mr-1"></small>
                        ))}
                      {Array(5 - listProduct.averageRating)
                        .fill()
                        .map((_, i) => (
                          <small key={i} className="far fa-star text-primary mr-1"></small>
                        ))}
                      <small>({listProduct.totalReviews})</small>
                    </div>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>

      <div className="container-fluid pt-5 pb-3 text-center">
        <h2 className="section-title position-relative text-uppercase mx-xl-5 mb-4">
          <span className="pr-3" style={{ backgroundColor: "#1a1a1a", color: "#fff" }}>
            featured Products
          </span>
        </h2>
        <MultiCarousel responsive={responsive} infinite={true} itemClass="carousel-item-padding-40-px">
          {featuredProducts &&
            featuredProducts.map((product) => {
              const rating = Number.isFinite(product.rating)
                ? Math.min(Math.max(Math.floor(product.rating), 0), 5)
                : 0;
              const emptyStars = 5 - rating;

              return (
                <div
                  className="product-item mb-4"
                  key={product.id}
                  style={{
                    backgroundColor: "#333",
                    borderRadius: "10px",
                    padding: "15px",
                    margin: "0 10px",
                  }}
                >
                  <div className="product-img position-relative overflow-hidden">
                    <img
                      className="img-fluid w-100"
                      style={{ height: "250px", objectFit: "cover" }}
                      src={product.image}
                      alt={product.name}
                    />
                    <div className="product-action">
                      <Link
                        className="btn btn-outline-light btn-square"
                        to={`/product-detail/${product.id}`}
                      >
                        <i className="fa fa-search"></i>
                      </Link>
                    </div>
                  </div>
                  <div className="text-left py-4" style={{ color: "#fff" }}>
                    <Link
                      className="h6 text-decoration-none text-truncate product-name"
                      style={{ color: "#fff" }}
                      to={`/product-detail/${product.id}`}
                    >
                      {product.name}
                    </Link>
                    <div className="d-flex align-items-center justify-content-between mt-2">
                      <div>
                        <h5>{formatCurrency(product.discountedPrice)}</h5>
                        <h6
                          className="text-muted"
                          style={{ textDecoration: "line-through" }}
                        >
                          <del>{formatCurrency(product.price)}</del>
                        </h6>
                      </div>
                      <div
                        className="heart-icon"
                        onClick={() =>
                          handleAddToWishlist(product.id, product.discountedPrice)
                        }
                      >
                        <i
                          className="fa-solid fa-heart"
                          style={{
                            color: "#FFD333",
                            fontSize: "30px",
                            cursor: "pointer",
                          }}
                        ></i>
                      </div>
                    </div>
                    <div className="d-flex align-items-center justify-content-start mb-1">
                      {Array(rating)
                        .fill()
                        .map((_, i) => (
                          <small key={i} className="fa fa-star text-primary mr-1"></small>
                        ))}
                      {Array(emptyStars)
                        .fill()
                        .map((_, i) => (
                          <small key={i} className="far fa-star text-primary mr-1"></small>
                        ))}
                      <small>({product.reviews})</small>
                    </div>
                  </div>
                </div>
              );
            })}
        </MultiCarousel>
      </div>

      <div className="container-fluid pt-5 pb-3">
        <div className="row px-xl-5">
          <div className="col-md-6">
            <div className="product-offer mb-30" style={{ height: "350px" }}>
              <img
                className="img-fluid"
                src="https://rog.asus.com/media/1717257544920.jpg"
                alt=""
              />
              <div className="offer-text">
                <h6 className="text-white text-uppercase">Save 20%</h6>
                <h3 className="text-white mb-3">Special Offer</h3>
                <Link to="/list-product" className="btn btn-primary">
                  Shop Now
                </Link>
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <div className="product-offer mb-30" style={{ height: "350px" }}>
              <img
                className="img-fluid"
                src="https://rog.asus.com/media/1704765385844.jpg"
                alt=""
              />
              <div className="offer-text">
                <h6 className="text-white text-uppercase">Save 20%</h6>
                <h3 className="text-white mb-3">Special Offer</h3>
                <Link to="/list-product" className="btn btn-primary">
                  Shop Now
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container promotion-section">
        <div className="row mt-4 text-center">
          <div className="col-md-2 promotion-item">
            <i className="fas fa-tags"></i>
            <h5>Priority member</h5>
            <p>Receive an additional discount of up to 7% for each order</p>
          </div>
          <div className="col-md-2 promotion-item">
            <i className="fas fa-credit-card"></i>
            <h5>0% Installment</h5>
            <p>0% interest installment payment support up to 12 months</p>
          </div>
          <div className="col-md-2 promotion-item">
            <i className="fas fa-shipping-fast"></i>
            <h5>Free shipping</h5>
            <p>Free shipping (See purchase policy details)</p>
          </div>
          <div className="col-md-2 promotion-item">
            <i className="fas fa-tools"></i>
            <h5>Guarantee</h5>
            <p>Warranty support (See warranty policy details)</p>
          </div>
          <div className="col-md-2 promotion-item">
            <i className="fas fa-exchange-alt"></i>
            <h5>Free Returns</h5>
            <p>15-day free return (See purchase policy details)</p>
          </div>
        </div>
      </div>

      <CustomerChat />
    </>
  );
};

export default Home;
