import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import { confirmAlert } from 'react-confirm-alert';
import 'react-toastify/dist/ReactToastify.css';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { f_getWishlistItem_api, f_deleteWishlist_api } from '../../config/api';
import './WishList.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

const WishList = () => {
  const [wishlistItems, setWishlistItems] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  useEffect(() => {
    fetchWishlistItems();
  }, []);

  useEffect(() => {
    if (wishlistItems.length) {
      validateCurrentPage();
    }
  }, [wishlistItems]);

  const fetchWishlistItems = async () => {
    try {
      const response = await f_getWishlistItem_api();
      setWishlistItems(response.data.result);
    } catch (error) {
      console.error('Error fetching wishlist items:', error);
    }
  };

  const validateCurrentPage = () => {
    const totalPages = Math.ceil(wishlistItems.length / itemsPerPage);
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
    }
  };

  const loadPage = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const removeItem = async (index) => {
    confirmAlert({
      title: 'Confirm to delete',
      message: 'Are you sure you want to delete this item?',
      buttons: [
        {
          label: 'Yes',
          onClick: async () => {
            try {
              const itemId = wishlistItems[index].id;
              await f_deleteWishlist_api(itemId);
              const newWishlistItems = [...wishlistItems];
              newWishlistItems.splice(index, 1);
              setWishlistItems(newWishlistItems);
              validateCurrentPage();
              toast.success('Đã xóa sản phẩm khỏi danh sách yêu thích', {
                position: toast.POSITION.TOP_CENTER,
                autoClose: 2000,
              });
            } catch (error) {
              console.error('Error deleting wishlist item:', error);
              toast.error('Không thể xóa sản phẩm khỏi danh sách yêu thích', {
                position: toast.POSITION.TOP_CENTER,
                autoClose: 2000,
              });
            }
          }
        },
        {
          label: 'No',
          onClick: () => { }
        }
      ]
    });
  };

  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const itemsToDisplay = wishlistItems.slice(startIndex, endIndex);
  const totalPages = Math.ceil(wishlistItems.length / itemsPerPage);

  return (
    <div className="wishlist-container container">
      <ToastContainer />
      <h2 className="wishlist-title">Danh Sách Yêu Thích</h2>
      <div className="row justify-content-center" id="wishlist-items">
        {itemsToDisplay.map((item, index) => (
          <div className="wishlist-item" key={item.id}>
            <img src={item.image} alt="Product" />
            <button
              className="wishlist-remove"
              onClick={() => removeItem(startIndex + index)}
            >
              <i className="fas fa-times"></i>
            </button>
            <div className="wishlist-name">{item.nameProduct}</div>
            <div className="wishlist-price">{item.price}đ</div>
            <Link
              className="wishlist-add-to-cart"
              to={`/product-detail/${item.productId}`}
              style={{
                display: 'block',
                textAlign: 'center',
                backgroundColor: '#ffd333',
                padding: '10px',
                borderRadius: '5px',
                color: '#000',
                textDecoration: 'none',
                marginTop: '10px'
              }}
            >
              <i className="fas fa-shopping-cart"></i> Thêm vào giỏ
            </Link>
          </div>
        ))}
      </div>
      {totalPages > 1 && (
        <nav aria-label="Page navigation example">
          <ul className="pagination">
            {[...Array(totalPages).keys()].map((number) => (
              <li className={`page-item ${currentPage === number + 1 ? 'active' : ''}`} key={number}>
                <Link className="page-link" to="#" onClick={() => loadPage(number + 1)}>
                  {number + 1}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </div>
  );
};

export default WishList;
