import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { f_getCartItem_api, f_deleteAllCartByUser_api } from '../../config/api';
import { toast } from 'react-toastify';
import { formatCurrency } from '../../Validate/Validate';
import axios from 'axios';

const CheckOut = () => {
  const token = localStorage.getItem('token');
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('COD');
  const [coupons, setCoupons] = useState([]);
  const [selectedCoupon, setSelectedCoupon] = useState(null);
  const [formData, setFormData] = useState({
    userName: '',
    address: '',
    district: '',
    ward: '',
    city: '',
    tel: '',
    paymentMethod: 'VNPAY',
    status: 'Pending',
    note: '',
    products: [],
    coupon: '2',
    subtotal: 0,
    totalQuantity: 0,
    orderId: 0
  });
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!token) {
      navigate('/login');
    } else {
      getCartItems();
      fetchCoupons();
    }

    const searchParams = new URLSearchParams(location.search);
    const paymentStatus = searchParams.get('paymentStatus');
    const orderInfo = searchParams.get('orderInfo');
    const totalPrice = searchParams.get('totalPrice');

    if (paymentStatus === 'success' && orderInfo && totalPrice) {
      handleOrder(orderInfo, totalPrice);
    }
  }, [navigate, token, location.search]);

  const handleMoney = (quantity, price) => {
    return quantity * price;
  };

  const getCartItems = async () => {
    setIsLoading(true);
    try {
      const res = await f_getCartItem_api();
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'success') {
        setData(res.data.result);
        setFormData({
          ...formData,
          products: res.data.result.map(item => ({
            productId: item.productId,
            quantity: item.quantityProduct,
            price: item.discountedPrice,
            color: item.color
          })),
          subtotal: res.data.result.reduce((total, item) => total + handleMoney(item.quantityProduct, item.discountedPrice), 0),
          totalQuantity: res.data.result.reduce((total, item) => total + parseFloat(item.quantityProduct), 0),
          orderId: res.data.orderId
        });
      }
    } catch (error) {
      toast.error(error.response.data.message);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCoupons = async () => {
    setIsLoading(true);
    try {
      const res = await axios.get('http://localhost:8080/api/coupons/get-all-coupons', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (res.data.status === 'success') {
        setCoupons(res.data.result);
      } else {
        toast.error('Failed to fetch coupons');
      }
    } catch (error) {
      toast.error('Error fetching coupons: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOrder = async () => {
    setIsLoading(true);

    // Calculate total amount after discount
    const subtotal = data?.reduce((total, item) => total + handleMoney(item.quantityProduct, item.discountedPrice), 0);
    const discount = selectedCoupon ? (subtotal * (selectedCoupon.discount / 100)) : 0;
    const shippingFee = 0; // Adjust if there are shipping fees
    const total = subtotal - discount + shippingFee;

    // Update orderData with total amount and subtotal after discount
    const orderData = {
      ...formData,
      paymentMethod: selectedPaymentMethod,
      totalPrice: subtotal,
      subtotal: total, // Use the discounted total for subtotal
    };

    // Check required fields
    if (!formData.userName || !formData.address || !formData.district || !formData.ward || !formData.city || !formData.tel) {
      toast.error('Please fill in all required information.');
      setIsLoading(false);
      return;
    }

    // Log order data JSON
    console.log('Order Data:', JSON.stringify(orderData, null, 2));

    try {
      const res = await axios.post('http://localhost:8080/api/orders/create-order', orderData, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (res.data.status === 'error') {
        toast.error(res.data.message);
      } else if (res.data.status === 'success') {
        toast.success('Order Success!');
        await f_deleteAllCartByUser_api();  // Clear the cart after a successful order
        getCartItems();
        navigate('/');
      }
    } catch (error) {
      if (error.response && error.response.status === 401) {
        toast.error('Unauthorized! Please login again.');
        navigate('/login');
      } else {
        toast.error(error.message);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handlePaymentMethodChange = (method) => {
    setSelectedPaymentMethod(method);
    setFormData({
      ...formData,
      paymentMethod: method
    });
  };

  const renderPaymentMethodDetails = () => {
    switch (selectedPaymentMethod) {
      case 'VNPAY':
        return (
          <div>
            <p>Redirecting to VNPAY...</p>
            <button
              onClick={handleVNPayClick}
              className="btn btn-primary"
              style={{ marginTop: '10px' }}
            >
              Pay with VNPay
            </button>
          </div>
        );
      case 'ShopeePay':
        return <div>Using ShopeePay for payment...</div>;
      case 'CreditCard':
        return <div>Enter your credit card details...</div>;
      default:
        return null;
    }
  };

  const handleVNPayClick = async () => {
    setIsLoading(true);
    const orderInfo = "VNPAYTEST";
    const amount = formData.subtotal;
  
    try {
      const response = await axios.post('http://localhost:8080/submitOrder', null, {
        params: { orderInfo, amount },
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
  
      if (response.status === 200) {
        const vnpayUrl = response.data;
        window.location.href = vnpayUrl;
      } else {
        toast.error('VNPay payment initialization failed: ' + response.data.message);
        console.error('VNPay Error:', response.data.message);
      }
    } catch (error) {
      if (error.response) {
        console.error('Response error:', error.response);
        toast.error('VNPay payment initialization error: ' + error.response.data.message);
      } else if (error.request) {
        console.error('Request error:', error.request);
        toast.error('No response from VNPay');
      } else {
        console.error('Error:', error.message);
        toast.error('VNPay payment initialization error: ' + error.message);
      }
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleCouponSelect = (e) => {
    const couponId = e.target.value;
    const selected = coupons.find(coupon => coupon.id === parseInt(couponId));
    setSelectedCoupon(selected);
  };

  // Calculate the total amount including discount
  const subtotal = formData.subtotal;
  const discount = selectedCoupon ? (subtotal * (selectedCoupon.discount / 100)) : 0;
  const shippingFee = 0; // Adjust if there are shipping fees
  const total = subtotal - discount + shippingFee;

  return (
    <>
      <div className="container-fluid">
        <div className="row px-xl-5">
          <div className="col-12">
            <nav className="breadcrumb mb-30" style={{ backgroundColor: "#1a1a1a", color: "#FFF" }}>
              <Link className="breadcrumb-item text-dark" to="/">Home</Link>
              <Link className="breadcrumb-item text-dark" to="/list-product">Product</Link>
              <span className="breadcrumb-item active">Checkout</span>
            </nav>
          </div>
        </div>
      </div>
      <div className="container-fluid">
        <div className="row px-xl-5">
          <div className="col-lg-8">
            <h5 className="section-title position-relative text-uppercase mb-3">
              <span className="pr-3" style={{ backgroundColor: "#1a1a1a", color: "#FFF" }}>Shipping Address</span>
            </h5>
            <div className="row" style={{ margin: "0 0 15px 0", backgroundColor: "rgb(61, 70, 77)" }}>
              <div className="col-md-6 form-group">
                <label>Full Name</label>
                <input className="form-control" type="text" placeholder="Enter your name" name="userName" value={formData.userName} onChange={handleInputChange} required />
              </div>
              <div className="col-md-6 form-group">
                <label>Phone Number</label>
                <input className="form-control" type="text" placeholder="Enter your phone number" name="tel" value={formData.tel} onChange={handleInputChange} required />
              </div>
              <div className="col-md-6 form-group">
                <label>City</label>
                <input className="form-control" type="text" placeholder="Enter your city" name="city" value={formData.city} onChange={handleInputChange} required />
              </div>
              <div className="col-md-6 form-group">
                <label>District</label>
                <input className="form-control" type="text" placeholder="Enter your district" name="district" value={formData.district} onChange={handleInputChange} required />
              </div>
              <div className="col-md-6 form-group">
                <label>Ward</label>
                <input className="form-control" type="text" placeholder="Enter your ward" name="ward" value={formData.ward} onChange={handleInputChange} required />
              </div>
              <div className="col-md-12 form-group">
                <label>Address</label>
                <input className="form-control" type="text" placeholder="Enter your address" name="address" value={formData.address} onChange={handleInputChange} required />
              </div>
              <div className="col-md-12 form-group">
                <label>Order Note</label>
                <textarea className="form-control" placeholder="Enter your order note" name="note" value={formData.note} onChange={handleInputChange} required></textarea>
              </div>
              <div className="col-md-12 form-group">
                <label>Payment Method</label>
                <div className="payment-methods" style={{ display: 'flex', justifyContent: 'space-between', marginTop: '15px' }}>
                  <button
                    className={`btn payment-btn ${selectedPaymentMethod === 'ShopeePay' ? 'active' : ''}`}
                    onClick={() => handlePaymentMethodChange('ShopeePay')}
                    style={{
                      flex: 1,
                      marginRight: '5px',
                      padding: '10px',
                      backgroundColor: selectedPaymentMethod === 'ShopeePay' ? '#007bff' : '#f8f9fa',
                      border: '1px solid',
                      borderColor: selectedPaymentMethod === 'ShopeePay' ? '#007bff' : '#ced4da',
                      color: selectedPaymentMethod === 'ShopeePay' ? '#fff' : '#000',
                      cursor: 'pointer',
                      textAlign: 'center'
                    }}
                  >
                    ShopeePay Wallet
                  </button>
                  <button
                    className={`btn payment-btn ${selectedPaymentMethod === 'VNPAY' ? 'active' : ''}`}
                    onClick={() => handlePaymentMethodChange('VNPAY')}
                    style={{
                      flex: 1,
                      marginRight: '5px',
                      padding: '10px',
                      backgroundColor: selectedPaymentMethod === 'VNPAY' ? '#007bff' : '#f8f9fa',
                      border: '1px solid',
                      borderColor: selectedPaymentMethod === 'VNPAY' ? '#007bff' : '#ced4da',
                      color: selectedPaymentMethod === 'VNPAY' ? '#fff' : '#000',
                      cursor: 'pointer',
                      textAlign: 'center'
                    }}
                  >
                    VNPAY
                  </button>
                  <button
                    className={`btn payment-btn ${selectedPaymentMethod === 'CreditCard' ? 'active' : ''}`}
                    onClick={() => handlePaymentMethodChange('CreditCard')}
                    style={{
                      flex: 1,
                      marginRight: '5px',
                      padding: '10px',
                      backgroundColor: selectedPaymentMethod === 'CreditCard' ? '#007bff' : '#f8f9fa',
                      border: '1px solid',
                      borderColor: selectedPaymentMethod === 'CreditCard' ? '#007bff' : '#ced4da',
                      color: selectedPaymentMethod === 'CreditCard' ? '#fff' : '#000',
                      cursor: 'pointer',
                      textAlign: 'center'
                    }}
                  >
                    Credit/Debit Card
                  </button>
                  <button
                    className={`btn payment-btn ${selectedPaymentMethod === 'COD' ? 'active' : ''}`}
                    onClick={() => handlePaymentMethodChange('COD')}
                    style={{
                      flex: 1,
                      padding: '10px',
                      backgroundColor: selectedPaymentMethod === 'COD' ? '#007bff' : '#f8f9fa',
                      border: '1px solid',
                      borderColor: selectedPaymentMethod === 'COD' ? '#007bff' : '#ced4da',
                      color: selectedPaymentMethod === 'COD' ? '#fff' : '#000',
                      cursor: 'pointer',
                      textAlign: 'center'
                    }}
                  >
                    Cash on Delivery
                  </button>
                </div>
                <div className="payment-details">
                  {renderPaymentMethodDetails()}
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-4">
            <h5 className="section-title position-relative text-uppercase mb-3">
              <span className="pr-3" style={{ backgroundColor: "#1a1a1a", color: "#FFF" }}>Order Summary</span>
            </h5>
            <div style={{ padding: "15px", backgroundColor: "rgb(61, 70, 77)" }}>
              <div className="border-bottom mb-3">
                <div className="mb-30">
                  <div className="input-group">
                    <select 
                      className="form-control border-0 border-radius p-4" 
                      style={{ backgroundColor: "#293035", color: "#FFF" }} 
                      onChange={handleCouponSelect}
                    >
                      <option value="">{selectedCoupon ? selectedCoupon.description : 'Select Coupon'}</option>
                      {coupons.map(coupon => (
                        <option key={coupon.id} value={coupon.id}>
                          {coupon.description}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
              <div className="border-bottom pt-3 pb-2">
                <div className="d-flex justify-content-between mb-3">
                  <h6>Subtotal</h6>
                  <h6>{formatCurrency(formData.subtotal.toFixed(2))}</h6>
                </div>
                <div className="d-flex justify-content-between mb-3">
                  <h6>Shipping Fee</h6>
                  <h6>Free</h6>
                </div>
                <div className="d-flex justify-content-between mb-3">
                  <h6>Discount</h6>
                  <h6>
                    {selectedCoupon ? (
                      <>
                        {formatCurrency(discount.toFixed(2))} <small>({selectedCoupon.description})</small>
                      </>
                    ) : (
                      formatCurrency(0)
                    )}
                  </h6>
                </div>
                <div className="d-flex justify-content-between mb-3">
                  <h6>Total</h6>
                  <h6>{formatCurrency(total.toFixed(2))}</h6>
                </div>
              </div>
              <button className="btn btn-primary btn-block" onClick={handleOrder}>Place Order</button>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid">
        <div className="row px-xl-5">
          <div className="col-12">
            <h5 className="section-title position-relative text-uppercase mb-3">
              <span className="pr-3" style={{ backgroundColor: "#1a1a1a", color: "#FFF" }}>Cart</span>
            </h5>
            <div className="">
              <table className="table table-light table-borderless table-hover">
                <thead style={{ backgroundColor: "#3D464D", color: "#FFF" }}>
                  <tr>
                    <th>No.</th>
                    <th>Image</th>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody style={{ backgroundColor: "#293035", color: "#FFF" }}>
                  {data && data.map((item, index) => (
                    <tr key={index}>
                      <td>{index + 1}</td>
                      <td><img src={item.image} alt="Product" style={{ width: "120px", height: "80px", objectFit: "cover" }} /></td>
                      <td>
                        {item.nameProduct}
                        <br />
                        Color: {item.color}
                      </td>
                      <td>{formatCurrency(item.discountedPrice)}</td>
                      <td>{item.quantityProduct}</td>
                      <td>{formatCurrency(handleMoney(item.quantityProduct, item.discountedPrice))}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CheckOut;
