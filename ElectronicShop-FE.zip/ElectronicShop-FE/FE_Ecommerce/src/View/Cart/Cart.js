import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { f_deleteCartItem_api, f_getCartItem_api } from '../../config/api';
import { toast } from 'react-toastify';
import { Button, Modal } from 'react-bootstrap';
import { convertBase64ToBlob, formatCurrency } from '../../Validate/Validate';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingBasket } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';

const Cart = () => {
  const token = localStorage.getItem('token');
  const [isLoading, setIsLoading] = useState(false);
  const [cartItem, setCartItem] = useState([]);
  const [showModel, setShowModel] = useState(false);
  const [selectedCartId, setSelectedCartId] = useState(null);
  const navigate = useNavigate();
  const currentAccount = JSON.parse(localStorage.getItem('current-account'));

  useEffect(() => {
    if (!token) {
      navigate('/login');
    } else if (currentAccount && currentAccount.authority.includes("ROLE_ADMIN")) {
      navigate('/admin-page');
    } else {
      getCartItem();
    }
  }, [navigate, token]);

  const handleMoney = (quantity, price) => {
    return quantity * price;
  };

  const subtotal = cartItem?.reduce((total, item) => total + handleMoney(item.quantityProduct, item.discountedPrice), 0);
  const totalItems = cartItem?.reduce((total, item) => total + parseFloat(item.quantityProduct), 0);
  const shippingFee = 1;
  const total = subtotal + shippingFee;

  const getCartItem = async () => {
    setIsLoading(true);
    try {
      const res = await f_getCartItem_api();
      if (res.data.status === 'success') {
        setCartItem(res.data.result);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const updateCartItem = async (cartId, quantity) => {
    try {
      const response = await axios.put(`http://localhost:8080/api/carts/update-cart/${cartId}`, 
        { quantity },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      if (response.data.status === 'success') {
        getCartItem(); // Refresh cart items after update
      } else {
        toast.error('Failed to update cart');
      }
    } catch (error) {
      toast.error('Error updating cart: ' + error.message);
    }
  };

  const handleOpen = (id) => {
    setSelectedCartId(id);
    setShowModel(true);
  };

  const handleClose = () => {
    setShowModel(false);
  };

  const handleDelete = async () => {
    setIsLoading(true);
    try {
      const res = await f_deleteCartItem_api(selectedCartId);
      if (res.data.status === 'success') {
        toast.success(res.data.message);
        setCartItem((prevItems) => prevItems.filter((item) => item.id !== selectedCartId));
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
      setShowModel(false);
    }
  };

  const handleQuantityChange = async (id, delta) => {
    const item = cartItem.find(item => item.id === id);
    if (item) {
      const newQuantity = Math.max(1, item.quantityProduct + delta);
      if (newQuantity <= item.stock) {
        await updateCartItem(id, newQuantity);
      } else {
        toast.warning('Cannot exceed available stock');
      }
    }
  };

  return (
    <>
      <div className="container-fluid">
        <div className="row px-xl-5">
          <div className="col-12">
            <nav className="breadcrumb mb-30" style={{ backgroundColor: "#1a1a1a", color: "#FFF" }}>
              <Link className="breadcrumb-item text-dark" to="/">Home</Link>
              <Link className="breadcrumb-item text-dark" to="/list-product">Product</Link>
              <span className="breadcrumb-item active" style={{ color: "#fff" }}>Shopping Cart</span>
            </nav>
          </div>
        </div>
      </div>
      <div className="container-fluid">
        <div className="row px-xl-5">
          {isLoading ? (
            <div className='col-lg-8'>
              <div className="custom-loader "></div>
            </div>
          ) : cartItem && cartItem.length === 0 ? (
            <div className="text-center py-5">
              <FontAwesomeIcon icon={faShoppingBasket} className="empty-cart-icon" />
              <h3>Empty shopping cart</h3>
              <p className="mt-3">Please add items to the shopping cart.</p>
            </div>
          ) : (
            <div className="col-lg-8 table-responsive mb-5">
              <table className="table table-light table-borderless table-hover text-center mb-0">
                <thead className="thead" style={{ backgroundColor: "#3D464D", color: "#FFF" }}>
                  <tr>
                    <th>STT</th>
                    <th>Ảnh</th>
                    <th>Sản Phẩm</th>
                    <th>Giá</th>
                    <th>Số Lượng</th>
                    <th>Thành Tiền</th>
                    <th>Remove</th>
                  </tr>
                </thead>
                <tbody className="align-middle" style={{ backgroundColor: "#293035", color: "#FFF" }}>
                  {cartItem?.map((cart, index) => (
                    <tr key={cart.id} className='fadeIn'>
                      <td>{index + 1}</td>
                      <td>
                        <img
                          src={convertBase64ToBlob(cart.image)}
                          alt="" className='mx-5' style={{ width: "80px", height: "80px", objectFit: "cover" }} />
                      </td>
                      <td className="text-left" style={{ maxWidth: '200px' }}>
                        {cart.nameProduct}
                        <div><small>Màu sắc: {cart.color}</small></div>                        
                      </td>
                      <td className="align-middle">{formatCurrency(cart.discountedPrice)}</td>
                      <td className="align-middle">
                        <div className="input-group quantity mx-auto d-flex w-100 justify-content-center">
                          <div className="input-group-btn">
                            <button className="btn btn-sm btn-primary btn-minus" onClick={() => handleQuantityChange(cart.id, -1)} disabled={cart.quantityProduct <= 1}>
                              <i className="fa fa-minus"></i>
                            </button>
                          </div>
                          <span className="form-control form-control-sm bg-secondary border-0 text-center">{cart.quantityProduct}</span>
                          <div className="input-group-btn">
                            <button className="btn btn-sm btn-primary btn-plus" onClick={() => handleQuantityChange(cart.id, 1)} disabled={cart.quantityProduct >= cart.stock}>
                              <i className="fa fa-plus"></i>
                            </button>
                          </div>
                        </div>
                      </td>
                      <td className="align-middle">{formatCurrency(handleMoney(cart.quantityProduct, cart.discountedPrice))}</td>
                      <td className="align-middle"><button className="btn btn-sm btn-danger" onClick={() => handleOpen(cart.id)}><i className="fas fa-trash-alt"></i></button></td>
                    </tr>
                  ))}
                </tbody>
                {showModel && (
                  <Modal show={showModel} onHide={handleClose}>
                    <Modal.Header closeButton>
                      <Modal.Title>Confirm Deletion</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                      Are you sure you want to delete this item?
                    </Modal.Body>
                    <Modal.Footer>
                      <Button variant="secondary" onClick={handleClose}>
                        Cancel
                      </Button>
                      <Button variant="danger" onClick={handleDelete}>
                        Delete
                      </Button>
                    </Modal.Footer>
                  </Modal>
                )}
              </table>
            </div>
          )}
          <div className="col-lg-4">
            <h5 className="section-title position-relative text-uppercase mb-3"><span className="pr-3" style={{ backgroundColor: "#1a1a1a", color: "#FFF" }}>Cart Summary</span></h5>
            <div className="p-30 mb-5 bounceIn" style={{ backgroundColor: "#3D464D", color: "#FFF" }}>
              <div className="border-bottom pb-2">
                <div className="d-flex justify-content-between mb-3">
                  <h6>All Cart Items</h6>
                  <h6>({totalItems} products)</h6>
                </div>
                <div className="d-flex justify-content-between mb-3">
                  <h6>Subtotal</h6>
                  <h6>{formatCurrency(subtotal?.toFixed(2))}</h6>
                </div>
                <div className="d-flex justify-content-between">
                  <h6 className="font-weight-medium">Shipping</h6>
                  <h6 className="font-weight-medium">{formatCurrency(shippingFee?.toFixed(2))}</h6>
                </div>
              </div>
              <div className="pt-2">
                <div className="d-flex justify-content-between mt-2">
                  <h5>Total</h5>
                  <h5>{formatCurrency(total?.toFixed(2))}</h5>
                </div>
                {cartItem && cartItem.length > 0 ? (
                  <Link className="btn btn-block btn-primary font-weight-bold my-3 py-3" to="/check-out">Proceed To Checkout</Link>
                ) : (
                  <button className="btn btn-block btn-secondary font-weight-bold my-3 py-3" disabled>Proceed To Checkout</button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Cart;
