/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import "./update.css";
import SideBar from "../SideBar/SideBar";
import { toast } from "react-toastify";
import axios from '../../config/customAxios';
import { convertBase64ToBlob, formatDateTime } from "../../Validate/Validate";
import moment from 'moment';
import { f_getAllReviewByUser_api,f_getDetaiAccout_api } from '../../config/api'; // Ensure the import path is correct

const UpdateUser = () => {
  const token = localStorage.getItem("token");
  const currentUser = JSON.parse(localStorage.getItem("current-account"));
  const navigate = useNavigate();
  const [loadingApi, setLoadingApi] = useState(false);
  const [nameUpdate, setName] = useState(currentUser.name);
  const [dob, setDob] = useState(currentUser.dob);
  const [phone, setPhone] = useState(currentUser.tel);
  const [address, setAddress] = useState(currentUser.address);
  const [selectedGender, setSelectedGender] = useState(currentUser.gender);
  const [avatar, setAvatar] = useState(currentUser.avatar);

  useEffect(() => {
    if (!token) {
      navigate("/login");
    } else {
      fetchUserAvatar();
    }
  }, [navigate]);

  const fetchUserAvatar = async () => {
    try {
      const response = await f_getDetaiAccout_api();
      if (response.data.status === 'success' && response.data.result.length > 0) {
        const userAvatar = response.data.result[0].avatar;
        setAvatar(userAvatar);
      } else {
        console.error('Failed to fetch user avatar');
      }
    } catch (error) {
      console.error('Error fetching user avatar:', error);
    }
  };

  const handleUpdate = async () => {
    if (!nameUpdate || !phone || !address || !avatar || !dob) {
      toast.warning("Input not blank, Please");
      return;
    }

    setLoadingApi(true);
    const formData = new FormData();
    formData.append('avatar', avatar);
    formData.append('user', JSON.stringify({
      'name': nameUpdate,
      'tel': phone,
      'dob': dob,
      'gender': selectedGender,
      'address': address
    }));

    try {
      const res = await axios.put('/account/update-account', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (res.data.status === "error") {
        toast.error(res.data.message);
      } else if (res.data.status === "success") {
        toast.success(res.data.message);
        window.location.reload(true);
        const updatedCurrentUser = {
          ...currentUser,
          name: nameUpdate,
          dob: dob,
          phone: phone,
          address: address,
          gender: selectedGender,
          avatar: avatar,
        };

        setName(updatedCurrentUser.name);
        setDob(updatedCurrentUser.dob);
        setPhone(updatedCurrentUser.phone);
        setAddress(updatedCurrentUser.address);
        setSelectedGender(updatedCurrentUser.gender);
        setAvatar(updatedCurrentUser.avatar);

        localStorage.setItem("current-account", JSON.stringify(updatedCurrentUser));
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoadingApi(false);
    }
  };

  return (
    <div
      className="page-wrapper"
      id="main-wrapper"
      data-layout="vertical"
      data-navbarbg="skin6"
      data-sidebartype="full"
      data-sidebar-position="fixed"
      data-header-position="fixed"
    >
      <div className="container-fluid">
        <div className="row">
          <SideBar />

          <div className="col-xl-9 col-lg-9 col-md-8" style={{paddingTop:"25px"}} >
            <div className="card" style={{backgroundColor:"#3d464d", color:"#fff", borderRadius:"50px"}}>
            
              <div className="container-fluid profilex-form" >
              <h1  style={{paddingTop:"25px",paddingBottom:"25px",color:"#ffffff",textAlign:"center"}}> User Profile</h1>
                <div className="row">

                  <div className="col-sm-4 col-lg-4">

                    <div className="img-user fadeInLeft">
                      <ul>
                        <li>
                          <img
                            src={convertBase64ToBlob(avatar)}
                            className="avatar img-thumbnails"
                            alt="avatar"
                          />
                        </li>
                        <li>
                          <input
                            type="file"
                            id="avatar"
                            name="avatar"
                            accept="image/png, image/jpeg, image/jpg"
                            onChange={(e) => setAvatar(e.target.files[0])}
                            style={{backgroundColor:"#3d464d"}}
                          />
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div className="col-sm-6 col-lg-6">
                    <div className="form userProfile m-auto ">
                      <div className="col-12 fadeInLeft">
                        <label htmlFor="user_name">Full Name</label>
                        <input
                          type="text"
                          className="form-control"
                          name="name"
                          id="user_name"
                          value={nameUpdate}
                          onChange={(e) => setName(e.target.value)}
                        />
                      </div>
                      <div className="form-group form-infor ">
                        <div className="col-sm-6 col-6 input-infor fadeInLeft">
                          <label>Gender</label>
                          <select
                            id="gender"
                            value={selectedGender}
                            onChange={(e) => setSelectedGender(e.target.value)}
                            className="form-control"
                          >
                            <option value="F">Female</option>
                            <option value="M">Male</option>
                          </select>
                        </div>
                        <div className="col-sm-6 col-6 input-infor fadeInLeft">
                          <label>Date of birth</label>
                          <input
                            required
                            name="dob"
                            type="date"
                            className="form-control"
                            value={moment(dob, 'YYYYMMDD').format('YYYY-MM-DD')}
                            onChange={(e) => setDob(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="form-group form-infor">
                        <div className="col-sm-6 col-6 input-infor fadeInLeft">
                          <label>Phone</label>
                          <input
                            type="text"
                            className="form-control"
                            name="phone"
                            id="mobile"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                          />
                        </div>
                        <div className="col-sm-6 col-6 input-infor fadeInLeft">
                          <label>Address</label>
                          <input
                            type="text"
                            className="form-control"
                            name="text"
                            id="text"
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="form-group form-infor">
                        <div className="col-sm-12">
                          <br />
                          <button
                            className="btn-update fadeInUp"
                            style={{ outline: "none" }}
                            type="button"
                            onClick={handleUpdate}
                          >
                            Update&nbsp;
                            {loadingApi ? (
                              <i className="fa-solid fa-spinner fa-spin-pulse fa-spin-reverse"></i>
                            ) : (
                              <i className="fa-solid fa-right-to-bracket"></i>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdateUser;
