import React, { useState, useEffect } from 'react';
import './Feedbacked.css';
import SideBar from '../SideBar/SideBar';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash, faTimes, faStar as solidStar, faStar as regularStar } from '@fortawesome/free-solid-svg-icons';
import { f_getAllReviewByUser_api } from '../../config/api'; // Updated import path
import axios from '../../config/customAxios';

const Feedback = () => {
  const [reviews, setReviews] = useState([]);
  const [currentReview, setCurrentReview] = useState(null);
  const [updatedComment, setUpdatedComment] = useState('');
  const [updatedRating, setUpdatedRating] = useState(0);
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetchUserReviews();
  }, []);

  const fetchUserReviews = async () => {
    try {
      const response = await f_getAllReviewByUser_api();
      if (response.data.status === 'success') {
        setReviews(response.data.result);
      } else {
        console.error('Failed to fetch reviews');
      }
    } catch (error) {
      console.error('Error fetching reviews:', error);
    }
  };

  const handleUpdate = (review) => {
    setCurrentReview(review);
    setUpdatedComment(review.comment);
    setUpdatedRating(review.rating);
  };

  const handleSaveChanges = async () => {
    try {
      await axios.put(`/reviews/update-review/${currentReview.id}`, {
        comment: updatedComment,
        rating: updatedRating,
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setReviews(reviews.map(review =>
        review.id === currentReview.id ? { ...review, comment: updatedComment, rating: updatedRating } : review
      ));
      setCurrentReview(null);
    } catch (error) {
      console.error('Error updating review:', error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`/reviews/delete-review/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setReviews(reviews.filter(review => review.id !== id));
    } catch (error) {
      console.error('Error deleting review:', error);
    }
  };

  const handleRatingChange = (e) => {
    setUpdatedRating(Number(e.target.value));
  };

  const handleClosePopup = () => {
    setCurrentReview(null);
  };

const renderStars = (rating) => {
    const stars = [];
    for (let i = 0; i < 5; i++) {
      if (i < rating) {
        stars.push(<small key={i} className="fas fa-star text-primary"></small>);
      } else {
        stars.push(<small key={i} className="far fa-star text-primary"></small>);
      }
    }
    return stars;
  };

  return (
    <div className="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full" data-sidebar-position="fixed" data-header-position="fixed">
      <div className='container-fluid'>
        <div className='row'>
          <SideBar />
          <div className='col-xl-9 col-lg-9 col-md-8' style={{paddingTop:"25px"}}>
          <div className="card" style={{backgroundColor:"#3d464d", color:"#FFF", borderRadius:"50px"}}>

            <h1 className="title" style={{paddingTop:"25px"}}>Feedbacked Orders</h1>
            <div className="product-cards" style={{paddingBottom:"25px"}}>
              {reviews.map(review => (
                <div key={review.id} className="product-card">
                  <img src={review.productImage} alt={review.nameUser} className="product-image" />
                  <div className="product-info">
                    <h2>{review.productName}</h2>
                    <div>
                      {renderStars(review.rating)}
                    </div>                    
                    <p>{review.comment}</p>
                    <div className="actions">
                      <button onClick={() => handleUpdate(review)} className="update-button">
                        <FontAwesomeIcon icon={faEdit} /> Update
                      </button>
                      <button onClick={() => handleDelete(review.id)} className="delete-button">
                        <FontAwesomeIcon icon={faTrash} /> Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {currentReview && (
              <div className="popup">
                <button className="close-button" onClick={handleClosePopup}>
                  <FontAwesomeIcon icon={faTimes} />
                </button>
                <h2>Update Feedback</h2>
                <textarea
                  value={updatedComment}
                  onChange={(e) => setUpdatedComment(e.target.value)}
                  className="update-textarea"
                />
                <div className="rating">
                  <label htmlFor="rating-select">Your Rating *</label>
                  <select id="rating-select" value={updatedRating} onChange={handleRatingChange} className="rating-dropdown">
                    {[1, 2, 3, 4, 5].map((value) => (
                      <option key={value} value={value}>
                        {value} Star{value > 1 ? 's' : ''}
                      </option>
                    ))}
                  </select>
                </div>
                <button onClick={handleSaveChanges} className="save-changes-button">Save changes</button>
              </div>
            )}
          </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Feedback;
