import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import './Payment.css'; // Import file CSS của bạn

const Payment = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);

  const totalPrice = searchParams.get('vnp_Amount');
  const transactionId = searchParams.get('vnp_TransactionNo');
  const paymentTime = searchParams.get('vnp_PayDate');
  const orderId = searchParams.get('vnp_OrderInfo');

  useEffect(() => {
    console.log('orderId:', orderId);
    console.log('transactionId:', transactionId);
    console.log('totalPrice:', totalPrice);
    console.log('paymentTime:', paymentTime);
  }, [orderId, transactionId, totalPrice, paymentTime]);

  return (
    <div className="container mt-5">
      <div className="card shadow-sm p-3">
        <div className="card-body">
          <h1 className="card-title text-center">Order Success</h1>
          <div className="card-text payment-details">
            <p><strong>Order ID:</strong> {orderId}</p>
            <p><strong>Transaction ID:</strong> {transactionId}</p>
            <p><strong>Total Price:</strong> {totalPrice}</p>
            <p><strong>Payment Time:</strong> {paymentTime}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payment;
