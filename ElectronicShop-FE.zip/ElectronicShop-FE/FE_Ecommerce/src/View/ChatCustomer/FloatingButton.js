import React from 'react';
import './FloatingButton.css';

const FloatingButton = ({ onClick, isOpen }) => {
    return (
        <div className="floating-button" onClick={onClick}>
            <i className={`fa ${isOpen ? 'fa-times' : 'fa-comment'}`}></i>
        </div>
    );
};

export default FloatingButton;