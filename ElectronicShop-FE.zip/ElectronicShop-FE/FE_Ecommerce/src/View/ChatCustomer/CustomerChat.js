import React, { useEffect, useState, useRef } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import './CustomerChat.css'; // Import CSS file
import FloatingButton from './FloatingButton'; // Import Floating Button component

var stompClient = null;

const CustomerChat = () => {
    const currentAccount = JSON.parse(localStorage.getItem('current-account'));
    const chatStorageKey = `privateChats-${currentAccount?.name}`;
    const [privateChats, setPrivateChats] = useState(JSON.parse(localStorage.getItem(chatStorageKey)) || []);
    const [userData, setUserData] = useState({
        username: currentAccount?.name || '',
        connected: false,
        message: ''
    });
    const [isChatOpen, setIsChatOpen] = useState(false); // State to toggle chat window
    const chatContentRef = useRef(null);

    useEffect(() => {
        if (userData.username) {
            connect();
        }
    }, [userData.username]);

    useEffect(() => {
        if (chatContentRef.current) {
            chatContentRef.current.scrollTop = chatContentRef.current.scrollHeight;
        }
        localStorage.setItem(chatStorageKey, JSON.stringify(privateChats));
    }, [privateChats, chatStorageKey]);

    const connect = () => {
        let Sock = new SockJS('http://localhost:8080/ws');
        stompClient = new Client({
            webSocketFactory: () => Sock,
            onConnect: onConnected,
            onStompError: onError,
        });
        stompClient.activate();
    }

    const onConnected = () => {
        setUserData(prevState => ({...prevState, connected: true}));
        stompClient.subscribe('/user/' + userData.username + '/private', onPrivateMessage);
        userJoin();
    }

    const userJoin = () => {
        var chatMessage = {
            senderName: userData.username,
            status: "JOIN"
        };
        stompClient.publish({destination: "/app/message", body: JSON.stringify(chatMessage)});
    }

    const onPrivateMessage = (payload) => {
        var payloadData = JSON.parse(payload.body);
        setPrivateChats(prevChats => [payloadData, ...prevChats]);
    }

    const onError = (err) => {
        console.log(err);
    }

    const handleMessage = (event) => {
        const { value } = event.target;
        setUserData(prevState => ({...prevState, message: value}));
    }

    const sendValue = () => {
        if (stompClient) {
            var chatMessage = {
                senderName: userData.username,
                receiverName: "Admin",
                message: userData.message,
                status: "MESSAGE",
                timestamp: new Date().toLocaleTimeString()
            };
            setPrivateChats(prevChats => [chatMessage, ...prevChats]);
            stompClient.publish({destination: "/app/private-message", body: JSON.stringify(chatMessage)});
            setUserData(prevState => ({...prevState, message: ''}));
        }
    }

    const handleUsername = (event) => {
        const { value } = event.target;
        setUserData(prevState => ({...prevState, username: value}));
    }

    const handleKeyPress = (event) => {
        if (event.key === 'Enter') {
            sendValue();
        }
    };

    const registerUser = () => {
        connect();
    }

    const toggleChat = () => {
        setIsChatOpen(!isChatOpen);
    };

    const getAvatar = (name) => {
        return name ? name.charAt(0).toUpperCase() : '';
    };

    return (
        <div className="customer-chat">
            <FloatingButton onClick={toggleChat} />
            {isChatOpen && (
                <div className="chat-container">
                    {userData.connected ?
                        <div className="chat-box">
                            <div className="chat-content" ref={chatContentRef}>
                                <ul className="chat-messages">
                                    {privateChats.map((chat, index) => (
                                        <li className={`message ${chat.senderName === userData.username && "self"}`} key={index}>
                                            {chat.senderName !== userData.username && <div className="avatar">{getAvatar(chat.senderName)}</div>}
                                            <div className="message-data">
                                                {chat.message}
                                                <span className="timestamp">{chat.timestamp}</span>
                                            </div>
                                            {chat.senderName === userData.username && <div className="avatar self">{getAvatar(chat.senderName)}</div>}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="send-message">
                                <input 
                                    type="text" 
                                    className="input-message" 
                                    placeholder="Nhập tin nhắn của bạn..." 
                                    value={userData.message} 
                                    onChange={handleMessage} 
                                    onKeyPress={handleKeyPress} 
                                />
                                <button type="button" className="send-button" onClick={sendValue}>
                                    <i className="fa-regular fa-paper-plane"></i>
                                </button>
                            </div>
                        </div>
                        :
                        <div className="register">
                            <input
                                id="user-name"
                                placeholder="Enter your name"
                                name="userName"
                                value={userData.username}
                                onChange={handleUsername}
                                margin="normal"
                            />
                            <button type="button" onClick={registerUser}>Connect</button>
                        </div>
                    }
                </div>
            )}
        </div>
    )
}

export default CustomerChat;
