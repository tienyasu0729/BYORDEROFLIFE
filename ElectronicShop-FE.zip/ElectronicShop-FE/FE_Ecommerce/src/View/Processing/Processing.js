import React, { useEffect, useState } from 'react';
import SideBar from '../SideBar/SideBar';
import { toast } from 'react-toastify';
import { formatCurrency, formatDateTime } from '../../Validate/Validate';
import { Modal, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button, TextField, Select, MenuItem } from '@mui/material';
import Pagination from 'react-paginate';
import { f_getAllOderByUser_api, f_getAllOrderdetaillByOrderID_api } from '../../config/api';
import './Processing.css';

const Processing = () => {
    const [listOrders, setListOrders] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isDetailOpen, setIsDetailOpen] = useState(false);
    const [orderDetails, setOrderDetails] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredOrders, setFilteredOrders] = useState([]);
    const [page, setPage] = useState(0);
    const [statusFilter, setStatusFilter] = useState('');

    const itemsPerPage = 6;

    const getProcessingItems = async () => {
        setIsLoading(true);
        try {
            const res = await f_getAllOderByUser_api();
            if (res.data.status === 'success') {
                const sortedOrders = res.data.result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
                setListOrders(sortedOrders);
                setFilteredOrders(sortedOrders);
            } else {
                toast.warning(res.data.message);
            }
        } catch (error) {
            toast.error(error.message);
        } finally {
            setIsLoading(false);
        }
    };

    const getOrderDetails = async (id) => {
        console.log(`Fetching details for order ID: ${id}`);
        setIsLoading(true);
        try {
            const res = await f_getAllOrderdetaillByOrderID_api(id);
            if (res.data.status === 'success') {
                setOrderDetails(res.data.result);
                setIsDetailOpen(true);
            } else {
                toast.error(res.data.message);
                console.error(`Error fetching order details for ID ${id}: ${res.data.message}`);
            }
        } catch (error) {
            toast.error(`Error fetching order details: ${error.message}`);
            console.error(`Error fetching order details for ID ${id}:`, error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        getProcessingItems();
    }, []);

    useEffect(() => {
        const lowercasedQuery = searchQuery.toLowerCase();
        const filtered = listOrders.filter(order =>
            order.nameOrder.toLowerCase().includes(lowercasedQuery) ||
            order.paymentMethod.toLowerCase().includes(lowercasedQuery) ||
            order.status.toLowerCase().includes(lowercasedQuery)
        );

        if (statusFilter) {
            setFilteredOrders(filtered.filter(order => order.status.toLowerCase() === statusFilter.toLowerCase()));
        } else {
            setFilteredOrders(filtered);
        }
    }, [searchQuery, statusFilter, listOrders]);

    const handlePageClick = (event) => {
        const newPage = event.selected;
        setPage(newPage);
    };

    const offset = page * itemsPerPage;
    const pageData = filteredOrders.slice(offset, offset + itemsPerPage);

    const statusFormat = (status) => {
        switch (status) {
            case 'Processing':
                return 'Processing';
            case 'Confirmed':
                return 'Confirmed';
            case 'Shipping':
                return 'Shipping';
            case 'Delivered':
                return 'Delivered';
            case 'Canceled':
                return 'Canceled';
            default:
                return status;
        }
    };

    const statusClass = (status) => {
        switch (status) {
            case 'Processing':
                return 'status-processing';
            case 'Confirmed':
                return 'status-confirmed';
            case 'Shipping':
                return 'status-shipping';
            case 'Delivered':
                return 'status-delivered';
            case 'Canceled':
                return 'status-canceled';
            default:
                return '';
        }
    };

    return (
        <div className="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full" data-sidebar-position="fixed" data-header-position="fixed">
            <div className="container-fluid">
                <div className="row">
                    <SideBar />
                    <div className="col-xl-9 col-lg-9 col-md-8">
                        <div className="card" style={{ backgroundColor: "#3d464d", color: "#FFF", borderRadius: "50px" }}>
                            <div className="container-fluid" style={{ minHeight: "60vh" }}>
                                <div className="col-lg-12 table-responsive mb-5">
                                    <div className="shopee-heading">
                                        <h3 style={{ color: "#fff", paddingTop:"25px" }}>Order History</h3>
                                    </div>
                                    <div className="search-container text-center mb-4">
                                        <TextField
                                            label="Search Orders"
                                            variant="outlined"
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            style={{ width: '50%' }}
                                        />
                                        <Select
                                            value={statusFilter}
                                            onChange={(e) => setStatusFilter(e.target.value)}
                                            displayEmpty
                                            style={{  width: '20%', marginLeft: '180px', backgroundColor: '#fff' }}
                                        >
                                            <MenuItem value="">All</MenuItem>
                                            <MenuItem value="Processing">Processing</MenuItem>
                                            <MenuItem value="Confirmed">Confirmed</MenuItem>
                                            <MenuItem value="Shipping">Shipping</MenuItem>
                                            <MenuItem value="Delivered">Delivered</MenuItem>
                                            <MenuItem value="Canceled">Canceled</MenuItem>
                                        </Select>
                                    </div>
                                    {isLoading ? (
                                        <div className="d-flex justify-content-center align-items-center" style={{ minHeight: "200px" }}>
                                            <div className="custom-loader"></div>
                                        </div>
                                    ) : pageData.length === 0 ? (
                                        <div className="text-center py-5">
                                            <h3>No Processing Orders</h3>
                                            <p className="mt-3">You have no orders being processed at the moment.</p>
                                        </div>
                                    ) : (
                                        <TableContainer component={Paper} className="table-container" style={{
                                            boxShadow: "0px 13px 20px 0px #80808029",
                                            borderRadius: "20px",
                                            width: "98%",
                                            backgroundColor: "#F0FFF0",
                                        }}>
                                            <Table sx={{ minWidth: 650 }} aria-label="simple table">
                                                <TableHead>
                                                    <TableRow style={{ backgroundColor: "#ff9200" }}>
                                                        <TableCell style={{ paddingLeft: "20px" }} align="left">Order Code</TableCell>
                                                        <TableCell align="left">Created At</TableCell>
                                                        <TableCell align="left">Payment Method</TableCell>
                                                        <TableCell align="left">Subtotal</TableCell>
                                                        <TableCell align="left">Total Quantity</TableCell>
                                                        <TableCell align="left">Status</TableCell>
                                                        <TableCell align="left">Details</TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {pageData.map((order, index) => (
                                                        <TableRow key={order.id} sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                                                            <TableCell style={{ paddingLeft: "25px" }} className="table-cell" scope="row">
                                                                {order.nameOrder}
                                                            </TableCell>
                                                            <TableCell className="table-cell" align="left">
                                                                {formatDateTime(order.createdAt)}
                                                            </TableCell>
                                                            <TableCell className="table-cell" align="left">
                                                                {order.paymentMethod}
                                                            </TableCell>
                                                            <TableCell className="table-cell" align="left">
                                                                {formatCurrency(order.subtotal)}
                                                            </TableCell>
                                                            <TableCell className="table-cell" align="left">
                                                                {order.totalQuantity}
                                                            </TableCell>
                                                            <TableCell className="table-cell" align="left">
                                                                <span className={`status-btn ${statusClass(order.status)}`}>
                                                                    {statusFormat(order.status)}
                                                                </span>
                                                            </TableCell>
                                                            <TableCell className="table-cell" align="left">
                                                                <Button variant="contained" color="primary" onClick={() => getOrderDetails(order.id)}>View Details</Button>
                                                            </TableCell>
                                                        </TableRow>
                                                    ))}
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    )}
                                    <Pagination
                                        pageCount={Math.ceil(filteredOrders.length / itemsPerPage)}
                                        pageRangeDisplayed={5}
                                        marginPagesDisplayed={2}
                                        onPageChange={handlePageClick}
                                        containerClassName={'pagination'}
                                        activeClassName={'active'}
                                    />
                                </div>
                                {isDetailOpen && (
                                    <Modal open={isDetailOpen} onClose={() => setIsDetailOpen(false)} className="product-detail-modal">
                                        <div className="modal-content">
                                            <div className="modal-header">
                                                <h5 className="modal-title">Order Details</h5>
                                                <Button variant="contained" color="primary" onClick={() => setIsDetailOpen(false)}>Close</Button>
                                            </div>
                                            <div className="modal-body">
                                                <TableContainer component={Paper} className="table-container">
                                                    <Table sx={{ minWidth: 650 }} aria-label="simple table">
                                                        <TableHead>
                                                            <TableRow>
                                                                <TableCell align="left">Product Image</TableCell>
                                                                <TableCell align="left">Product Name</TableCell>
                                                                <TableCell align="left">Color</TableCell>
                                                                <TableCell align="left">Quantity</TableCell>
                                                                <TableCell align="left">Price</TableCell>
                                                                <TableCell align="left">Total</TableCell>
                                                            </TableRow>
                                                        </TableHead>
                                                        <TableBody>
                                                            {orderDetails.map((detail, index) => (
                                                                <TableRow key={index}>
                                                                    <TableCell align="left">
                                                                        <img src={detail.image} alt={detail.nameProduct} className="additional-info-img" />
                                                                    </TableCell>
                                                                    <TableCell align="left">{detail.nameProduct}</TableCell>
                                                                    <TableCell align="left">{detail.color}</TableCell>
                                                                    <TableCell align="left">{detail.quantityProduct}</TableCell>
                                                                    <TableCell align="left">{formatCurrency(detail.priceProduct)}</TableCell>
                                                                    <TableCell align="left">{formatCurrency(detail.quantityProduct * detail.priceProduct)}</TableCell>
                                                                </TableRow>
                                                            ))}
                                                        </TableBody>
                                                    </Table>
                                                </TableContainer>
                                            </div>
                                        </div>
                                    </Modal>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Processing;
