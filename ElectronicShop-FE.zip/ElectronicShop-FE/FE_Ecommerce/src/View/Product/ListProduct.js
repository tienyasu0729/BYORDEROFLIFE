import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { f_getAllProduct_api, f_getAllReviewByProduct_api, f_getAllBrands_api, f_getAllCategory_api } from '../../config/api';
import axios from '../../config/customAxios';
import { toast } from 'react-toastify';
import "./listProduct.css";
import Pagination from "react-paginate";
import { formatCurrency } from '../../Validate/Validate';

const ListProduct = () => {
    const [isLoading, setIsLoading] = useState(false);
    const [products, setProducts] = useState([]);
    const [page, setPage] = useState(0);
    const [searchResults, setSearchResults] = useState([]);
    const [brands, setBrands] = useState([]);
    const [categories, setCategories] = useState([]);
    const location = useLocation();
    const token = localStorage.getItem('token'); // Get the token from localStorage

    const fetchProducts = async (pageNumber = 0, size = 9) => {
        setIsLoading(true);
        try {
            const response = await f_getAllProduct_api(pageNumber, size);
            if (response.data.status === 'success') {
                const productsWithReviews = await Promise.all(response.data.result.content.map(async product => {
                    const reviewsResponse = await f_getAllReviewByProduct_api(product.id);
                    if (reviewsResponse.data.status === 'success') {
                        const reviews = reviewsResponse.data.result;
                        const totalReviews = reviews.length;
                        const averageRating = totalReviews > 0 ? Math.floor(reviews.reduce((acc, review) => acc + review.rating, 0) / totalReviews) : 0;
                        return { ...product, totalReviews, averageRating };
                    } else {
                        return { ...product, totalReviews: 0, averageRating: 0 };
                    }
                }));
                setProducts(productsWithReviews);
                setPage(response.data.result);
                setSearchResults(productsWithReviews);
            } else {
                toast.error(response.data.message);
            }
        } catch (error) {
            toast.error(error.message);
        } finally {
            setIsLoading(false);
        }
    };

    const fetchFilters = async () => {
        try {
            const [brandsResponse, categoriesResponse] = await Promise.all([f_getAllBrands_api(), f_getAllCategory_api()]);

            if (brandsResponse.data.status === 'success') {
                setBrands(brandsResponse.data.result);
            } else {
                toast.error(brandsResponse.data.message);
            }

            if (categoriesResponse.data.status === 'success') {
                setCategories(categoriesResponse.data.result);
            } else {
                toast.error(categoriesResponse.data.message);
            }
        } catch (error) {
            toast.error(error.message);
        }
    };

    useEffect(() => {
        fetchProducts(0, 9);
        fetchFilters();
    }, []);

    useEffect(() => {
        if (location.search) {
            const searchQuery = new URLSearchParams(location.search).get('search');
            if (searchQuery) {
                const filteredProducts = products.filter((product) => {
                    return product.name.toLowerCase().includes(searchQuery.toLowerCase());
                });
                setSearchResults(filteredProducts);
            } else {
                setSearchResults(products);
            }
        } else {
            setSearchResults(products);
        }
    }, [location.search, products]);

    const handleCheckboxChangeByMoney = (event) => {
        const selectedPriceRange = event.target.value;
        let filteredProducts = [];
        if (selectedPriceRange === "all") {
            filteredProducts = products;
        } else {
            const [minPrice, maxPrice] = selectedPriceRange.split('-').map(Number);
            filteredProducts = products.filter(product => product.discountedPrice >= minPrice && (maxPrice ? product.discountedPrice <= maxPrice : true));
        }
        setSearchResults(filteredProducts);
    };

    const handleCheckboxChange = (type, event) => {
        const selectedValue = event.target.value.toLowerCase();
        let filteredProducts = products;

        if (type === 'brand') {
            if (selectedValue === 'all') {
                filteredProducts = products;
            } else {
                filteredProducts = products.filter(product => product.brandsName.toLowerCase() === selectedValue);
            }
        } else if (type === 'category') {
            if (selectedValue === 'all') {
                filteredProducts = products;
            } else {
                filteredProducts = products.filter(product => product.categoriesName.toLowerCase() === selectedValue);
            }
        }

        setSearchResults(filteredProducts);
    };

    const handleSortPriceAscending = () => {
        const sortedProducts = [...searchResults].sort((a, b) => a.discountedPrice - b.discountedPrice);
        setSearchResults(sortedProducts);
    };

    const handleSortPriceDescending = () => {
        const sortedProducts = [...searchResults].sort((a, b) => b.discountedPrice - a.discountedPrice);
        setSearchResults(sortedProducts);
    };

    const handleAddToWishlist = async (productId, price) => {
        if (!token) {
            toast.error('Bạn cần đăng nhập để thêm sản phẩm vào danh sách yêu thích', {
                position: toast.POSITION.TOP_CENTER,
                autoClose: 2000,
            });
            return;
        }

        try {
            const response = await axios.post('http://localhost:8080/api/wishlists/create-wishlist', {
                productId,
                price
            }, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });

            if (response.data.status === 'success') {
                if (response.data.message === "Đã Có Trong Wishlist") {
                    toast.warning(response.data.message, {
                        position: toast.POSITION.TOP_CENTER,
                        autoClose: 2000,
                    });
                } else {
                    toast.success('Đã thêm sản phẩm vào danh sách yêu thích', {
                        position: toast.POSITION.TOP_CENTER,
                        autoClose: 2000,
                    });
                }
            } else {
                toast.error('Không thể thêm sản phẩm vào danh sách yêu thích', {
                    position: toast.POSITION.TOP_CENTER,
                    autoClose: 2000,
                });
            }
        } catch (error) {
            toast.error('Có lỗi xảy ra, vui lòng thử lại sau', {
                position: toast.POSITION.TOP_CENTER,
                autoClose: 2000,
            });
        }
    };

    return (
        <>
            <div className="container-fluid">
                <div className="row px-xl-5">
                    <div className="col-12">
                        <nav className="breadcrumb mb-30" style={{ backgroundColor: "#1a1a1a", color: "#fff" }}>
                            <Link className="breadcrumb-item text-dark" style={{ textDecoration: "none" }} to="/">Home</Link>
                            <Link className="breadcrumb-item text-dark" style={{ textDecoration: "none" }} to="/list-product">Product</Link>
                            <span className="breadcrumb-item">Product List</span>
                        </nav>
                    </div>
                </div>
                <div className="row px-xl-5">
                    <div className="col-12 d-flex justify-content-end mb-3">
                        <button className="btn btn-outline-light mr-2" onClick={handleSortPriceAscending}>
                            <i className="fa fa-sort-amount-asc"></i> Price: Low to High
                        </button>
                        <button className="btn btn-outline-light" onClick={handleSortPriceDescending}>
                            <i className="fa fa-sort-amount-desc"></i> Price: High to Low
                        </button>
                    </div>
                </div>
                <div className="row px-xl-5">
                    <div className="col-lg-3 col-md-4">
                        <div className="filter-sidebar">
                            <h5 className="section-title position-relative text-uppercase mb-3">
                                <span className="pr-6" style={{ backgroundColor: "#1a1a1a", color: "#fff" }}>Filter by price</span>
                            </h5>
                            <div className="p-4 mb-30">
                                <form>
                                    <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                                        <input type="checkbox" className="custom-control-input" id="price-all" value="all" onChange={handleCheckboxChangeByMoney} defaultChecked />
                                        <label className="custom-control-label" htmlFor="price-all">All Price</label>
                                    </div>
                                    <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                                        <input type="checkbox" className="custom-control-input" id="price-1" value="0-500000" onChange={handleCheckboxChangeByMoney} />
                                        <label className="custom-control-label" htmlFor="price-1">0 - 500.000</label>
                                    </div>
                                    <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                                        <input type="checkbox" className="custom-control-input" id="price-2" value="500000-2000000" onChange={handleCheckboxChangeByMoney} />
                                        <label className="custom-control-label" htmlFor="price-2">500.000 - 3.000.000</label>
                                    </div>
                                    <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                                        <input type="checkbox" className="custom-control-input" id="price-3" value="3000000-7000000" onChange={handleCheckboxChangeByMoney} />
                                        <label className="custom-control-label" htmlFor="price-3">3.000.000 - 7.000.000</label>
                                    </div>
                                    <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between">
                                        <input type="checkbox" className="custom-control-input" id="price-6" value="7000000" onChange={handleCheckboxChangeByMoney} />
                                        <label className="custom-control-label" htmlFor="price-6">7.000.000 +</label>
                                    </div>
                                </form>
                            </div>

                            <h5 className="section-title position-relative text-uppercase mb-3">
                                <span className="pr-6" style={{ backgroundColor: "#1a1a1a", color: "#fff" }}>Filter by brand</span>
                            </h5>
                            <div className="p-4 mb-30">
                                <form>
                                    <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                                        <input type="checkbox" className="custom-control-input" id="brand-all" value="all" onChange={(e) => handleCheckboxChange('brand', e)} defaultChecked />
                                        <label className="custom-control-label" htmlFor="brand-all">All Brands</label>
                                    </div>
                                    {brands.map(brand => (
                                        <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3" key={brand.id}>
                                            <input type="checkbox" className="custom-control-input" id={`brand-${brand.id}`} value={brand.nameBrand} onChange={(e) => handleCheckboxChange('brand', e)} />
                                            <label className="custom-control-label" htmlFor={`brand-${brand.id}`}>{brand.nameBrand}</label>
                                        </div>
                                    ))}
                                </form>
                            </div>

                            <h5 className="section-title position-relative text-uppercase mb-3">
                                <span className="pr-6" style={{ backgroundColor: "#1a1a1a", color: "#fff" }}>Filter by category</span>
                            </h5>
                            <div className="p-4 mb-30">
                                <form>
                                    <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                                        <input type="checkbox" className="custom-control-input" id="category-all" value="all" onChange={(e) => handleCheckboxChange('category', e)} defaultChecked />
                                        <label className="custom-control-label" htmlFor="category-all">All Categories</label>
                                    </div>
                                    {categories.map(category => (
                                        <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3" key={category.id}>
                                            <input type="checkbox" className="custom-control-input" id={`category-${category.id}`} value={category.nameCategory} onChange={(e) => handleCheckboxChange('category', e)} />
                                            <label className="custom-control-label" htmlFor={`category-${category.id}`}>{category.nameCategory}</label>
                                        </div>
                                    ))}
                                </form>
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-9 col-md-8 list-product-container">
                        <div className="row pb-3">
                            {isLoading ? (
                                <div className='loading'>
                                    <div className="custom-loader"></div>
                                </div>
                            ) : (
                                searchResults.map((listProduct) => (
                                    <div className="col-lg-4 col-md-6 col-sm-6 pb-1" key={listProduct.id}>
                                        <div className="product-item mb-4" style={{ backgroundColor: "#262626" }}>
                                            <div className="product-img position-relative overflow-hidden">
                                                <img className="img-fluid w-100" style={{ height: "300px" }} src={listProduct.image} alt="" />
                                                <div className="product-action">
                                                    <Link className="btn btn-outline-dark btn-square" to={`/product-detail/${listProduct.id}`}><i className="fa fa-search"></i></Link>
                                                </div>
                                            </div>
                                            <div className="text-left py-4">
                                                <Link className="h6 text-decoration-none text-truncate product-name" style={{ color: "#fff" }} to={`/product-detail/${listProduct.id}`}>{listProduct.name}</Link>
                                                <div className="d-flex align-items-center justify-content-between mt-2" style={{ color: "#fff" }}>
                                                    <div>
                                                        <h5>{formatCurrency(listProduct.discountedPrice)}</h5>
                                                        <h6 className="text-muted" style={{ textDecoration: "line-through" }}>
                                                            <del>{formatCurrency(listProduct.price)}</del>
                                                        </h6>
                                                    </div>
                                                    <div className="heart-icon" onClick={() => handleAddToWishlist(listProduct.id, listProduct.discountedPrice)}>
                                                        <i className="fa-solid fa-heart" style={{ color: "#FFD333", fontSize: "30px", cursor: "pointer" }}></i>
                                                    </div>
                                                </div>
                                                <div className="d-flex align-items-center justify-content-start mb-1">
                                                    {Array(listProduct.averageRating).fill().map((_, i) => (
                                                        <small key={i} className="fa fa-star text-primary mr-1"></small>
                                                    ))}
                                                    {Array(5 - listProduct.averageRating).fill().map((_, i) => (
                                                        <small key={i} className="far fa-star text-primary mr-1"></small>
                                                    ))}
                                                    <small>({listProduct.totalReviews})</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                        <Pagination
                            pageCount={page.totalPages}
                            pageRangeDisplayed={5}
                            marginPagesDisplayed={2}
                            onPageChange={({ selected }) => fetchProducts(selected + 0, 9)}
                            containerClassName={'pagination'}
                            activeClassName={'active'}
                        />
                    </div>
                </div>
            </div>
        </>
    );
}

export default ListProduct;
