import React, { useEffect, useReducer, useState } from 'react';
import "./productDetail.css";
import { useNavigate, useParams, Link } from 'react-router-dom';
import { f_getAllProductId_api, f_getAllReviewByProduct_api } from '../../../config/api';
import axios from '../../../config/customAxios';
import { toast } from 'react-toastify';
import { convertBase64ToBlob, formatCurrency } from '../../../Validate/Validate';
import { Carousel } from 'react-bootstrap';
import Rating from '@mui/material/Rating';

// Define initial state and reducer for useReducer
const initialState = {
  product: {
    name: "",
    slug: "",
    description: "",
    information: '',
    summary: "",
    stock: 0,
    price: "",
    discounted_price: "",
    image: "",
    image2: "",
    image3: "",
    status: "",
    colorName: "",
    quantity: 1,
  },
  listColor: [],
  reviews: [],
  isLoading: false,
  activeTab: "tab-pane-1",
};

function reducer(state, action) {
  switch (action.type) {
    case 'SET_PRODUCT':
      return {
        ...state,
        product: action.payload.product,
        listColor: action.payload.colors,
      };
    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload,
      };
    case 'SET_ACTIVE_TAB':
      return {
        ...state,
        activeTab: action.payload,
      };
    case 'SET_QUANTITY':
      return {
        ...state,
        product: { ...state.product, quantity: action.payload },
      };
    case 'SET_COLOR_NAME':
      return {
        ...state,
        product: { ...state.product, colorName: action.payload },
      };
    case 'SET_REVIEWS':
      return {
        ...state,
        reviews: action.payload,
      };
    default:
      return state;
  }
}

const ProductDetails = () => {
  const [state, dispatch] = useReducer(reducer, initialState);
  const token = localStorage.getItem('token');
  const navigate = useNavigate();
  const { id } = useParams();

  const [comment, setComment] = useState("");
  const [rating, setRating] = useState(5);

  const getProductById = async () => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const res = await f_getAllProductId_api(id);
      if (res.data.status === 'not found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'success') {
        const product = res.data.result.product;
        product.quantity = 1;
        dispatch({
          type: 'SET_PRODUCT',
          payload: {
            product: res.data.result.product,
            colors: res.data.result.colors || [],
          }
        });
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const getReviewsByProductId = async () => {
    try {
      const res = await f_getAllReviewByProduct_api(id);
      if (res.data.status === 'success') {
        dispatch({ type: 'SET_REVIEWS', payload: res.data.result });
      } else {
        toast.warning(res.data.message);
      }
    } catch (error) {
      toast.error(error.message);
    }
  };

  useEffect(() => {
    getProductById();
    getReviewsByProductId();
  }, [id]);

  const handleTabChange = (tabId) => {
    if (state.activeTab !== tabId) {
      dispatch({ type: 'SET_ACTIVE_TAB', payload: tabId });
    }
  };

  const handleAddToCart = async (e) => {
    if (!token) {
      navigate("/login");
      return;
    }
    e.preventDefault();

    const dataCart = {
      productId: id,
      quantity: state.product.quantity,
      nameColor: state.product.colorName,
      price: state.product.discounted_price,
    };
    if (!dataCart.nameColor) {
      toast.warning('Please select color');
      return;
    }
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const res = await axios.post('/carts/create-cart', dataCart);
      if (res.data.status === 'not-found') {
        toast.warning(res.data.message);
      } else if (res.data.status === 'Conflict') {
        toast.error(res.data.message);
      } else if (res.data.status === 'success') {
        window.history.go(0);
        toast.success(res.data.message);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const handleQuantityIncrement = () => {
    dispatch({ type: 'SET_QUANTITY', payload: Math.min(state.product.quantity + 1, state.product.stock) });
  };

  const handleQuantityDecrement = () => {
    dispatch({ type: 'SET_QUANTITY', payload: Math.max(state.product.quantity - 1, 1) });
  };

  const handleSubmitComment = async (e) => {
    if (!token) {
      navigate("/login");
      return;
    }
    e.preventDefault();

    if (!comment.trim()) {
      toast.warning('Please enter a comment.');
      return;
    }

    const dataReview = {
      productId: id,
      rating,
      comment,
    };

    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const res = await axios.post('/reviews/create-review', dataReview, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (res.data.status === 'success') {
        toast.success('Review submitted successfully!');
        getReviewsByProductId(); // Refresh the reviews
        setComment("");
        setRating(5);
      } else {
        toast.error(res.data.message);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const renderStars = (rating) => {
    return <Rating value={rating} readOnly />;
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <>
      <div className="container-fluid">
        <div className="row px-xl-5">
          <div className="col-12">
            <nav className="breadcrumb mb-30" style={{  color: "#fff" }}>
              <Link className="breadcrumb-item text-dark" to="/">Home</Link>
              <Link className="breadcrumb-item text-dark" to="/shop">Shop</Link>
              <span className="breadcrumb-item active">Shop Detail</span>
            </nav>
          </div>
        </div>
      </div>
      <div className="container-fluid pb-5">
        <div className="row px-xl-5">
          <div className="col-lg-6 mb-30">
            <Carousel>
              <Carousel.Item>
                <img className="w-100" style={{ height: "500px" }}
                  src={convertBase64ToBlob(state.product.image)}
                  alt="Image" />
              </Carousel.Item>
              <Carousel.Item>
                <img className="w-100" style={{ height: "500px" }}
                  src={convertBase64ToBlob(state.product.image2)}
                  alt="Image" />
              </Carousel.Item>
              <Carousel.Item>
                <img className="w-100" style={{ height: "500px" }}
                  src={convertBase64ToBlob(state.product.image3)}
                  alt="Image" />
              </Carousel.Item>
            </Carousel>
          </div>

          <div className="col-lg-6 h-auto mb-30">
            <div className="h-100 p-30" style={{color:"#fff",backgroundColor:"#262626"}}>
              <h4 style={{color:"#fff",fontWeight:600}}>{state.product.name}</h4>
            
            {/* <div className=' d-flex mt-2'>
            <h3 className="font-weight-semi-bold mb-4"  style={{color:"#fff"}}>
                {formatCurrency(state.product.discountedPrice)}
              </h3>
              <h3 className='ml-2 d-flex'>
                <span className="text-muted mr-2" style={{ textDecoration: "line-through" }}>
                  <del>{formatCurrency(state.product.price)}</del>
                </span>
                </h3>
            </div> */}
            <div className="d-flex" style={{color:"#fff"}}>
                  <h3 class="font-weight-semi-bold mb-4" style={{color:"#e48d0a"}}>{formatCurrency(state.product.discountedPrice)}</h3> <h3 className="ml-2" ><del>{formatCurrency(state.product.price)}</del></h3>
                  </div>
              <p className="mb-4"><strong>Description: </strong>{state.product.summary}</p>
              <div className="d-flex mb-3">
                <strong className="text-light mr-3">Colors:</strong>
                <div>
                  {state.listColor.map((color, index) => (
                    <div key={index} className="custom-control custom-radio custom-control-inline">
                      <input type="radio" className="custom-control-input" onChange={(e) => dispatch({ type: 'SET_COLOR_NAME', payload: e.target.value })} id={color.id} name="color" value={color.nameColor} />
                      <label className="custom-control-label" htmlFor={color.id}>{color.nameColor}</label>
                    </div>
                  ))}
                </div>
              </div>
              <div className="d-flex mb-4">
                <strong className="text-light mr-3">Stock:</strong>
                <span>{state.product.stock}</span>
              </div>
              <div className="d-flex align-items-center mb-4 pt-2">
                <div className="input-group quantity mr-3" style={{ width: "130px" }}>
                  <div className="input-group-btn">
                    <button className="btn btn-primary btn-minus" onClick={handleQuantityDecrement} >
                      <i className="fa fa-minus"></i>
                    </button>
                  </div>
                  <input type="text" className="form-control bg-secondary border-0 text-center" value={state.product.quantity} onChange={(e) => dispatch({ type: 'SET_QUANTITY', payload: parseInt(e.target.value) || 1 })} />
                  <div className="input-group-btn">
                    <button className="btn btn-primary btn-plus" onClick={handleQuantityIncrement}>
                      <i className="fa fa-plus"></i>
                    </button>
                  </div>
                </div>
                {state.product.stock > 0 ? (
                  <button className="btn btn-primary px-3" onClick={handleAddToCart}><i className="fa fa-shopping-cart mr-1"></i> Add To Cart</button>
                ) : (
                  <button className="btn btn-danger px-3" disabled>
                  <i className="bi bi-cart-x me-1"></i>
                  Sold Out
                </button>
                )}
              </div>
              <div className="d-flex pt-2">
                <strong className="text-light mr-2">Share on:</strong>
                <div className="d-inline-flex">
                  <Link className="text-light px-2" to="">
                    <i className="fab fa-facebook-f"></i>
                  </Link>
                  <Link className="text-light px-2" to="">
                    <i className="fab fa-twitter"></i>
                  </Link>
                  <Link className="text-light px-2" to="">
                    <i className="fab fa-linkedin-in"></i>
                  </Link>
                  <Link className="text-light px-2" to="">
                    <i className="fab fa-pinterest"></i>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row px-xl-5">
          <div className="col-12">
            <div className="p-30" style={{color:"#fff", backgroundColor:"#262626"}}>
              <div className="nav nav-tabs mb-4">
                <Link
                  className={`nav-item nav-link text-light ${state.activeTab === "tab-pane-1" ? "active active-bg" : ""}`}
                  onClick={() => handleTabChange("tab-pane-1")}
                >
                  Description
                </Link>
                <Link
                  className={`nav-item nav-link text-light ${state.activeTab === "tab-pane-2" ? "active active-bg" : ""}`}
                  onClick={() => handleTabChange("tab-pane-2")}
                >
                  Information
                </Link>
                <Link
                  className={`nav-item nav-link text-light ${state.activeTab === "tab-pane-3" ? "active active-bg" : ""}`}
                  onClick={() => handleTabChange("tab-pane-3")}
                >
                  Reviews ({state.reviews.length})
                </Link>
              </div>
              <div className="tab-content">
                <div
                  className={`tab-pane fadeIn ${state.activeTab === "tab-pane-1" ? "show active" : ""}`}
                  id="tab-pane-1"
                >
                  <h4 className="mb-3 text-light">Product Description</h4>
                  <p>{state.product.description}</p>
                </div>
                <div
                  className={`tab-pane ${state.activeTab === "tab-pane-2" ? "show active fadeIn" : ""}`}
                  id="tab-pane-2"
                >
                  <h4 className="mb-3 text-light">Additional Information</h4>
                  <p className='wrapper'>{state.product.information}</p>
                  <div className="row">
                    <div className="col-md-4 mb-3 additional-info-img-container">
                      <img
                        className="img-fluid additional-info-img"
                        src={convertBase64ToBlob(state.product.image)}
                        alt="Image" style={{height: "330px",
                          width:"100%" }}
                      />
                    </div>
                    <div className="col-md-4 mb-3 additional-info-img-container">
                      <img
                        className="img-fluid additional-info-img"
                        src={convertBase64ToBlob(state.product.image2)}
                        alt="Image"
                        style={{height: "330px",
                          width:"100%" }}
                      />
                    </div>
                    <div className="col-md-4 mb-3 additional-info-img-container">
                      <img
                        className="img-fluid additional-info-img"
                        src={convertBase64ToBlob(state.product.image3)}
                        alt="Image"
                        style={{height: "330px",
                          width:"100%" }}
                      />
                    </div>
                  </div>
                
                </div>
                <div
                  className={`tab-pane ${state.activeTab === "tab-pane-3" ? "show active fadeIn" : "" }` }
                  id="tab-pane-3"
                >
                  {state.reviews.length > 0 ? (
                    <div className="row ">
                      <div className="col-md-12 d-flex" style={{justifyContent:"space-around"}}>
                        {state.reviews.map((review) => (
                          <div key={review.id} className="media mb-4">
                            <img
                              src={review.avatar}
                              alt="Avatar"
                              className="img-fluid mr-3 mt-1 rounded-avatar"
                            />
                            <div className="media-body">
                              <h6>{review.nameUser}</h6> <small className="text-muted">{formatDate(review.createdAt)}</small>
                              <div>{renderStars(review.rating)}</div>
                              <p>{review.comment}</p>
              
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="row ">
                      <div className="col-md-6">
                        <p>No reviews for this product yet.</p>
                        <i className="fa-thin fa-comment-slash"></i>
                      </div>
                    </div>
                  )}
                  <div className="row ">
                    <div className="col-md-6 ">
                      <h4 className="mb-4 text-light ">Feedback a product</h4>
                      <div>
                        <div className="form-group">
                          <label htmlFor="rating">Your Rating *</label>
                          <Rating
                            name="rating"
                            value={rating}
                            onChange={(event, newValue) => setRating(newValue)}
                          />
                        </div>
                        <div className="form-group">
                          <label htmlFor="message">Your Review *</label>
                          <textarea
                            id="message"
                            cols="30"
                            rows="5"
                            className="form-control"
                            value={comment}
                            onChange={(e) => setComment(e.target.value)}
                          ></textarea>
                        </div>
                        <div className="form-group mb-0">
                          <button className="btn btn-primary px-3" onClick={handleSubmitComment}>Leave Your Review</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ProductDetails;
