document.addEventListener("DOMContentLoaded", () => {
    const realtimeChatbox = document.querySelector("#realtime-chatbox");
    const realtimeChatInput = document.querySelector("#realtime-chat-input");
    const realtimeSendChatBtn = document.querySelector("#realtime-send-btn");
    const connectBtn = document.querySelector("#connect-btn");
    const userNameInput = document.querySelector("#user-name");

    let stompClient = null;
    let privateChats = [];
    let userData = {
        username: '',
        connected: false,
        message: ''
    };

    const createChatLi = (message, className) => {
        const chatLi = document.createElement("li");
        chatLi.classList.add("chat", className);
        chatLi.innerHTML = `<p>${message}</p>`;
        return chatLi;
    };

    const connect = () => {
        const socket = new SockJS('http://localhost:8080/ws');
        stompClient = Stomp.over(socket);
        stompClient.connect({}, onConnected, onError);
    };

    const onConnected = () => {
        userData.connected = true;
        stompClient.subscribe('/user/' + userData.username + '/private', onPrivateMessage);
        userJoin();
    };

    const userJoin = () => {
        const chatMessage = {
            senderName: userData.username,
            status: "JOIN"
        };
        stompClient.send("/app/message", {}, JSON.stringify(chatMessage));
    };

    const onPrivateMessage = (payload) => {
        const payloadData = JSON.parse(payload.body);
        privateChats.push(payloadData);
        realtimeChatbox.appendChild(createChatLi(payloadData.message, 'incoming'));
        realtimeChatbox.scrollTo(0, realtimeChatbox.scrollHeight);
    };

    const onError = (err) => {
        console.log(err);
    };

    const handleMessage = (event) => {
        userData.message = event.target.value;
    };

    const sendValue = () => {
        if (stompClient) {
            const chatMessage = {
                senderName: userData.username,
                receiverName: "Admin",
                message: userData.message,
                status: "MESSAGE"
            };
            privateChats.push(chatMessage);
            realtimeChatbox.appendChild(createChatLi(chatMessage.message, 'outgoing'));
            stompClient.send("/app/private-message", {}, JSON.stringify(chatMessage));
            userData.message = "";
            realtimeChatInput.value = "";
            realtimeChatbox.scrollTo(0, realtimeChatbox.scrollHeight);
        }
    };

    const handleUsername = (event) => {
        userData.username = event.target.value;
    };

    connectBtn.addEventListener("click", () => {
        connect();
    });

    realtimeSendChatBtn.addEventListener("click", sendValue);
    realtimeChatInput.addEventListener("input", handleMessage);
    userNameInput.addEventListener("input", handleUsername);

    realtimeChatInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            sendValue();
        }
    });
});
