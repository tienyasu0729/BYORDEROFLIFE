
 package com.DSTA.PJ_BE.controller;

 import com.DSTA.PJ_BE.dto.ColorDTO.ColorDto;
 import com.DSTA.PJ_BE.service.ColorService;
 import com.DSTA.PJ_BE.utils.DataResponse;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.security.access.prepost.PreAuthorize;
 import org.springframework.web.bind.annotation.*;

 @RestController
 @RequestMapping("/api/colors")
 public class ColorController {
     private final Logger log = LoggerFactory.getLogger(ColorController.class);

     @Autowired
     private ColorService colorService;

     @PostMapping("/create-color")
     @PreAuthorize("hasRole('ROLE_ADMIN')")
     public DataResponse createColor(@RequestBody ColorDto colorDto){
         log.debug("Controller Request Create New Color");
         DataResponse res = colorService.addNewColor(colorDto);
         return res;
     }

     @GetMapping("/get-all-colors")
     public DataResponse getAllColors(){
         log.debug("Controller Request Get All Colors");
         DataResponse res = colorService.getAllColors();
         return res;
     }

     @DeleteMapping("/delete-color/{id}")
     @PreAuthorize("hasRole('ROLE_ADMIN')")
     public DataResponse deleteColor(@PathVariable("id") Long id){
         log.debug("Controller Request Delete Color");
         DataResponse res = colorService.deleteColor(id);
         return res;
     }

     @PutMapping("/update-color/{id}")
     @PreAuthorize("hasRole('ROLE_ADMIN')")
     public DataResponse updateColor(@RequestBody ColorDto colorDto, @PathVariable("id") Long id){
         log.debug("Controller Request Update Color");
         DataResponse res = colorService.updateColor(colorDto, id);
         return res;
     }
 }
