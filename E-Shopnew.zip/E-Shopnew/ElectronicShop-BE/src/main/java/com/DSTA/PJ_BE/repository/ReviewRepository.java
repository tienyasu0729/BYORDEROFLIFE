package com.DSTA.PJ_BE.repository;

import com.DSTA.PJ_BE.dto.Review.ReviewDtoitf;
import com.DSTA.PJ_BE.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    // Tìm kiếm review theo sản phẩm
    @Query("SELECT r FROM Review r WHERE r.product.id = :productId")
    List<Review> findByProductId(@Param("productId") Long productId);
    @Query(value = "SELECT u.name as nameUser, r.created_at as createdAt, u.avatar as avatar, r.comment as comment, r.rating as rating, r.id as id, p.id as productId, p.name_product as productName, p.image as productImage " +
            "FROM Review r " +
            "JOIN User u ON r.user_id = u.id " +
            "JOIN Product p ON r.product_id = p.id", nativeQuery = true)
    List<ReviewDtoitf> getAll();

    // Tìm kiếm review theo người dùng
    @Query("SELECT r FROM Review r WHERE r.user.id = :userId")
    List<Review> findByUserId(@Param("userId") Long userId);

    @Query(value = "SELECT r FROM Review r WHERE r.user.id = :userId AND r.product.id = :productId")
    List<Review> findByUserIdAndProductId(@Param("userId") Long userId, @Param("productId") Long productId);

    @Query(value = "SELECT u.name as nameUser, r.created_at as createdAt, u.avatar as avatar, r.comment as comment, r.rating as rating, r.id as id, p.id as productId, p.name_product as productName, p.image as productImage " +
            "FROM Review r " +
            "JOIN User u ON r.user_id = u.id " +
            "JOIN Product p ON r.product_id = p.id " +
            "WHERE r.user_id = :id", nativeQuery = true)
    List<ReviewDtoitf> getAllReviewItems(@Param("id") Long id);


    @Query(value = "SELECT u.name as nameUser, r.created_at as createdAt, u.avatar as avatar, r.comment as comment, r.rating as rating, r.id as id, p.id as productId, p.name_product as productName, p.image as productImage " +
            "FROM Review r " +
            "JOIN User u ON r.user_id = u.id " +
            "JOIN Product p ON r.product_id = p.id " +
            "WHERE r.product_id = :productId", nativeQuery = true)
    List<ReviewDtoitf> getAllReviewItemsByProductId(@Param("productId") Long productId);
}