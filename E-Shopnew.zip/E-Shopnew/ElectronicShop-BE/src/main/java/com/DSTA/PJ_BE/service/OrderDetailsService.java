package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.dto.OrderDetails.OrderDetailsDTO;
import com.DSTA.PJ_BE.utils.DataResponse;

public interface OrderDetailsService {
    DataResponse getOrderDetailsByOrderId(Long orderId);
    DataResponse getRevenue();
}