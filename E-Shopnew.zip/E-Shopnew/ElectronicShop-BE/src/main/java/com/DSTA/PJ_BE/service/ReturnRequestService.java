package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.dto.ReturnRequest.ReturnRequestDTO;
import com.DSTA.PJ_BE.utils.DataResponse;

public interface ReturnRequestService {
    DataResponse createReturnRequest(ReturnRequestDTO returnRequestDTO);
    DataResponse getAllReturnRequests();
    DataResponse getReturnRequestById(Long id);
    DataResponse updateReturnRequest(Long id, ReturnRequestDTO returnRequestDTO);
    DataResponse deleteReturnRequest(Long id);
}
