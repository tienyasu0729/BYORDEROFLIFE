package com.DSTA.PJ_BE.controller;

import com.DSTA.PJ_BE.entity.Coupon;
import com.DSTA.PJ_BE.service.CouponService;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/coupons")
public class CouponController {
    private final Logger log = LoggerFactory.getLogger(CouponController.class);

    @Autowired
    private CouponService couponService;

    @PostMapping("/create-coupon")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse createCoupon(@RequestBody Coupon coupon){
        log.debug("Controller Request Create Coupon");
        DataResponse res = couponService.createCoupon(coupon);
        return res;
    }

    @GetMapping("/get-all-coupons")
    public DataResponse getAllCoupons(){
        log.debug("Controller Request Get All Coupons");
        DataResponse res = couponService.getAllCoupons();
        return res;
    }

    @PutMapping("/update-coupon/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse updateCoupon(@PathVariable("id") Long id, @RequestBody Coupon coupon){
        log.debug("Controller Request Update Coupon");
        DataResponse res = couponService.updateCoupon(id, coupon);
        return res;
    }

    @DeleteMapping("/delete-coupon/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse deleteCoupon(@PathVariable("id") Long id){
        log.debug("Controller Request Delete Coupon");
        DataResponse res = couponService.deleteCoupon(id);
        return res;
    }
}
