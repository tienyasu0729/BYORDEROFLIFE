package com.DSTA.PJ_BE.dto.Account;

import java.io.IOException;

import com.DSTA.PJ_BE.utils.Common;

public class AccountViewDto {
    private Long id;
    private String name;
    private String dob;
    private String tel;
    private String gender;
    private String address;
    private String avatar;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // Getter và Setter cho name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter và Setter cho dob
    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    // Getter và Setter cho tel
    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    // Getter và Setter cho gender
    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    // Getter và Setter cho address
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Getter và Setter cho avatar
    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        try {
            this.avatar = Common.convertToBase64(avatar);
        } catch (IOException e) {
            this.avatar = avatar;
        }
    }
}