package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.dto.WishList.WishListDTO;
import com.DSTA.PJ_BE.dto.WishList.WishListDtoItf;
import com.DSTA.PJ_BE.dto.WishList.WishListViewDto;
import com.DSTA.PJ_BE.entity.Product;
import com.DSTA.PJ_BE.entity.Account;
import com.DSTA.PJ_BE.entity.WishList;
import com.DSTA.PJ_BE.repository.WishListRepository;
import com.DSTA.PJ_BE.repository.ProductRepository;
import com.DSTA.PJ_BE.repository.AccountRepository;
import com.DSTA.PJ_BE.service.WishListService;
import com.DSTA.PJ_BE.utils.Common;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class WishListServiceImp implements WishListService {
    private final Logger log = LoggerFactory.getLogger(WishListServiceImp.class);

    @Autowired
    private WishListRepository wishListRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private ModelMapper mapper;

    @Override
    public DataResponse createWishList(WishListDTO wishListDTO) {
        log.debug("Request Create WishList");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            Product product = productRepository.getProductByID(wishListDTO.getProductId());
            WishList list = mapper.map(wishListDTO, WishList.class);

            if (product == null || account == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.NOT_FOUND);
                return res;
            }

            List<WishList> existingWishListItems = wishListRepository.findByUserIdAndProductId(account.getId(), product.getId());

            if (!existingWishListItems.isEmpty()){
                boolean isMatchFound = false;
                for (WishList existingWishListItem : existingWishListItems) {
                    if (existingWishListItem.getProduct().getId().equals(wishListDTO.getProductId())) {
                        res.setMessage(Constants.ALREADY_IN_WISHLIST);
                        res.setResult(existingWishListItem);
                        isMatchFound = true;
                        break;
                    }
                }

                if (!isMatchFound) {
                    list.setUser(account);
                    list.setProduct(product);
                    list.setPrice(product.getPrice());
                    wishListRepository.save(list);
                    res.setMessage(Constants.ADD_SUCCESS);
                }
            }else{
                list.setUser(account);
                list.setProduct(product);
                list.setPrice(product.getPrice());
                wishListRepository.save(list);
                res.setMessage(Constants.ADD_SUCCESS);
            }

            res.setStatus(Constants.SUCCESS);
            res.setResult(list);
            return res;
        } catch (Exception ex) {
            log.error("Message Add To WishList___BUG: " + ex.getMessage());
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getAllWishLists() {
        log.debug("Request Get All Wish List");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            List<WishListDtoItf> wishList = wishListRepository.getAllWL(account.getId());

            if(wishList == null || wishList.isEmpty()){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            List<WishListViewDto> result = Common.mapList(wishList, WishListViewDto.class);
            res.setStatus(Constants.SUCCESS);
            res.setResult(result);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }



    @Override
    public DataResponse deleteWishList(Long id) {
        log.debug("Request Delete Wish List");
        DataResponse res = new DataResponse();
        try {
            WishList list = wishListRepository.getWLbyID(id);
            if(list == null){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            wishListRepository.delete(list);
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.DELETE_SUCCESS);
            return res;

        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
}