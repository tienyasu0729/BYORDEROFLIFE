package com.DSTA.PJ_BE.dto.Categories;

public interface CategoriesViewAllDtoInf {
    Long getId();
    String getNameCategory();
    String getSlugCategory();
    String getImgCategory();
}
