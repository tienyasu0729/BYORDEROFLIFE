package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.dto.Categories.CategoriesADto;
import com.DSTA.PJ_BE.dto.Categories.CategoriesGetAllDto;
import com.DSTA.PJ_BE.dto.Categories.CategoriesViewAllDtoInf;
import com.DSTA.PJ_BE.entity.Account;
import com.DSTA.PJ_BE.entity.Categories;
import com.DSTA.PJ_BE.repository.CategoryRepository;
import com.DSTA.PJ_BE.service.CategoriesService;
import com.DSTA.PJ_BE.utils.Common;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class CategoriesServiceImp implements CategoriesService {
    private final Logger log = LoggerFactory.getLogger(CategoriesServiceImp.class);

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ModelMapper mapper;

//    @Override
//    @Transactional
//    public DataResponse addNewCategories(MultipartFile file, String str) {
//        log.debug("Request Add New Categories");
//        DataResponse res = new DataResponse();
//        Account account = Common.getCurrentUserLogin();
//        Categories categories =  new Categories();
//        try {
//            CategoriesADto categoriesADto = Common.convertStringToObject(str, CategoriesADto.class);
//            categories = mapper.map(categoriesADto, Categories.class);
//
//            if(categoriesADto.getName().length() < 5 || categoriesADto.getSlug().length()<5){
//                res.setStatus(Constants.ERROR);
//                res.setMessage(Constants.ERROR_ADD_NEW_CATEGORIES);
//                return res;
//            }
//            String imageUrl = Constants.IMG_CATEGORY_SAVE + account.getId() + "/" + Common.currentDate()+ "/";
//            String img = Common.saveFile(file, imageUrl, account.getId(), categories.getName());
//            if (img != null){
//                categories.setImageCategory(img);
//            }
//            categories.setName(categoriesADto.getName());
//            categories.setSlug(categoriesADto.getSlug());
//            categoryRepository.save(categories);
//            res.setStatus(Constants.SUCCESS);
//            res.setMessage(Constants.ADD_CATEGORIES_SUCCESS);
//            res.setResult(categories);
//            return res;
//        }catch (Exception ex){
//            res.setStatus(Constants.ERROR);
//            res.setMessage(Constants.SYSTEM_ERROR);
//            return res;
//        }
//    }
@Override
@Transactional
public DataResponse addNewCategories(MultipartFile file, String str) {
    log.debug("Request Add New Categories");
    DataResponse res = new DataResponse();
    Account account = Common.getCurrentUserLogin();
    Categories categories = new Categories();
    try {
        // Log chuỗi đầu vào
        log.debug("Chuỗi để chuyển đổi: {}", str);

        // Chuyển đổi chuỗi sang đối tượng CategoriesADto
        CategoriesADto categoriesADto = Common.convertStringToObject(str, CategoriesADto.class);

        // Log đối tượng sau khi chuyển đổi
        log.debug("Đối tượng CategoriesADto sau khi chuyển đổi: {}", categoriesADto);

        // Kiểm tra nếu đối tượng categoriesADto là null
        if (categoriesADto == null) {
            res.setStatus(Constants.ERROR);
            res.setMessage("Chuyển đổi chuỗi thất bại");
            return res;
        }

        if (categoriesADto.getName().length() < 5 || categoriesADto.getSlug().length() < 5) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.ERROR_ADD_NEW_CATEGORIES);
            return res;
        }

        // Log thông tin file
        log.debug("File nhận được: {}", file.getOriginalFilename());

        String imageUrl = Constants.IMG_CATEGORY_SAVE + account.getId() + "/" + Common.currentDate() + "/";
        String img = Common.saveFile(file, imageUrl, account.getId(), categories.getName());

        // Log URL hình ảnh đã lưu
        log.debug("URL hình ảnh đã lưu: {}", img);

        if (img != null) {
            categories.setImageCategory(img);
        }
        categories.setName(categoriesADto.getName());
        categories.setSlug(categoriesADto.getSlug());
        categoryRepository.save(categories);
        res.setStatus(Constants.SUCCESS);
        res.setMessage(Constants.ADD_CATEGORIES_SUCCESS);
        res.setResult(categories);
        return res;
    } catch (Exception ex) {
        // Log ngoại lệ
        log.error("Ngoại lệ xảy ra khi thêm mới danh mục", ex);
        res.setStatus(Constants.ERROR);
        res.setMessage(Constants.SYSTEM_ERROR);
        return res;
    }
}


    @Override
    public DataResponse getAllCategories() {
        log.debug("Requtest Get All Categories");
        DataResponse res = new DataResponse();
        try {
            List<CategoriesViewAllDtoInf> listCate = categoryRepository.getAllCate();
            if(listCate == null || listCate.isEmpty()){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.CATEGORIES_NOT_FOUND);
                return res;
            }
            List<CategoriesGetAllDto> cateList = Common.mapList(listCate, CategoriesGetAllDto.class);
            res.setStatus(Constants.SUCCESS);
            res.setResult(cateList);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse deleteCategories(Long id) {
        log.debug("Request Delete Categories");
        DataResponse res = new DataResponse();
        Account account = Common.getCurrentUserLogin();
        try {
            Categories categories = categoryRepository.getCategoryByID(id);
            if(categories == null){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.CATEGORIES_NOT_FOUND);
                return res;
            }
            //String imgPath = Constants.IMG_CATEGORY_SAVE + account.getId();
            categoryRepository.delete(categories);
            //Common.deleteImageFolder(imgPath);


            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.DELETE_SUCCESS);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

//    @Override
//    public DataResponse updateCategory(MultipartFile file, String str, Long id) {
//        log.debug("Request Update Categories");
//        DataResponse res = new DataResponse();
//        Account account = Common.getCurrentUserLogin();
//
//        try {
//            // Chuyển đổi chuỗi JSON thành đối tượng CategoriesADto
//            CategoriesADto categoriesADto = Common.convertStringToObject(str, CategoriesADto.class);
//            // Lấy thông tin danh mục hiện tại dựa trên id
//            Categories categories = categoryRepository.getCategoryByID(id);
//
//            // Kiểm tra điều kiện dữ liệu đầu vào
//            if(categoriesADto.getName().length() < 5 || categoriesADto.getSlug().length() < 5){
//                res.setStatus(Constants.ERROR);
//                res.setMessage(Constants.ERROR_ADD_NEW_CATEGORIES);
//                return res;
//            }
//
//            // Xử lý tệp hình ảnh (nếu có)
//            if(file != null && !file.isEmpty()){
//                // Xác định đường dẫn lưu trữ hình ảnh
//                String imageUrl = Constants.IMG_CATEGORY_SAVE + account.getId() + "/" + Common.currentDate() +categories.getName() +"/";
//                // Lưu tệp hình ảnh và lấy đường dẫn
//                String img = Common.saveFile(file, imageUrl, categories.getId(), categories.getName());
//                // Nếu tệp hình ảnh được lưu thành công, cập nhật đường dẫn hình ảnh vào đối tượng danh mục
//                if(img != null){
//                    categories.setImageCategory(img);
//                }
//            } else {
//                // Nếu không có tệp hình ảnh mới, giữ nguyên đường dẫn hình ảnh hiện tại
//                categories.setImageCategory(categories.getImageCategory());
//            }
//
//
//            // Cập nhật thông tin danh mục
//            categories.setSlug(categoriesADto.getSlug());
//            categories.setName(categoriesADto.getName());
//            categoryRepository.save(categories);
//
//            // Trả về phản hồi thành công
//            res.setStatus(Constants.SUCCESS);
//            res.setMessage(Constants.UPDATE_SUCCESS);
//            res.setResult(categories);
//            return res;
//        } catch (Exception ex) {
//            // Xử lý ngoại lệ và trả về phản hồi lỗi
//            res.setStatus(Constants.ERROR);
//            res.setMessage(Constants.SYSTEM_ERROR);
//            return res;
//        }
//    }
@Override
public DataResponse updateCategory(MultipartFile file, String str, Long id) {
    log.debug("Request Update Categories");
    DataResponse res = new DataResponse();
    Account account = Common.getCurrentUserLogin();
    try {
        CategoriesADto categoriesADto = Common.convertStringToObject(str, CategoriesADto.class);
        Categories categories = categoryRepository.getCategoryByID(id);
        if(categoriesADto.getName().length() < 5 || categoriesADto.getSlug().length()<5){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.ERROR_ADD_NEW_CATEGORIES);
            return res;
        }
        //    if(file != null && !file.isEmpty()){
        //        String imageUrl = Constants.IMG_CATEGORY_SAVE + account.getId() + "/" + Common.currentDate()+ "/";
        //        String img = Common.saveFile(file, imageUrl, categories.getId(), categories.getName());
        //        if(img != null){
        //            categories.setImageCategory(img);
        //        }
        //    }else{
        //        categories.setImageCategory(categories.getImageCategory());
        //    }
        String imageUrl = Constants.IMG_CATEGORY_SAVE + account.getId() + "/" + Common.currentDate()+ "/";
        String img = Common.saveFile(file, imageUrl, account.getId(), categories.getName());
        if (img != null){
            categories.setImageCategory(img);
        }
        categories.setSlug(categoriesADto.getSlug());
        categories.setName(categoriesADto.getName());
        categoryRepository.save(categories);

        res.setStatus(Constants.SUCCESS);
        res.setMessage(Constants.UPDATE_SUCCESS);
        res.setResult(categories);
        return res;
    }catch (Exception ex ){
        res.setStatus(Constants.ERROR);
        res.setMessage(Constants.SYSTEM_ERROR);
        return res;
    }
}


}
