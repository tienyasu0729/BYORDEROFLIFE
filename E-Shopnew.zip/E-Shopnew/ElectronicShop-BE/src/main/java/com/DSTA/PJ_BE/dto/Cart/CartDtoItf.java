package com.DSTA.PJ_BE.dto.Cart;

import java.math.BigDecimal;

public interface CartDtoItf {
    Long getId();
    String getNameProduct();
    Long getProductId();
    BigDecimal getPriceProduct();
    Integer getQuantityProduct();
    String getImage();
    BigDecimal getTotal();
    String getColor();
    BigDecimal getDiscountedPrice();
    Integer getStock();

}