package com.DSTA.PJ_BE.dto.Promotion;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class PromotionDTO {
    private String description;
    private Timestamp startDate;
    private Timestamp endDate;
    private BigDecimal discount;

    // Getters and Setters

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }
}
