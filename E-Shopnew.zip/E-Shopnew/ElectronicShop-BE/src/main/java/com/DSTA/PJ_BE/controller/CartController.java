package com.DSTA.PJ_BE.controller;

import com.DSTA.PJ_BE.dto.Cart.CartDTO;
import com.DSTA.PJ_BE.service.CartService;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/carts")
public class CartController {
    private final Logger log = LoggerFactory.getLogger(CartController.class);

    @Autowired
    private CartService cartService;

    @PostMapping("/create-cart")
    public DataResponse createCart(@RequestBody CartDTO cartDTO) {
        log.debug("Controller Request Create Cart");
        DataResponse res = cartService.createCart(cartDTO);
        return res;
    }

    @GetMapping("/get-all-carts")
    public DataResponse getAllCarts() {
        log.debug("Controller Request Get All Carts");
        DataResponse res = cartService.getAllCarts();
        return res;
    }

    @PutMapping("/update-cart/{id}")
    public DataResponse updateCart(@PathVariable("id") Long id, @RequestBody CartDTO cartDTO) {
        log.debug("Controller Request Update Cart");
        DataResponse res = cartService.updateCart(id, cartDTO);
        return res;
    }

    @DeleteMapping("/delete-cart/{id}")
    public DataResponse deleteCart(@PathVariable() Long id) {
        log.debug("Controller Request Delete Cart");
        DataResponse res = cartService.deleteCart(id);
        return res;
    }

    @DeleteMapping("/delete-all-cart")
    public DataResponse deleteAllCart() {
        log.debug("Controller Request Delete Cart");
        DataResponse res = cartService.deleteAllCart();
        return res;
    }
}