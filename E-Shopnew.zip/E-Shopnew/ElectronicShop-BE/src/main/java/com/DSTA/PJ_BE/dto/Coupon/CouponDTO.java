package com.DSTA.PJ_BE.dto.Coupon;

import com.DSTA.PJ_BE.utils.Common;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;

public class CouponDTO {
    private String code;
    private String description;
    private BigDecimal discount;
    private Date startDate;
    private Date endDate;
    private int usageLimit;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public int getUsageLimit() {
        return usageLimit;
    }

    public void setUsageLimit(int usageLimit) {
        this.usageLimit = usageLimit;
    }
}
