package com.DSTA.PJ_BE.repository;

import com.DSTA.PJ_BE.dto.OrderDetails.OrderDetailDtoItf;
import com.DSTA.PJ_BE.entity.OrderDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;

public interface OrderDetailsRepository extends JpaRepository<OrderDetails, Long> {
    @Query("SELECT od FROM OrderDetails od WHERE od.orderId.id = :orderId")
    List<OrderDetails> findAllByOrderId(@Param("orderId") Long orderId);

    //
    @Query(value = "SELECT p.name_product as nameProduct, o.quantity as quantityProduct, o.price as priceProduct, p.image as image, o.id as id, o.color as color " +
            "FROM order_details o " +
            "JOIN Product p ON o.product_id = p.id " +
            "WHERE o.order_id = :id", nativeQuery = true)
    List<OrderDetailDtoItf> getAllOrderDetailItems(@Param("id") Long id);

    @Query(
            value = "SELECT SUM(od.price * od.quantity) AS total_revenue " +
                    "FROM order_details od " +
                    "JOIN orders o ON od.order_id = o.id " +
                    "WHERE o.status = 'Delivered'",
            nativeQuery = true
    )
    BigDecimal getTotalRevenue();
}
