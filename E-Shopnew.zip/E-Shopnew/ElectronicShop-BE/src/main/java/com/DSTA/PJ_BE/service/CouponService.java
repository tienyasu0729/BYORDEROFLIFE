package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.entity.Coupon;
import com.DSTA.PJ_BE.utils.DataResponse;

public interface CouponService {
    DataResponse createCoupon(Coupon coupon);

    DataResponse getAllCoupons();

    DataResponse updateCoupon(Long id, Coupon coupon);

    DataResponse deleteCoupon(Long id);
}
