package com.DSTA.PJ_BE.dto.Review;

import java.io.IOException;
import java.sql.Timestamp;

import com.DSTA.PJ_BE.utils.Common;

public class ReviewViewDto {
    private Long id;
    private String nameUser;
    private String avatar;
    private String comment;
    private Integer rating;
    private Long productId;
    private String productName;
    private String productImage;
    private  Timestamp createdAt;

    // Getter and Setter for id
    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    // Getter và Setter cho productName
    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    // Getter và Setter cho productImage
    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        try {
            this.productImage = Common.convertToBase64(productImage);
        } catch (IOException e) {
            this.productImage = productImage;
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // Getter and Setter for nameUser
    public String getNameUser() {
        return nameUser;
    }

    public void setNameUser(String nameUser) {
        this.nameUser = nameUser;
    }

    // Getter and Setter for avatar
    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        try {
            this.avatar = Common.convertToBase64(avatar);
        } catch (IOException e) {
            this.avatar = avatar;
        }
    }

    // Getter and Setter for comment
    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    // Getter and Setter for rating
    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
}