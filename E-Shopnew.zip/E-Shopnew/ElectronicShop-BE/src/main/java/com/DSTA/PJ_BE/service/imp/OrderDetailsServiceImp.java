package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.dto.OrderDetails.OrderDetailView;
import com.DSTA.PJ_BE.dto.OrderDetails.OrderDetailsDTO;
import com.DSTA.PJ_BE.dto.OrderDetails.TotalRevenueDto;
import com.DSTA.PJ_BE.entity.OrderDetails;
import com.DSTA.PJ_BE.entity.Account;
import com.DSTA.PJ_BE.entity.Order;
import com.DSTA.PJ_BE.entity.Product;
import com.DSTA.PJ_BE.repository.OrderDetailsRepository;
import com.DSTA.PJ_BE.repository.OrderRepository;
import com.DSTA.PJ_BE.repository.ProductRepository;
import com.DSTA.PJ_BE.service.OrderDetailsService;
import com.DSTA.PJ_BE.utils.Common;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import com.DSTA.PJ_BE.dto.OrderDetails.OrderDetailDtoItf;

import java.math.BigDecimal;
import java.util.List;

@Service
public class OrderDetailsServiceImp implements OrderDetailsService {
    private final Logger log = LoggerFactory.getLogger(OrderDetailsServiceImp.class);

    @Autowired
    private OrderDetailsRepository orderDetailsRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ModelMapper mapper;
//
@Override
public DataResponse getOrderDetailsByOrderId(Long orderId) {
    log.debug("Request Get Order Details By OrderId");
    DataResponse res = new DataResponse();
    try {
        List<OrderDetailDtoItf> listOrderDetails = orderDetailsRepository.getAllOrderDetailItems(orderId);
        if (listOrderDetails == null || listOrderDetails.isEmpty()) {
            res.setStatus(Constants.NOT_FOUND);
            res.setMessage(Constants.LIST_NOT_FOUND);
            return res;
        }

        List<OrderDetailView> result = Common.mapList(listOrderDetails, OrderDetailView.class);
        res.setStatus(Constants.SUCCESS);
        res.setResult(result);
        return res;
    } catch (IllegalArgumentException ex) {
        log.error("Invalid argument passed: {}", ex.getMessage(), ex);
        res.setStatus(Constants.ERROR);
        res.setMessage("Invalid order ID provided: " + ex.getMessage());
        return res;
    } catch (DataAccessException ex) {
        log.error("Database access error: {}", ex.getMessage(), ex);
        res.setStatus(Constants.ERROR);
        res.setMessage("Database access error occurred: " + ex.getMessage());
        return res;
    } catch (Exception ex) {
        log.error("Unexpected error occurred: {}", ex.getMessage(), ex);
        res.setStatus(Constants.ERROR);
        res.setMessage("System error occurred: " + ex.getMessage());
        return res;
    }
}
    @Override
    public DataResponse getRevenue() {
        DataResponse res = new DataResponse();
        try {
            BigDecimal totalRevenue = orderDetailsRepository.getTotalRevenue();
            TotalRevenueDto revenueDto = new TotalRevenueDto(totalRevenue);

            res.setStatus(Constants.SUCCESS);
            res.setResult(revenueDto);
            return res;
        } catch (Exception ex) {
            log.error("Error in getRevenue: ", ex);
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
}