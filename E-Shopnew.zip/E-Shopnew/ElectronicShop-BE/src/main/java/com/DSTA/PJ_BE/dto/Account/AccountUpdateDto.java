package com.DSTA.PJ_BE.dto.Account;

import com.DSTA.PJ_BE.utils.Common;

import java.io.IOException;

public class AccountUpdateDto {
    private String name;
    private String dob;
    private String tel;
    private String gender;
    private String address;
    private String avatar;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        try {
            this.avatar = Common.convertToBase64(avatar);
        } catch (IOException e) {
            this.avatar = avatar;
        }
    }

}
