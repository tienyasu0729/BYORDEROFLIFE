package com.DSTA.PJ_BE.service;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.DSTA.PJ_BE.dto.Promotion.PromotionDTO;
import com.DSTA.PJ_BE.entity.Promotions;
import com.DSTA.PJ_BE.utils.DataResponse;

public interface PromotionsService {

    
    DataResponse createPromotion(PromotionDTO promotionDTO);

    DataResponse getAllPromotions();

    DataResponse updatePromotion(Long id, PromotionDTO promotionDTO);

    DataResponse deletePromotion(Long id);
    
}
