package com.DSTA.PJ_BE.dto.WishList;

import java.io.IOException;
import java.math.BigDecimal;

import com.DSTA.PJ_BE.utils.Common;

public class WishListViewDto {
    private Long id;
    private Long productId;
    private String nameProduct;
    private BigDecimal price;
    private String image;
//getter setter
    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNameProduct() {
        return nameProduct;
    }

    public void setNameProduct(String nameProduct) {
        this.nameProduct = nameProduct;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }


    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        try {
            this.image = Common.convertToBase64(image);
        } catch (IOException e) {
            this.image = image;
        }
    }

}