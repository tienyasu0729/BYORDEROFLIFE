package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.Security.Authorities;
import com.DSTA.PJ_BE.dto.Account.*;
import com.DSTA.PJ_BE.entity.Account;
import com.DSTA.PJ_BE.repository.AccountRepository;
import com.DSTA.PJ_BE.service.AccountService;
import com.DSTA.PJ_BE.utils.Common;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import com.DSTA.PJ_BE.utils.Validate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.util.Value;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.modelmapper.ModelMapper;
import org.springframework.web.multipart.MultipartFile;
import java.time.temporal.ChronoUnit;
import javax.transaction.Transactional;
import java.time.Instant;
import java.util.*;

@Service
@Transactional
public class AccountServiceImp implements AccountService {
    private final Logger log = LoggerFactory.getLogger(AccountServiceImp.class);
    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private ModelMapper mapper;
    @Autowired
    private JavaMailSender mailSender;
    @Value("${PJ.mail.from}")
    private String fromEmail;

    @Value("${PJ.clientApp.name}")
    private String clientAppName;

    @Override
    public Account getAccountByUsername(String email) {
        log.debug("Get account by user name" + email);
        return accountRepository.getAccountUserName(email);
    }

    @Override
    public Account getAccountById(Long id) {
        log.debug("Get account by id" + id);
        return accountRepository.getAccountId(id);
    }

    @Override
    public Account getAccountLogin() {
        return Common.getCurrentUserLogin();
    }

    @Override
    public DataResponse register(AccountRegisterDto accountRegisterDto) {
        log.debug("Request Register Imp");
        DataResponse res = new DataResponse();
        try {
            Account account = mapper.map(accountRegisterDto, Account.class);

            if(!Validate.validateEmail(account.getEmail())){
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.REGISTER_FAIL);
                return res;
            }
            account.setAuthority(getRoleJson(Authorities.CUSTOMER));
            String password = account.getPassword();
            account.setPassword(passwordEncoder.encode(password));
            account.setActive(true);
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.REGISTER_SUCCESS);
            res.setResult(account);
            accountRepository.save(account);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
    private String getRoleJson(String role) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(Collections.singletonList("" + role));
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting roles to JSON", e);
        }
    }
    @Override
    @Transactional
    public DataResponse updateAccount(String str, MultipartFile file) {
        log.debug("Request Update Account");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            AccountUpdateDto accountUpdateDto = Common.convertStringToObject(str, AccountUpdateDto.class);
            String date = Common.convertStringDate(accountUpdateDto.getDob(), Constants.YYYY_MM_DD, Constants.YYYYMMDD);
            if(account == null || account.equals("")){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.ACCOUNT_NOT_FOUND);
                return res;
            }
            if(!Validate.validateTel(accountUpdateDto.getTel())){
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.UPDATE_FAIL);
                return res;
            }
            if(file != null && !file.isEmpty()){
                String avatarUrl = Constants.AVATAR_SAVE + account.getId() + "/" + Common.currentDate() + "/";
                String image = Common.saveFile(file, avatarUrl, account.getId(), account.getName());
                if(image != null){
                    account.setAvatar(image);
                }
            }else {
                account.setAvatar(account.getAvatar());
            }
            account.setName(accountUpdateDto.getName());
            account.setDob(date);
            account.setAddress(accountUpdateDto.getAddress());
            account.setGender(accountUpdateDto.getGender());
            account.setTel(accountUpdateDto.getTel());

            accountRepository.save(account);
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.UPDATE_ACCOUNT_SUCCESS);
            res.setResult(account);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }


    @Override
    public DataResponse deleteUser(Long id) {
        log.debug("Request Delete User");
        DataResponse res = new DataResponse();
        try {
            Account account = accountRepository.getAccountId(id);
            if(account == null){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.ACCOUNT_NOT_FOUND);
                return res;
            }

            String imgPath = Constants.AVATAR_SAVE + account.getId();
            accountRepository.delete(account);
            Common.deleteImageFolder(imgPath);
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.DELETE_SUCCESS);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    @Transactional
    public DataResponse getAllUser(Pageable pageable) {
        log.debug("Request Get All User___BUG: ");
        DataResponse res = new DataResponse();
        try {
            Page<Account> user = accountRepository.getUser(pageable);

            if(!user.hasContent()){
                res.setResult(Constants.NOT_FOUND);
                res.setMessage(Constants.ACCOUNT_NOT_FOUND);
                return res;
            }

            res.setStatus(Constants.SUCCESS);
            res.setResult(user);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse changePass(AccountChangePassDto accountChangePassDto) {
        log.debug("Request Change Pass___BUG: ");
        DataResponse res = new DataResponse();
        try {
            Account account = this.getAccountLogin();
            if(accountChangePassDto.getNewPass().length()<3){
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.NEW_PASSWORD_ERROR);
                return res;
            }
            if(!passwordEncoder.matches(accountChangePassDto.getOldPass(), account.getPassword())){
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.OLD_PASSWORD_ERROR);
                return res;
            }
            account.setPassword(passwordEncoder.encode(accountChangePassDto.getNewPass()));
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.CHANGE_PASSWORD_SUCCESS);
            accountRepository.save(account);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse updateAdmin(Long id, boolean status) {
        log.debug("Request update status");
        DataResponse res = new DataResponse();
        try {
            Account account = accountRepository.getAccountId(id);
            if(account == null){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.ACCOUNT_NOT_FOUND);
                return res;
            }
            account.setActive(status);
            accountRepository.save(account);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.UPDATE_SUCCESS);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getAllInfo() {
        log.debug("Request Get All Infomation");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            List<AccountDtoItf> acc = accountRepository.getAllInfoAcc(account.getId());

            List<AccountViewDto> result = Common.mapList(acc, AccountViewDto.class);
            res.setStatus(Constants.SUCCESS);
            res.setResult(result);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
    @Override
    @Transactional
    public Account socialLogin(AccountSocialLoginDto socialLoginDto) {
        log.debug("Social login attempt for email: {}", socialLoginDto.getEmail());
        try {
            Optional<Account> existingAccount = Optional
                    .ofNullable(accountRepository.getAccountUserName(socialLoginDto.getEmail()));

            if (existingAccount.isPresent()) {
                log.debug("Existing account found for email: {}", socialLoginDto.getEmail());
                Account account = existingAccount.get();
                // Update existing account with any new information
                account.setName(socialLoginDto.getName());
                account.setAvatar(socialLoginDto.getImageUrl());

                log.debug("Updating existing account: {}", account);
                return accountRepository.save(account);
            } else {
                log.debug("Creating new account for email: {}", socialLoginDto.getEmail());
                // Create new account
                Account newAccount = new Account();
                newAccount.setEmail(socialLoginDto.getEmail());
                newAccount.setName(socialLoginDto.getName());
                newAccount.setPassword("123456");
                newAccount.setAuthority(getRoleJson(Authorities.CUSTOMER));
                log.debug("Saving new account: {}", newAccount);
                return accountRepository.save(newAccount);
            }
        } catch (Exception e) {
            log.error("Unexpected error during social login for email: {}", socialLoginDto.getEmail(), e);
            throw new RuntimeException("Unexpected error during social login", e);
        }
    }

    @Override
    public DataResponse resetPassword(String token, String newPassword) {
        DataResponse res = new DataResponse();
        try {
            Account account = accountRepository.getAccountByResetToken(token);
            if (account == null) {
                log.debug("No account found for reset token: {}", token);
                res.setStatus(Constants.ERROR);
                res.setMessage("Invalid or expired reset token");
                return res;
            }

            if (account.getResetTokenExpiration().before(new Date())) {
                log.debug("Reset token expired for account: {}", account.getEmail());
                res.setStatus(Constants.ERROR);
                res.setMessage("Reset token expired");
                return res;
            }

            account.setPassword(passwordEncoder.encode(newPassword));
            account.setResetToken(null);
            account.setResetTokenExpiration(null);
            accountRepository.save(account);
            log.debug("Password reset successful for account: {}", account.getEmail());
            res.setStatus(Constants.SUCCESS);
            res.setMessage("Password reset successful");
            return res;
        } catch (Exception e) {
            log.error("Unexpected error during password reset for token: {}", token, e);
            res.setStatus(Constants.ERROR);
            res.setMessage("An error occurred while resetting password.");
            return res;
        }
    }

    private String generatePasswordResetToken() {
        return UUID.randomUUID().toString();
    }

    @Override
    public DataResponse forgotPassword(String email) {
        DataResponse res = new DataResponse();
        try {
            Account account = accountRepository.getAccountUserName(email);
            if (account == null) {
                log.debug("No account found for email: {}", email);
                res.setStatus(Constants.ERROR);
                res.setMessage("No account found for email: " + email);
                return res;
            }

            String resetToken = generatePasswordResetToken();
            account.setResetToken(resetToken);
            account.setResetTokenExpiration(Date.from(Instant.now().plus(30, ChronoUnit.MINUTES)));
            accountRepository.save(account);
            String resetUrl = "http://localhost:3000/reset-password?token=" + resetToken;
            String emailContent = String.format(
                    "Dear %s,\n\n" +
                            "You have requested to reset your password for your %s account. " +
                            "Please click on the link below to reset your password:\n\n" +
                            "%s\n\n" +
                            "This link will expire in 30 minutes.\n\n" +
                            "If you did not request a password reset, please ignore this email.\n\n",
                    account.getName(), clientAppName, resetUrl, clientAppName
            );

            SimpleMailMessage mailMessage = new SimpleMailMessage();
            mailMessage.setFrom(fromEmail);
            mailMessage.setTo(account.getEmail());
            mailMessage.setSubject(clientAppName + " - Password Reset Request");
            mailMessage.setText(emailContent);
            mailSender.send(mailMessage);

            log.debug("Password reset email sent to: {}", email);
            res.setStatus(Constants.SUCCESS);
            res.setMessage("Password reset email sent to: " + email);
            return res;
        } catch (Exception e) {
            log.error("Unexpected error during password reset for email: {}", email, e);
            res.setStatus(Constants.ERROR);
            res.setMessage("An error occurred while sending password reset email.");
            return res;
        }

    }
}
