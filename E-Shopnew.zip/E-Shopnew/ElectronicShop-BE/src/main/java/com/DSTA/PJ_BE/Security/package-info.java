/**
 * Security
 */
/**
 * @author ACER
 *
 */
package DSTA.Cos.Cosmetics.security;