package com.DSTA.PJ_BE.dto.Order;

public interface OderViewStatusInfDto {
    Long getId();
    String getProductName();
    String getTotal();
    Integer getQuantity();
    String getImage();
    String getStatus();
    String getTime();
}
