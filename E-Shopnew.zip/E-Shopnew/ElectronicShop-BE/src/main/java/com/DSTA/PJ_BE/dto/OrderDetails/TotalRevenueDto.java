package com.DSTA.PJ_BE.dto.OrderDetails;

import java.math.BigDecimal;
import com.DSTA.PJ_BE.utils.Common;

public class TotalRevenueDto {
    private BigDecimal totalRevenue;

    public TotalRevenueDto(BigDecimal totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public BigDecimal getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(BigDecimal totalRevenue) {
        this.totalRevenue = totalRevenue;
    }
}