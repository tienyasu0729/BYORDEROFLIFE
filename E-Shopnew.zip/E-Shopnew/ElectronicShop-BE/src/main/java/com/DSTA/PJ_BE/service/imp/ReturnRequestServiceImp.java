package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.dto.ReturnRequest.ReturnRequestDTO;
import com.DSTA.PJ_BE.entity.Order;
import com.DSTA.PJ_BE.entity.ReturnRequest;
import com.DSTA.PJ_BE.repository.OrderRepository;
import com.DSTA.PJ_BE.repository.ReturnRequestRepository;
import com.DSTA.PJ_BE.service.ReturnRequestService;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReturnRequestServiceImp implements ReturnRequestService {
    private final Logger log = LoggerFactory.getLogger(ReturnRequestServiceImp.class);

    @Autowired
    private ReturnRequestRepository returnRequestRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ModelMapper mapper;

    @Override
    public DataResponse createReturnRequest(ReturnRequestDTO returnRequestDTO) {
        log.debug("Request Create Return Request");
        DataResponse res = new DataResponse();
        try {
            ReturnRequest returnRequest = new ReturnRequest();
            returnRequest.setRequestDate(returnRequestDTO.getRequestDate());
            returnRequest.setStatus(returnRequestDTO.getStatus());
            returnRequest.setReason(returnRequestDTO.getReason());

            Order order = orderRepository.findById(returnRequestDTO.getOrderId()).orElse(null);

            if (order == null) {
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.NOT_FOUND);
                return res;
            }

            returnRequest.setOrder(order);
            returnRequestRepository.save(returnRequest);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.ADD_SUCCESS);
            res.setResult(returnRequest);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getAllReturnRequests() {
        log.debug("Request Get All Return Requests");
        DataResponse res = new DataResponse();
        try {
            List<ReturnRequest> listReturnRequests = returnRequestRepository.findAll();
            if (listReturnRequests == null || listReturnRequests.isEmpty()) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }

            res.setStatus(Constants.SUCCESS);
            res.setResult(listReturnRequests);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getReturnRequestById(Long id) {
        log.debug("Request Get Return Request By Id");
        DataResponse res = new DataResponse();
        try {
            ReturnRequest returnRequest = returnRequestRepository.findById(id).orElse(null);
            if (returnRequest == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }

            res.setStatus(Constants.SUCCESS);
            res.setResult(returnRequest);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse updateReturnRequest(Long id, ReturnRequestDTO returnRequestDTO) {
        log.debug("Request Update Return Request");
        DataResponse res = new DataResponse();
        try {
            ReturnRequest returnRequestUpdate = returnRequestRepository.findById(id).orElse(null);
            if (returnRequestUpdate == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }

            returnRequestUpdate.setRequestDate(returnRequestDTO.getRequestDate());
            returnRequestUpdate.setStatus(returnRequestDTO.getStatus());
            returnRequestUpdate.setReason(returnRequestDTO.getReason());

            Order order = orderRepository.findById(returnRequestDTO.getOrderId()).orElse(null);

            if (order == null) {
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.NOT_FOUND);
                return res;
            }

            returnRequestUpdate.setOrder(order);

            returnRequestRepository.save(returnRequestUpdate);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.UPDATE_SUCCESS);
            res.setResult(returnRequestUpdate);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse deleteReturnRequest(Long id) {
        log.debug("Request Delete Return Request");
        DataResponse res = new DataResponse();
        try {
            ReturnRequest returnRequest = returnRequestRepository.findById(id).orElse(null);
            if (returnRequest == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            returnRequestRepository.delete(returnRequest);
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.DELETE_SUCCESS);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
}
