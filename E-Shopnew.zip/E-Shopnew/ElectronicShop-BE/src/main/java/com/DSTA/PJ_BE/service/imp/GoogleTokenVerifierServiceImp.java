package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.utils.DataResponse;
import com.DSTA.PJ_BE.service.GoogleTokenVerifierService;
import com.DSTA.PJ_BE.utils.Constants;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;

@Service
public class GoogleTokenVerifierServiceImp implements GoogleTokenVerifierService {

    private static final Logger logger = LoggerFactory.getLogger(GoogleTokenVerifierServiceImp.class);

    private static final String CLIENT_ID = "333632614563-afkr3g3h5h43bb0hrf6ou5ojs9rabes0.apps.googleusercontent.com";

    @Override
    public DataResponse verifyGoogleIdToken(String idTokenString) {
        DataResponse response = new DataResponse();
        if (idTokenString == null || idTokenString.isEmpty()) {
            logger.error("Received null or empty ID token");
            response.setStatus(Constants.ERROR);
            response.setMessage("ID token is null or empty");
            return response;
        }

        try {
            logger.debug("Attempting to verify Google ID token");

            GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(new NetHttpTransport(), new JacksonFactory())
                    .setAudience(Collections.singletonList(CLIENT_ID))
                    .build();

            GoogleIdToken idToken = verifier.verify(idTokenString);
            if (idToken != null) {
                GoogleIdToken.Payload payload = idToken.getPayload();
                logger.info("Google ID token verified successfully for user: {}", payload.getEmail());
                response.setStatus(Constants.SUCCESS);
                response.setMessage("Google ID token verified successfully");
                response.setResult(payload);
            } else {
                logger.error("Invalid ID token");
                response.setStatus(Constants.ERROR);
                response.setMessage("Invalid ID token");
            }
        } catch (Exception e) {
            logger.error("Error verifying Google ID token", e);
            response.setStatus(Constants.ERROR);
            response.setMessage("Error verifying Google ID token: " + e.getMessage());
        }
        return response;
    }
}