package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.utils.DataResponse;

public interface GoogleTokenVerifierService {
    DataResponse verifyGoogleIdToken(String idTokenString);
}