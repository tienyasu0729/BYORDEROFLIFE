// package com.DSTA.PJ_BE.service;

// import com.DSTA.PJ_BE.utils.DataResponse;

// public interface ColorService {

//     DataResponse getAllColors();
    
// }
package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.dto.ColorDTO.ColorDto;
import com.DSTA.PJ_BE.utils.DataResponse;

public interface ColorService {

    DataResponse addNewColor(ColorDto colorDto);

    DataResponse getAllColors();

    DataResponse deleteColor(Long id);

    DataResponse updateColor(ColorDto colorDto, Long id);
}
