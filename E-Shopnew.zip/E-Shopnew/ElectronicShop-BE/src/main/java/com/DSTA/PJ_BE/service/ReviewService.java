package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.dto.Review.ReviewDTO;
import com.DSTA.PJ_BE.entity.Product;
import com.DSTA.PJ_BE.utils.DataResponse;

public interface ReviewService {

    DataResponse createReview(ReviewDTO reviewDTO);
    DataResponse getAllReviewsByProduct(Long id);
    DataResponse getAllReviewsByUser();
    DataResponse updateReview(Long id, ReviewDTO reviewDTO);
    DataResponse deleteReview(Long id);
    DataResponse getAll();
}