 package com.DSTA.PJ_BE.service.imp;

 import com.DSTA.PJ_BE.dto.ColorDTO.ColorDto;
 import com.DSTA.PJ_BE.entity.Color;
 import com.DSTA.PJ_BE.repository.ColorRepository;
 import com.DSTA.PJ_BE.service.ColorService;
 import com.DSTA.PJ_BE.utils.Common;
 import com.DSTA.PJ_BE.utils.Constants;
 import com.DSTA.PJ_BE.utils.DataResponse;
 import org.modelmapper.ModelMapper;
 import org.slf4j.Logger;
 import org.slf4j.LoggerFactory;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.stereotype.Service;

 import javax.transaction.Transactional;
 import java.util.List;

 @Service
 public class ColorServiceImp implements ColorService {
     private final Logger log = LoggerFactory.getLogger(ColorServiceImp.class);

     @Autowired
     private ColorRepository colorRepository;

     @Autowired
     private ModelMapper mapper;

     @Override
     @Transactional
     public DataResponse addNewColor(ColorDto colorDto) {
         log.debug("Request Add New Color");
         DataResponse res = new DataResponse();
         Color color = new Color();
         try {
             color = mapper.map(colorDto, Color.class);

             if (colorDto.getName().length() < 3) {
                 res.setStatus(Constants.ERROR);
                 res.setMessage(Constants.ERROR_ADD_NEW_COLOR);
                 return res;
             }
             color.setName(colorDto.getName());
             colorRepository.save(color);
             res.setStatus(Constants.SUCCESS);
             res.setMessage(Constants.ADD_COLOR_SUCCESS);
             res.setResult(color);
             return res;
         } catch (Exception ex) {
             res.setStatus(Constants.ERROR);
             res.setMessage(Constants.SYSTEM_ERROR);
             return res;
         }
     }

     @Override
     public DataResponse getAllColors() {
         log.debug("Request Get All Colors");
         DataResponse res = new DataResponse();
         try {
             List<Color> listColors = colorRepository.getAll();
             if (listColors == null || listColors.isEmpty()) {
                 res.setStatus(Constants.NOT_FOUND);
                 res.setMessage(Constants.COLORS_NOT_FOUND);
                 return res;
             }
             res.setStatus(Constants.SUCCESS);
             res.setResult(listColors);
             return res;
         } catch (Exception ex) {
             res.setStatus(Constants.ERROR);
             res.setMessage(Constants.SYSTEM_ERROR);
             return res;
         }
     }

     @Override
     public DataResponse deleteColor(Long id) {
         log.debug("Request Delete Color");
         DataResponse res = new DataResponse();
         try {
             Color color = colorRepository.getColorByID(id);
             if (color == null) {
                 res.setStatus(Constants.NOT_FOUND);
                 res.setMessage(Constants.COLORS_NOT_FOUND);
                 return res;
             }
             colorRepository.delete(color);

             res.setStatus(Constants.SUCCESS);
             res.setMessage(Constants.DELETE_SUCCESS);
             return res;
         } catch (Exception ex) {
             res.setStatus(Constants.ERROR);
             res.setMessage(Constants.SYSTEM_ERROR);
             return res;
         }
     }

     @Override
     public DataResponse updateColor(ColorDto colorDto, Long id) {
         log.debug("Request Update Color");
         DataResponse res = new DataResponse();
         try {
             Color color = colorRepository.getColorByID(id);
             if (colorDto.getName().length() < 3) {
                 res.setStatus(Constants.ERROR);
                 res.setMessage(Constants.ERROR_UPDATE_COLOR);
                 return res;
             }
             color.setName(colorDto.getName());
             colorRepository.save(color);

             res.setStatus(Constants.SUCCESS);
             res.setMessage(Constants.UPDATE_SUCCESS);
             res.setResult(color);
             return res;
         } catch (Exception ex) {
             res.setStatus(Constants.ERROR);
             res.setMessage(Constants.SYSTEM_ERROR);
             return res;
         }
     }
 }
