package com.DSTA.PJ_BE.repository;

import com.DSTA.PJ_BE.entity.Color;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ColorRepository extends JpaRepository<Color, Long> {

    @Query(value = "SELECT co FROM Color co WHERE co.id = :id")
    Color getColorByID(@Param("id") Long id);
    //thêm
    @Query(value = "SELECT c FROM Color c")
    List<Color> getAll();
}
