package com.DSTA.PJ_BE.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "color")
public class Color {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", columnDefinition = "VARCHAR(50)", nullable = false)
    private String name;

    // @OneToMany(mappedBy = "color")
    // private List<ProductColor> productColors;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // public List<ProductColor> getProductColors() {
    //     return productColors;
    // }

    // public void setProductColors(List<ProductColor> productColors) {
    //     this.productColors = productColors;
    // }
}
