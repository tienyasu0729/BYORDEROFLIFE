package com.DSTA.PJ_BE.repository;

import com.DSTA.PJ_BE.dto.Cart.CartDtoItf;
import com.DSTA.PJ_BE.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {

    @Query(value = "SELECT c FROM Cart c WHERE c.user.id = :userId AND c.product.id = :productId")
    List<Cart> findByUserIdAndProductId(@Param("userId") Long userId, @Param("productId") Long productId);

    @Query(value = "SELECT p.name_product as nameProduct,p.stock as stock, c.quantity as quantityProduct, c.product_id as productId, p.price as total, p.image as image, c.id as id, c.color_name as color, c.discounted_price as discountedPrice " +
            "FROM Cart c " +
            "JOIN Product p ON c.product_id = p.id " +
            "WHERE c.user_id = :id", nativeQuery = true)
    List<CartDtoItf> getAllCartItems(@Param("id") Long id);

    @Query(value = "SELECT c FROM Cart c WHERE c.id = :id")
    Cart getCartItemByID(@Param("id") Long id);

    @Query(value = "SELECT c FROM Cart c WHERE c.user.id = :id")
    List<Cart> getCartItemsByUserID(@Param("id") Long id);

    @Modifying
    @Query(value = "DELETE FROM Cart c WHERE c.id = :id")
    void removeFromCart(@Param("id") Long id);

    @Query(value = "SELECT c FROM Cart c WHERE c.product.id = :id")
    List<Cart> getCartItemsByProductID(@Param("id") Long id);
    @Query("SELECT c FROM Cart c WHERE c.user.id = :userId")
    List<Cart> findAllByUserId(@Param("userId") Long userId);
}