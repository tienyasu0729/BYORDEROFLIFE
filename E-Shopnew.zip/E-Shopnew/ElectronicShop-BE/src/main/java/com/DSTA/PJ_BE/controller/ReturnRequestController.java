package com.DSTA.PJ_BE.controller;

import com.DSTA.PJ_BE.dto.ReturnRequest.ReturnRequestDTO;
import com.DSTA.PJ_BE.service.ReturnRequestService;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/return-requests")
public class ReturnRequestController {
    private final Logger log = LoggerFactory.getLogger(ReturnRequestController.class);

    @Autowired
    private ReturnRequestService returnRequestService;

    @PostMapping("/create-return-request")
    
    public DataResponse createReturnRequest(@RequestBody ReturnRequestDTO returnRequestDTO) {
        log.debug("Controller Request Create Return Request");
        DataResponse res = returnRequestService.createReturnRequest(returnRequestDTO);
        return res;
    }

    @GetMapping("/get-all-return-requests")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse getAllReturnRequests() {
        log.debug("Controller Request Get All Return Requests");
        DataResponse res = returnRequestService.getAllReturnRequests();
        return res;
    }

    @GetMapping("/get-return-request/{id}")
    
    public DataResponse getReturnRequestById(@PathVariable("id") Long id) {
        log.debug("Controller Request Get Return Request By Id");
        DataResponse res = returnRequestService.getReturnRequestById(id);
        return res;
    }

    @PutMapping("/update-return-request/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse updateReturnRequest(@PathVariable("id") Long id, @RequestBody ReturnRequestDTO returnRequestDTO) {
        log.debug("Controller Request Update Return Request");
        DataResponse res = returnRequestService.updateReturnRequest(id, returnRequestDTO);
        return res;
    }

    @DeleteMapping("/delete-return-request/{id}")
    
    public DataResponse deleteReturnRequest(@PathVariable("id") Long id) {
        log.debug("Controller Request Delete Return Request");
        DataResponse res = returnRequestService.deleteReturnRequest(id);
        return res;
    }
}
