package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.dto.Brand.BrandDTO;
import com.DSTA.PJ_BE.utils.DataResponse;

public interface BrandService {
    DataResponse createBrand(BrandDTO brandDTO);

    DataResponse getAllBrands();

    DataResponse updateBrand(Long id, BrandDTO brandDTO);

    DataResponse deleteBrand(Long id);
}
