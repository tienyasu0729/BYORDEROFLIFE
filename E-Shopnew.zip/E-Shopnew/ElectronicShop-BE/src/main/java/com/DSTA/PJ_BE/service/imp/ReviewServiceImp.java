package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.dto.Review.ReviewDtoitf;
import com.DSTA.PJ_BE.dto.Review.ReviewViewDto;
import com.DSTA.PJ_BE.dto.Review.ReviewDTO;
import com.DSTA.PJ_BE.entity.Product;
import com.DSTA.PJ_BE.entity.Account;
import com.DSTA.PJ_BE.entity.Review;
import com.DSTA.PJ_BE.repository.ReviewRepository;
import com.DSTA.PJ_BE.repository.ProductRepository;
import com.DSTA.PJ_BE.repository.AccountRepository;
import com.DSTA.PJ_BE.service.ReviewService;
import com.DSTA.PJ_BE.utils.Common;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.Timestamp;


import java.util.List;

@Service
public class ReviewServiceImp implements ReviewService {
    private final Logger log = LoggerFactory.getLogger(ReviewServiceImp.class);

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private ProductRepository productRepository;


    @Autowired
    private ModelMapper mapper;

    @Override
    public DataResponse createReview(ReviewDTO reviewDTO) {
        log.debug("Request Create Review");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            Product product = productRepository.getProductByID(reviewDTO.getProductId());
            Review review = mapper.map(reviewDTO, Review.class);

            if (product == null || account == null) {
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.NOT_FOUND);
                return res;
            }

            review.setProduct(product);
            review.setUser(account);
            review.setComment(reviewDTO.getComment());
            review.setRating(reviewDTO.getRating());
            review.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            reviewRepository.save(review);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.ADD_SUCCESS);
            res.setResult(review);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getAllReviewsByUser() {
        log.debug("Request Get All Reviews By User");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            List<ReviewDtoitf> review = reviewRepository.getAllReviewItems(account.getId());

            if(review == null || review.isEmpty()){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            List<ReviewViewDto> result = Common.mapList(review, ReviewViewDto.class);
            res.setStatus(Constants.SUCCESS);
            res.setResult(result);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }



    @Override
    public DataResponse getAllReviewsByProduct(Long id) {
        log.debug("Request Get All Reviews By Product");
        DataResponse res = new DataResponse();
        try {
            List<ReviewDtoitf> review = reviewRepository.getAllReviewItemsByProductId(id);

            if (review == null || review.isEmpty()) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            List<ReviewViewDto> result = Common.mapList(review, ReviewViewDto.class);
            res.setStatus(Constants.SUCCESS);
            res.setResult(result);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse updateReview(Long id, ReviewDTO reviewDTO) {
        log.debug("Request Update Review");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            Review existingReview = reviewRepository.findById(id).orElse(null);

            if (existingReview == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.NOT_FOUND);
                return res;
            }

            if (!existingReview.getUser().getId().equals(account.getId())) {
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.UNAUTHORIZED);
                return res;
            }

            existingReview.setComment(reviewDTO.getComment());
            existingReview.setRating(reviewDTO.getRating());
            existingReview.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            reviewRepository.save(existingReview);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.UPDATE_SUCCESS);
            res.setResult(existingReview);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse deleteReview(Long id) {
        log.debug("Request Delete Review");
        DataResponse res = new DataResponse();
        try {
            Review review = reviewRepository.findById(id).orElse(null);
            if (review == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            reviewRepository.delete(review);
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.DELETE_SUCCESS);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
    @Override
    public DataResponse getAll() {
        log.debug("Request Get All Reviews By Product");
        DataResponse res = new DataResponse();
        try {
            List<ReviewDtoitf> review = reviewRepository.getAll();

            if (review == null || review.isEmpty()) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            List<ReviewViewDto> result = Common.mapList(review, ReviewViewDto.class);
            res.setStatus(Constants.SUCCESS);
            res.setResult(result);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
}