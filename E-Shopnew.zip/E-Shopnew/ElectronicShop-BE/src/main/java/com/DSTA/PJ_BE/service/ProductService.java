package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.utils.DataResponse;

import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

public interface ProductService {

    DataResponse getProductId(Long id);

    DataResponse addNewProduct(MultipartFile file1, MultipartFile file2, MultipartFile file3, String str);

    DataResponse getAllProducts(Pageable pageable);

    DataResponse deleteProduct(Long id);

    DataResponse updateProduct(MultipartFile file1, MultipartFile file2, MultipartFile file3, String str, Long id);
    DataResponse getProductsPopular();
}
