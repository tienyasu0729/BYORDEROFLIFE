package com.DSTA.PJ_BE.entity;

import java.sql.Timestamp;

import javax.persistence.*;

@Entity
@Table(name = "return_request")
public class ReturnRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long returnRequestID;

    @Column(name = "request_date")
    private Timestamp requestDate;

    @Column(name = "status", length = 50)
    private String status;

    @Column(name = "reason", columnDefinition = "TEXT")
    private String reason;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;

    // Getters and Setters

    public Long getReturnRequestID() {
        return returnRequestID;
    }

    public void setReturnRequestID(Long returnRequestID) {
        this.returnRequestID = returnRequestID;
    }

    public Timestamp getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Timestamp requestDate) {
        this.requestDate = requestDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }
}
