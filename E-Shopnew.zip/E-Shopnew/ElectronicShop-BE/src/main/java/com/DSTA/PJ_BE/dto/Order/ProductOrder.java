package com.DSTA.PJ_BE.dto.Order;

import java.math.BigDecimal;

public class ProductOrder {
    private Long productId;
    private Integer quantity;
    private BigDecimal price;
    private String color;

    // Getter and Setter for productId

    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    // Getter and Setter for quantity
    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}