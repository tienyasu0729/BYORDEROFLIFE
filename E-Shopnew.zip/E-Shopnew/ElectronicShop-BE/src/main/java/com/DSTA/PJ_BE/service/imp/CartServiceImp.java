package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.dto.Cart.CartDTO;
import com.DSTA.PJ_BE.dto.Cart.CartDtoItf;
import com.DSTA.PJ_BE.dto.Cart.CartViewDto;
import com.DSTA.PJ_BE.entity.Cart;
import com.DSTA.PJ_BE.entity.Product;
import com.DSTA.PJ_BE.entity.Account;
import com.DSTA.PJ_BE.repository.CartRepository;
import com.DSTA.PJ_BE.repository.ProductRepository;
import com.DSTA.PJ_BE.service.CartService;
import com.DSTA.PJ_BE.utils.Common;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class CartServiceImp implements CartService {
    private final Logger log = LoggerFactory.getLogger(CartServiceImp.class);

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ModelMapper mapper;

    @Override
    public DataResponse createCart(CartDTO cartDTO) {
        log.debug("Request Create Cart");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            Product product = productRepository.getProductByID(cartDTO.getProductId());
            Cart list = mapper.map(cartDTO, Cart.class);



            if (product == null || account == null) {
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.NOT_FOUND);
                return res;
            }


            List<Cart> existingCarts = cartRepository.findByUserIdAndProductId(account.getId(), product.getId());

            if (!existingCarts.isEmpty()){
                boolean isMatchFound = false;
                for (Cart existingCart : existingCarts) {
                    if (existingCart.getColorName().equals(cartDTO.getNameColor())) {
                        existingCart.setQuantity(existingCart.getQuantity() + cartDTO.getQuantity());
                        existingCart.setPrice(product.getDiscountedPrice().multiply(BigDecimal.valueOf(existingCart.getQuantity())));
                        cartRepository.save(existingCart);
                        res.setMessage(Constants.UPDATE_SUCCESS);
                        res.setResult(existingCart);
                        isMatchFound = true;
                        break;
                    }
                }

                if (!isMatchFound) {
                    list.setUser(account);
                    list.setProduct(product);
                    list.setColorName(cartDTO.getNameColor());
                    list.setDiscountedPrice(product.getDiscountedPrice());
                    list.setPrice(product.getDiscountedPrice().multiply(BigDecimal.valueOf(cartDTO.getQuantity())));
                    cartRepository.save(list);
                    res.setMessage(Constants.ADD_SUCCESS);
                }
            }else{
                list.setUser(account);
                list.setProduct(product);
                list.setColorName(cartDTO.getNameColor());
                list.setDiscountedPrice(product.getDiscountedPrice());
                list.setPrice(product.getDiscountedPrice().multiply(BigDecimal.valueOf(cartDTO.getQuantity())));
                cartRepository.save(list);
                res.setMessage(Constants.ADD_SUCCESS);
            }

            res.setStatus(Constants.SUCCESS);
            res.setResult(list);
            return res;
        } catch (Exception ex) {
            log.error("Message Add To Cart___BUG: " + ex.getMessage());
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getAllCarts() {
        log.debug("Request Get All Cart");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            List<CartDtoItf> cart = cartRepository.getAllCartItems(account.getId());

            if(cart == null || cart.isEmpty()){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            List<CartViewDto> result = Common.mapList(cart, CartViewDto.class);
            res.setStatus(Constants.SUCCESS);
            res.setResult(result);
            return res;
        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse updateCart(Long id, CartDTO cartDTO) {
        log.debug("Request Update Cart");
        DataResponse res = new DataResponse();
        try {

            Cart existingCart = cartRepository.findById(id).orElse(null);

            if (existingCart == null) {
                res.setStatus(Constants.ERROR);
                res.setMessage("Cart not found");
                return res;
            }

            // Corrected: Call getQuantity() on the cartDTO instance
            existingCart.setQuantity(cartDTO.getQuantity());

            cartRepository.save(existingCart);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.UPDATE_SUCCESS);
            res.setResult(existingCart);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse deleteCart(Long id) {
        log.debug("Request Delete Cart");
        DataResponse res = new DataResponse();
        try {
            Cart list = cartRepository.getCartItemByID(id);
            if(list == null){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            cartRepository.delete(list);
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.DELETE_SUCCESS);
            return res;

        }catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }


    @Override
    public DataResponse deleteAllCart() {
        log.debug("Request Delete Cart");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            if (account == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.ACCOUNT_NOT_FOUND);
                return res;
            }
            Long userId = account.getId();
            List<Cart> list = cartRepository.findAllByUserId(userId);

            if (list.isEmpty()) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.NOT_FOUND);
                return res;
            }
            for (Cart cart : list) {
                cartRepository.delete(cart);
            }
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.DELETE_SUCCESS);
            return res;

        } catch (Exception ex) {
            log.error("Exception while deleting all cart items", ex);
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
}