package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.dto.Order.OrderDTO;
import com.DSTA.PJ_BE.dto.Order.ProductOrder;
import com.DSTA.PJ_BE.entity.Order;
import com.DSTA.PJ_BE.entity.OrderDetails;
import com.DSTA.PJ_BE.entity.Product;
import com.DSTA.PJ_BE.entity.Promotions;
import com.DSTA.PJ_BE.entity.Account;
import com.DSTA.PJ_BE.entity.Cart;
import com.DSTA.PJ_BE.entity.Coupon;
import com.DSTA.PJ_BE.repository.OrderRepository;
import com.DSTA.PJ_BE.repository.ProductRepository;
import com.DSTA.PJ_BE.repository.AccountRepository;
import com.DSTA.PJ_BE.repository.CouponRepository;
import com.DSTA.PJ_BE.repository.OrderDetailsRepository;
import com.DSTA.PJ_BE.service.OrderService;
import com.DSTA.PJ_BE.utils.Common;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import com.DSTA.PJ_BE.utils.RandomStringGenerator;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

@Service
public class OrderServiceImp implements OrderService {
    private final Logger log = LoggerFactory.getLogger(OrderServiceImp.class);

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private OrderDetailsRepository orderDetailsRepository;

    @Autowired
    private CouponRepository couponRepository;

    @Autowired
    private ModelMapper mapper;

    @Override
    public DataResponse createOrder(OrderDTO orderDTO) {
        log.debug("Request Create Order");
        DataResponse res = new DataResponse();

        try {
            Account account = Common.getCurrentUserLogin();
            Order order = mapper.map(orderDTO, Order.class);
            Coupon coupon = couponRepository.findById(orderDTO.getCoupon()).orElse(null);
            if (order == null || account == null) {
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.NOT_FOUND);
                return res;
            }

            // Thiết lập các thuộc tính của đơn hàng
            order.setUserId(account);
            order.setUserName(orderDTO.getUserName());
            order.setTel(orderDTO.getTel());
            order.setAddress(orderDTO.getAddress());
            order.setDistrict(orderDTO.getDistrict());
            order.setWard(orderDTO.getWard());
            order.setCity(orderDTO.getCity());
            order.setPaymentMethod(orderDTO.getPaymentMethod());
            order.setSubtotal(orderDTO.getSubtotal());
            order.setTotalQuantity(orderDTO.getTotalQuantity());
            order.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            order.setStatus("Processing");

            // Tạo mã nameorder ngẫu nhiên
            String nameOrder = RandomStringGenerator.generateRandomString();
            order.setNameOrder(nameOrder);

            // Lưu đơn hàng
            orderRepository.save(order);

            // Lưu chi tiết đơn hàng
            for (ProductOrder productOrder : orderDTO.getProducts()) {
                Product product = productRepository.findById(productOrder.getProductId()).orElse(null);
                if (product != null) {
                    OrderDetails orderdetails = new OrderDetails();
                    orderdetails.setOrderId(order);
                    orderdetails.setProductId(product);
                    orderdetails.setQuantity(productOrder.getQuantity());
                    orderdetails.setPrice(productOrder.getPrice());
                    orderdetails.setCoupon(coupon);
                    orderdetails.setColor(productOrder.getColor());
                    orderDetailsRepository.save(orderdetails);
                }
            }

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.ADD_SUCCESS);
            res.setResult(order);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }




    @Override
    public DataResponse getAllOrders() {
        log.debug("Request Get All Orders");
        DataResponse res = new DataResponse();
        try {
            // Account account = Common.getCurrentUserLogin();
            List<Order> listOrders = orderRepository.findAll();
            if (listOrders == null || listOrders.isEmpty()) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }

            res.setStatus(Constants.SUCCESS);
            res.setResult(listOrders);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getOrdersByUserId() {
        log.debug("Request Get Orders By UserId");
        DataResponse res = new DataResponse();
        try {
            Account account = Common.getCurrentUserLogin();
            List<Order> listOrders = orderRepository.findAllByUserId(account.getId());
            if (listOrders == null || listOrders.isEmpty()) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }

            res.setStatus(Constants.SUCCESS);
            res.setResult(listOrders);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse updateOrder(Long id, OrderDTO orderDTO) {
        log.debug("Request Update Order");
        DataResponse res = new DataResponse();
        try {
            Order orderUpdate = orderRepository.findById(id).orElse(null);

            orderUpdate.setStatus(orderDTO.getStatus());


            orderRepository.save(orderUpdate);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.UPDATE_SUCCESS);
            res.setResult(orderUpdate);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    // @Override
    // public DataResponse deleteOrder(Long id) {
    //     log.debug("Request Delete Order");
    //     DataResponse res = new DataResponse();
    //     try {
    //         Order order = orderRepository.findById(id).orElse(null);
    //         if (order == null) {
    //             res.setStatus(Constants.NOT_FOUND);
    //             res.setMessage(Constants.LIST_NOT_FOUND);
    //             return res;
    //         }
    //         orderRepository.delete(order);
    //         res.setStatus(Constants.SUCCESS);
    //         res.setMessage(Constants.DELETE_SUCCESS);
    //         return res;
    //     } catch (Exception ex) {
    //         res.setStatus(Constants.ERROR);
    //         res.setMessage(Constants.SYSTEM_ERROR);
    //         return res;
    //     }
    // }
}