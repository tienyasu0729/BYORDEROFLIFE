package com.DSTA.PJ_BE.controller;

import com.DSTA.PJ_BE.dto.Brand.BrandDTO;
import com.DSTA.PJ_BE.service.BrandService;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/brands")
public class BrandController {
    private final Logger log = LoggerFactory.getLogger(BrandController.class);

    @Autowired
    private BrandService brandService;

    @PostMapping("/create-brands")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse createBrand(@RequestBody BrandDTO brandDTO){
        log.debug("Controller Request Create Brand");
        DataResponse res = brandService.createBrand(brandDTO);
        return res;
    }

    @GetMapping("/get-all-brands")
    public DataResponse getAllBrands(){
        log.debug("Controller Request Get All Brands");
        DataResponse res = brandService.getAllBrands();
        return res;
    }

    @PutMapping("/update-brand/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse updateBrand(@PathVariable("id") Long id, @RequestBody BrandDTO brandDTO){
        log.debug("Controller Request Update Brand");
        DataResponse res = brandService.updateBrand(id, brandDTO);
        return res;
    }

    @DeleteMapping("/delete-brand/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse deleteBrand(@PathVariable("id") Long id){
        log.debug("Controller Request Delete Brand");
        DataResponse res = brandService.deleteBrand(id);
        return res;
    }
}
