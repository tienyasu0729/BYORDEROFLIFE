package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.entity.Coupon;
import com.DSTA.PJ_BE.repository.CouponRepository;
import com.DSTA.PJ_BE.service.CouponService;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CouponServiceImp implements CouponService {
    private final Logger log = LoggerFactory.getLogger(CouponServiceImp.class);

    @Autowired
    private CouponRepository couponRepository;

    @Autowired
    private ModelMapper mapper;

    @Override
    public DataResponse createCoupon(Coupon coupon) {
        log.debug("Request Create Coupon");
        DataResponse res = new DataResponse();
        try {
            if(coupon.getCode().length()<3){
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.ERROR_ADD_NEW_COUPON);
                return res;
            }
            couponRepository.save(coupon);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.ADD_SUCCESS);
            res.setResult(coupon);
            return res;
        } catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getAllCoupons() {
        log.debug("Request Get All Coupons");
        DataResponse res = new DataResponse();
        try {
            List<Coupon> listCoupon = couponRepository.findAll();
            if(listCoupon == null || listCoupon.isEmpty()){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }

            res.setStatus(Constants.SUCCESS);
            res.setResult(listCoupon);
            return res;
        } catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse updateCoupon(Long id, Coupon coupon) {
        log.debug("Request Update Coupon");
        DataResponse res = new DataResponse();
        try {
            Coupon couponUpdate = couponRepository.findById(id).orElse(null);
            if(couponUpdate == null){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            couponUpdate.setCode(coupon.getCode());
            couponUpdate.setDescription(coupon.getDescription());
            couponUpdate.setDiscount(coupon.getDiscount());
            couponUpdate.setStartDate(coupon.getStartDate());
            couponUpdate.setEndDate(coupon.getEndDate());
            couponUpdate.setUsageLimit(coupon.getUsageLimit());
            couponUpdate.setUsedCount(coupon.getUsedCount());
            couponRepository.save(couponUpdate);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.UPDATE_SUCCESS);
            res.setResult(couponUpdate);
            return res;
        } catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse deleteCoupon(Long id) {
        log.debug("Request Delete Coupon");
        DataResponse res = new DataResponse();
        try {
            Coupon coupon = couponRepository.findById(id).orElse(null);
            if(coupon == null){
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            couponRepository.delete(coupon);
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.DELETE_SUCCESS);
            return res;
        } catch (Exception ex){
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
}
