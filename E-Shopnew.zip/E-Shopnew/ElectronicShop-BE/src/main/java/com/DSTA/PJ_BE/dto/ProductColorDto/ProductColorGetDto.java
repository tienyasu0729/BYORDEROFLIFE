package com.DSTA.PJ_BE.dto.ProductColorDto;

public class ProductColorGetDto {
    private Long id;
    private String nameColor;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getNameColor() {
        return nameColor;
    }
    public void setNameColor(String nameColor) {
        this.nameColor = nameColor;
    }
}
