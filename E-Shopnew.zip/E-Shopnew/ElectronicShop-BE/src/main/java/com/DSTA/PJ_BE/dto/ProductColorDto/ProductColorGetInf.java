package com.DSTA.PJ_BE.dto.ProductColorDto;

public interface ProductColorGetInf {
    Long getId();
    String getNameColor();
}
