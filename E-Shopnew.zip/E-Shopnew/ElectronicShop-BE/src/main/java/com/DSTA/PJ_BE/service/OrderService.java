package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.dto.Order.OrderDTO;
import com.DSTA.PJ_BE.utils.DataResponse;

public interface OrderService {
    DataResponse createOrder(OrderDTO orderDTO);
    DataResponse getAllOrders();
    DataResponse getOrdersByUserId();
    DataResponse updateOrder(Long id, OrderDTO orderDTO);
    // DataResponse deleteOrder(Long id);
}