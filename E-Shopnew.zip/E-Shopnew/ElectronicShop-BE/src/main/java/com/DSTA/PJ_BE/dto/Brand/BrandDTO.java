package com.DSTA.PJ_BE.dto.Brand;

public class BrandDTO {
    private Long id;
    private String nameBrand;
    private String slugBrand;
    private String status;
    // private Long categoryId;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNameBrand() {
        return nameBrand;
    }

    public void setNameBrand(String nameBrand) {
        this.nameBrand = nameBrand;
    }

    public String getSlugBrand() {
        return slugBrand;
    }

    public void setSlugBrand(String slugBrand) {
        this.slugBrand = slugBrand;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // public Long getCategoryId() {
    //     return categoryId;
    // }

    // public void setCategoryId(Long categoryId) {
    //     this.categoryId = categoryId;
    // }
}
