/**
 * Config
 */
/**
 * @author ACER
 *
 */
package DSTA.Cos.Cosmetics.config;