package com.DSTA.PJ_BE.dto.OrderDetails;

import java.io.IOException;
import java.math.BigDecimal;

import com.DSTA.PJ_BE.utils.Common;

public class OrderDetailView {
    private Long id;
    private String image;
    private String nameProduct;
    private String color;
    private Integer quantityProduct;
    private BigDecimal priceProduct;
    private BigDecimal total;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // Getter và Setter cho image
    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        try {
            this.image = Common.convertToBase64(image);
        } catch (IOException e) {
            this.image = image;
        }
    }

    // Getter và Setter cho nameProduct
    public String getNameProduct() {
        return nameProduct;
    }

    public void setNameProduct(String nameProduct) {
        this.nameProduct = nameProduct;
    }

    // Getter và Setter cho color
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    // Getter và Setter cho quantityProduct
    public Integer getQuantityProduct() {
        return quantityProduct;
    }

    public void setQuantityProduct(Integer quantityProduct) {
        this.quantityProduct = quantityProduct;
    }

    // Getter và Setter cho priceProduct
    public BigDecimal getPriceProduct() {
        return priceProduct;
    }

    public void setPriceProduct(BigDecimal priceProduct) {
        this.priceProduct = priceProduct;
    }

    // Getter và Setter cho total
    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

}