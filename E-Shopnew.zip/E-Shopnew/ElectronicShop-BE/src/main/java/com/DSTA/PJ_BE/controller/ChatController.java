package com.DSTA.PJ_BE.controller;


import com.DSTA.PJ_BE.entity.Message;
import com.DSTA.PJ_BE.entity.Status;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class ChatController {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @MessageMapping("/message")
    @SendTo("/topic/public")
    public Message sendPublicMessage(Message message) {
        message.setStatus(Status.MESSAGE);
        return message;
    }

    @MessageMapping("/private-message")
    public void sendPrivateMessage(Message message) {
        messagingTemplate.convertAndSendToUser(message.getReceiverName(), "/private", message);
    }

    @MessageMapping("/addUser")
    @SendTo("/topic/public")
    public Message addUser(Message message, SimpMessageHeaderAccessor headerAccessor) {
        headerAccessor.getSessionAttributes().put("username", message.getSenderName());
        message.setStatus(Status.JOIN);
        return message;
    }
}