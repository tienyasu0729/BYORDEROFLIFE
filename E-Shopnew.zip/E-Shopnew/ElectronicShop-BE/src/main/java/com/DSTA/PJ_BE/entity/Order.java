package com.DSTA.PJ_BE.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nameorder", columnDefinition = "VARCHAR(20)", nullable = false, unique = true)
    private String nameOrder;

    @ManyToOne
    @JoinColumn(name = "user_id",referencedColumnName = "id", columnDefinition = "BIGINT", nullable = false)
    private Account userId;
    @Column(name = "userName", columnDefinition = "TEXT", nullable = false )
    private String userName;
    @Column(name = "tel", columnDefinition = "VARCHAR(15)", nullable = false)
    private String tel;
    @Column(name = "address", columnDefinition = "TEXT", nullable = false )
    private String address;
    @Column(name = "district", columnDefinition = "TEXT", nullable = false)
    private String district;
    @Column(name = "ward", columnDefinition = "TEXT", nullable = false)
    private String ward;
    @Column(name = "city", columnDefinition = "TEXT", nullable = false)
    private String city;
    @Column(name = "note", columnDefinition = "TEXT", nullable = false)
    private String note;
    @Column(name = "created_at")
    private Timestamp createdAt;
    @Column(name = "status", columnDefinition = "VARCHAR(20) DEFAULT 'Processing'", nullable = false)
    private String status;
    @Column(name = "payment_method", columnDefinition = "VARCHAR(20)", nullable = false)
    private String paymentMethod;
    @Column(name = "subtotal", columnDefinition = "NUMERIC(10, 2)", nullable = false)
    private BigDecimal subtotal;
    @Column(name = "totalquantity", columnDefinition = "INT", nullable = false)
    private Integer totalQuantity;
    public Order() {
    }

    // Constructor that takes an id as a parameter
    public Order(Long id) {
        this.id = id;
    }
    public String getNameOrder() {
        return nameOrder;
    }

    public void setNameOrder(String nameOrder) {
        this.nameOrder = nameOrder;
    }

    public Integer getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(Integer totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public BigDecimal getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(BigDecimal subtotal) {
        this.subtotal = subtotal;
    }

    public String getWard() {
        return ward;
    }

    public void setWard(String ward) {
        this.ward = ward;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Account getUserId() {
        return userId;
    }

    public void setUserId(Account userId) {
        this.userId = userId;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }
}