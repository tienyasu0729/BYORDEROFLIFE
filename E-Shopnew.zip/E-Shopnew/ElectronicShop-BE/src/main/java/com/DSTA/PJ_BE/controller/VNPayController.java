package com.DSTA.PJ_BE.controller;

import com.DSTA.PJ_BE.service.VNPAYService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Logger;

@RestController
public class VNPayController {
    private static final Logger logger = Logger.getLogger(VNPayController.class.getName());

    @Autowired
    private VNPAYService vnPayService;

    @PostMapping("/submitOrder")
    public ResponseEntity<String> submitOrder(@RequestParam("amount") int orderTotal,
                                              @RequestParam("orderInfo") String orderInfo,
                                              HttpServletRequest request) {
        try {
            String baseUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort();
            logger.info("Submitting order with total: " + orderTotal + " and info: " + orderInfo);
            String vnpayUrl = vnPayService.createOrder(orderTotal, orderInfo, baseUrl);
            logger.info("Generated VNPay URL: " + vnpayUrl);
            return ResponseEntity.ok(vnpayUrl);
        } catch (Exception e) {
            logger.severe("Error creating VNPay order: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.ACCEPTED.INTERNAL_SERVER_ERROR).body("Error creating VNPay order: " + e.getMessage());
        }
    }

    @GetMapping("/vnpay-payment")
    public void getMapping(HttpServletRequest request, HttpServletResponse response, Model model) throws IOException {
        int paymentStatus = vnPayService.orderReturn(request);
        logger.info("VNPay payment status: " + paymentStatus);

        String orderInfo = request.getParameter("vnp_OrderInfo");
        String paymentTime = request.getParameter("vnp_PayDate");
        String transactionId = request.getParameter("vnp_TransactionNo");
        String totalPrice = request.getParameter("vnp_Amount");

        model.addAttribute("orderId", orderInfo);
        model.addAttribute("totalPrice", totalPrice);
        model.addAttribute("paymentTime", paymentTime);
        model.addAttribute("transactionId", transactionId);

        String redirectUrl;
        if (paymentStatus == 1) {
            redirectUrl = "http://localhost:3000/payment";
        } else {
            redirectUrl = "http://localhost:3000/orderFail";
        }

        response.sendRedirect(redirectUrl);
    }

}
