package com.DSTA.PJ_BE.controller;

import com.DSTA.PJ_BE.dto.Promotion.PromotionDTO;
import com.DSTA.PJ_BE.entity.Promotions;
import com.DSTA.PJ_BE.service.PromotionsService;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/promotions")
public class PromotionsController {
    private final Logger log = LoggerFactory.getLogger(PromotionsController.class);

    @Autowired
    private PromotionsService promotionsService;

    @PostMapping("/create-promotion")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse createPromotion(@RequestBody PromotionDTO promotionDTO) {
    log.debug("Controller Request Create Promotion");
    DataResponse res = promotionsService.createPromotion(promotionDTO);
    return res;
    }

    @GetMapping("/get-all-promotions")
    public DataResponse getAllPromotions() {
        log.debug("Controller Request Get All Promotions");
        DataResponse res = promotionsService.getAllPromotions();
        return res;
    }

    @PutMapping("/update-promotion/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse updatePromotion(@PathVariable("id") Long id, @RequestBody PromotionDTO promotionDTO) {
        log.debug("Controller Request Update Promotion");
        DataResponse res = promotionsService.updatePromotion(id, promotionDTO);
        return res;
    }

    @DeleteMapping("/delete-promotion/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse deletePromotion(@PathVariable("id") Long id) {
        log.debug("Controller Delete Promotion");
        DataResponse res = promotionsService.deletePromotion(id);
        return res;
    }
}
