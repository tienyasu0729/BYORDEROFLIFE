package com.DSTA.PJ_BE.dto.OrderDetails;

import java.math.BigDecimal;

public interface OrderDetailDtoItf {

    Long getId();
    String getImage();
    String getNameProduct();
    String getColor();
    Integer getQuantityProduct();
    BigDecimal getPriceProduct();
    BigDecimal getTotal();

}