package com.DSTA.PJ_BE.dto.Account;

public interface AccountDtoItf {
    Long getId();
    String getName();
    String getDob();
    String getTel();
    String getGender();
    String getAddress();
    String getAvatar();

}
