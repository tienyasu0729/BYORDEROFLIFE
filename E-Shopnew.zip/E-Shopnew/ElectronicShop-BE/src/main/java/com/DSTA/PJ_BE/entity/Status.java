package com.DSTA.PJ_BE.entity;

public enum Status {
    JOIN,
    MESSAGE,
    LEAVE
}
