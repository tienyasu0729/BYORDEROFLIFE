package com.DSTA.PJ_BE.repository;

import com.DSTA.PJ_BE.entity.WishList;
import com.DSTA.PJ_BE.dto.WishList.WishListDtoItf;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface WishListRepository extends JpaRepository<WishList, Long> {
    @Query(value = "SELECT w FROM WishList w WHERE w.user.id = :userId AND w.product.id = :productId")
    List<WishList> findByUserIdAndProductId(@Param("userId") Long userId, @Param("productId") Long productId);

    @Query(value = "SELECT p.id as productId, p.name_product as nameProduct, p.price as price, p.image as image , w.id as id " +
            "FROM Wish_List w " +
            "JOIN Product p ON w.product_id = p.id " +
            "WHERE w.user_id = :id", nativeQuery = true)
    List<WishListDtoItf> getAllWL(@Param("id") Long id);

    @Query(value = "SELECT w FROM WishList w WHERE w.id = :id")
    WishList getWLbyID(@Param("id") Long id);

    // @Query(value = "SELECT w FROM WishList w WHERE w.user.id = :id")
    // List<WishList> getWLbyUserID(@Param("id") Long id);

    // @Modifying
    // @Query(value = "DELETE FROM WishList w WHERE w.id = :id")
    // void removeFromWishList(@Param("id") Long id);

    // @Query(value = "SELECT w FROM WishList w WHERE w.product.id = :id")
    // List<WishList> getWLbyProductID(@Param("id") Long id);
}