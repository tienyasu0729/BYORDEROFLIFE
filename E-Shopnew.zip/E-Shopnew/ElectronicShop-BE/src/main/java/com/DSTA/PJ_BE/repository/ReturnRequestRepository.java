package com.DSTA.PJ_BE.repository;

import com.DSTA.PJ_BE.entity.ReturnRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReturnRequestRepository extends JpaRepository<ReturnRequest, Long> {
    // Các phương thức truy vấn tùy chỉnh có thể được khai báo tại đây nếu cần
}
