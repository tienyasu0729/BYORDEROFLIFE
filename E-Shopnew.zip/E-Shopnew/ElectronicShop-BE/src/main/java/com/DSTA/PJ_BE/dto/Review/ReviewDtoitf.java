package com.DSTA.PJ_BE.dto.Review;

import java.sql.Timestamp;

public interface ReviewDtoitf {
    Long getId();
    String getNameUser();
    String getAvatar();
    String getComment();
    Integer getRating();

    Long getProductId();
    String getProductName();
    String getProductImage();
    Timestamp getCreatedAt();
}