package com.DSTA.PJ_BE.repository;

import com.DSTA.PJ_BE.dto.Product.ProductGetAllInfDto;
import com.DSTA.PJ_BE.dto.Product.ProductGetByIdInfDto;
import com.DSTA.PJ_BE.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Set;
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    // @Query(value = "SELECT p FROM Product p")
    // List<Product> getAllProducts();
    // @Query("SELECT p FROM Product p JOIN FETCH p.productColors WHERE p.id = :id")
    // Optional<Product> findByIdWithColors(@Param("id") Long id);

    // @Query(value = "SELECT p FROM Product p WHERE p.id = :id")
    // Product getProductByID(@Param("id") Long id);

    @Query(
            value = "SELECT p.id as id, p.name_product as name, p.slug_product as slug, p.information as information, " +
                    "p.summary as summary, p.description as description, p.image as image, p.image2 as image2, p.image3 as image3, p.stock as stock, p.price as price, " +
                    "p.discounted_price as discountedPrice, p.status as status, c.name_category AS categoriesName, " +
                    "b.name_brand AS brandsName, SUM(od.quantity) as totalQuantitySold " +
                    "FROM product p " +
                    "JOIN order_details od ON p.id = od.product_id " +
                    "JOIN orders o ON od.order_id = o.id " +
                    "JOIN categories c ON p.categories_id = c.id " +
                    "JOIN brand b ON p.brands_id = b.id " +
                    "WHERE o.status = 'Confirmed' " +
                    "GROUP BY p.id, p.name_product, p.slug_product, p.information, p.summary, p.description, p.image, p.image2, p.image3, p.stock, p.price, p.discounted_price, p.status, c.name_category, b.name_brand " +
                    "ORDER BY totalQuantitySold DESC " +
                    "LIMIT 8",
            nativeQuery = true
    )
    List<ProductGetAllInfDto> getAllProductPpl();

    @Query
    (
        value = "SELECT p.id as id, p.name_product as name, p.slug_product as slug, p.information as information, " +
    "p.summary as summary, p.description as description, p.image as image, p.image2 as image2, p.image3 as image3, p.stock as stock, p.price as price, " +
    "p.discounted_price as discountedPrice, p.status as status, c.name_category AS categoriesName, " +
    "b.name_brand AS brandsName " +
    "FROM product p " +
    "JOIN categories c ON p.categories_id = c.id " +
    "JOIN brand b ON p.brands_id = b.id " +
    "ORDER BY p.id ASC ", nativeQuery = true
    )
    Page<ProductGetAllInfDto> getAllProductInf(Pageable pageable);

    @Query(value = "SELECT p FROM Product p WHERE p.id = :id")
    Product getProductByID(@Param("id") Long id);
    
    @Query(value = "SELECT p.name_product as name, p.slug_product as slug, p.information as information, p.summary as summary,"+
            "       p.description as description, p.image as image, p.image2 as image2, p.image3 as image3, p.stock as stock, p.price as price, p.discounted_price as discountedPrice,"+
            "       p.status as status, c.id as categoriesId, b.id as brandsId " +
            "FROM product p " +
            "JOIN categories c ON p.categories_id = c.id " +
            "JOIN brand b ON p.brands_id = b.id " +
            "WHERE p.id = :id", nativeQuery = true)
    ProductGetByIdInfDto getProductByIDInf(@Param("id") Long id);


}
