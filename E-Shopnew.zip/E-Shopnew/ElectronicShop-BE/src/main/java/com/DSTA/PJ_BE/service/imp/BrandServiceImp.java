package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.dto.Brand.BrandDTO;
import com.DSTA.PJ_BE.entity.Brand;
import com.DSTA.PJ_BE.entity.Categories;
import com.DSTA.PJ_BE.repository.BrandRepository;
import com.DSTA.PJ_BE.repository.CategoryRepository;
import com.DSTA.PJ_BE.service.BrandService;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BrandServiceImp implements BrandService {
    private final Logger log = LoggerFactory.getLogger(BrandServiceImp.class);

    @Autowired
    private BrandRepository brandRepository;

    @Autowired
    private CategoryRepository categoriesRepository;

    @Autowired
    private ModelMapper mapper;

    @Override
    public DataResponse createBrand(BrandDTO brandDTO) {
        log.debug("Request Create Brand");
        DataResponse res = new DataResponse();
        try {
            if (brandDTO.getNameBrand().length() < 3 || brandDTO.getSlugBrand().length() < 3) {
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.ERROR_ADD_NEW_BRAND);
                return res;
            }
            // Categories category = categoriesRepository.findById(brandDTO.getCategoryId()).orElse(null);
            // if (category == null) {
            //     res.setStatus(Constants.NOT_FOUND);
            //     res.setMessage(Constants.CATEGORIES_NOT_FOUND);
            //     return res;
            // }
            Brand brand = mapper.map(brandDTO, Brand.class);
            // brand.setCategory(category);
            brandRepository.save(brand);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.ADD_SUCCESS);
            res.setResult(brand);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getAllBrands() {
        log.debug("Request Get All Brands");
        DataResponse res = new DataResponse();
        try {
            List<Brand> listBrand = brandRepository.findAll();
            if (listBrand == null || listBrand.isEmpty()) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }

            res.setStatus(Constants.SUCCESS);
            res.setResult(listBrand);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse updateBrand(Long id, BrandDTO brandDTO) {
        log.debug("Request Update Brand");
        DataResponse res = new DataResponse();
        try {
            Brand brandUpdate = brandRepository.findById(id).orElse(null);
            if (brandUpdate == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            // Categories category = categoriesRepository.findById(brandDTO.getCategoryId()).orElse(null);
            // if (category == null) {
            //     res.setStatus(Constants.NOT_FOUND);
            //     res.setMessage(Constants.CATEGORIES_NOT_FOUND);
            //     return res;
            // }
            brandUpdate.setNameBrand(brandDTO.getNameBrand());
            brandUpdate.setSlugBrand(brandDTO.getSlugBrand());
            brandUpdate.setStatus(brandDTO.getStatus());
            // brandUpdate.setCategory(category);
            brandRepository.save(brandUpdate);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.UPDATE_SUCCESS);
            res.setResult(brandUpdate);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse deleteBrand(Long id) {
        log.debug("Request Delete Brand");
        DataResponse res = new DataResponse();
        try {
            Brand brand = brandRepository.findById(id).orElse(null);
            if (brand == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            brandRepository.delete(brand);
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.DELETE_SUCCESS);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
}
