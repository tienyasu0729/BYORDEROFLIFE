package com.DSTA.PJ_BE.dto.WishList;

import java.math.BigDecimal;

public interface WishListDtoItf {
    Long getId();
    Long getProductId();
    String getNameProduct();
    BigDecimal getPrice();
    String getImage();

}