package com.DSTA.PJ_BE.dto.ReturnRequest;

import java.sql.Timestamp;

public class ReturnRequestDTO {
    private Long returnRequestID;
    private Timestamp requestDate;
    private String status;
    private String reason;
    private Long orderId;

    // Default constructor
    public ReturnRequestDTO() {
    }

    // Getters and Setters

    public Long getReturnRequestID() {
        return returnRequestID;
    }

    public void setReturnRequestID(Long returnRequestID) {
        this.returnRequestID = returnRequestID;
    }

    public Timestamp getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Timestamp requestDate) {
        this.requestDate = requestDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
}
