package com.DSTA.PJ_BE.controller;

import com.DSTA.PJ_BE.dto.WishList.WishListDTO;
import com.DSTA.PJ_BE.service.WishListService;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/wishlists")
public class WishListController {
    private final Logger log = LoggerFactory.getLogger(WishListController.class);

    @Autowired
    private WishListService wishListService;

    @PostMapping("/create-wishlist")
    public DataResponse createWishList(@RequestBody WishListDTO wishListDTO) {
        log.debug("Controller Request Create WishList");
        DataResponse res = wishListService.createWishList(wishListDTO);
        return res;
    }

    @GetMapping("/get-all-wishlists")
    public DataResponse getAllWishLists() {
        log.debug("Controller Request Get All WishLists");
        DataResponse res = wishListService.getAllWishLists();
        return res;
    }

    @DeleteMapping("/delete-wishlist/{id}")

    public DataResponse deleteWishList(@PathVariable("id") Long id) {
        log.debug("Controller Request Delete WishList");
        DataResponse res = wishListService.deleteWishList(id);
        return res;
    }
}