package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.dto.Promotion.PromotionDTO;
import com.DSTA.PJ_BE.entity.Promotions;
import com.DSTA.PJ_BE.repository.PromotionsRepository;
import com.DSTA.PJ_BE.service.PromotionsService;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PromotionsServiceImp implements PromotionsService {
    private final Logger log = LoggerFactory.getLogger(PromotionsServiceImp.class);

    @Autowired
    private PromotionsRepository promotionsRepository;

    @Autowired
    private ModelMapper mapper;

    @Override
    public DataResponse createPromotion(PromotionDTO promotionDTO) {
        log.debug("Request Create Promotion");
        DataResponse res = new DataResponse();
        try {
            // Chuyển đổi PromotionDTO sang thực thể Promotions
            Promotions promotion = new Promotions();
            promotion.setDescription(promotionDTO.getDescription());
            promotion.setStartDate(promotionDTO.getStartDate());
            promotion.setEndDate(promotionDTO.getEndDate());
            promotion.setDiscount(promotionDTO.getDiscount());

            // Lưu thực thể Promotions vào cơ sở dữ liệu
            promotionsRepository.save(promotion);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.ADD_SUCCESS);
            res.setResult(promotion);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getAllPromotions() {
        log.debug("Request Get All Promotions");
        DataResponse res = new DataResponse();
        try {
            List<Promotions> listPromotions = promotionsRepository.findAll();
            if (listPromotions == null || listPromotions.isEmpty()) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }

            res.setStatus(Constants.SUCCESS);
            res.setResult(listPromotions);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse updatePromotion(Long id, PromotionDTO promotionDTO) {
        log.debug("Request Update Promotion");
        DataResponse res = new DataResponse();
        try {
            Promotions promotionUpdate = promotionsRepository.findById(id).orElse(null);
            if (promotionUpdate == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            // Cập nhật các trường
            promotionUpdate.setDescription(promotionDTO.getDescription());
            promotionUpdate.setStartDate(promotionDTO.getStartDate());
            promotionUpdate.setEndDate(promotionDTO.getEndDate());
            promotionUpdate.setDiscount(promotionDTO.getDiscount());

            promotionsRepository.save(promotionUpdate);

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.UPDATE_SUCCESS);
            res.setResult(promotionUpdate);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse deletePromotion(Long id) {
        log.debug("Request Delete Promotion");
        DataResponse res = new DataResponse();
        try {
            Promotions promotion = promotionsRepository.findById(id).orElse(null);
            if (promotion == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            promotionsRepository.delete(promotion);
            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.DELETE_SUCCESS);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
}
