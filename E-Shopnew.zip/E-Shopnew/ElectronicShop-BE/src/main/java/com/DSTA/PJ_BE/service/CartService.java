package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.dto.Cart.CartDTO;
import com.DSTA.PJ_BE.utils.DataResponse;

public interface CartService {
    DataResponse createCart(CartDTO cartDTO);
    DataResponse getAllCarts();
    DataResponse updateCart(Long id, CartDTO cartDTO);
    DataResponse deleteCart(Long id);
    DataResponse deleteAllCart();
}