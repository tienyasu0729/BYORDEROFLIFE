package com.DSTA.PJ_BE.controller;

import com.DSTA.PJ_BE.dto.OrderDetails.OrderDetailsDTO;
import com.DSTA.PJ_BE.service.OrderDetailsService;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/order-details")
public class OrderDetailsController {
    private final Logger log = LoggerFactory.getLogger(OrderDetailsController.class);

    @Autowired
    private OrderDetailsService orderDetailsService;

    @GetMapping("/get-order-details-by-order/{orderId}")
    public DataResponse getOrderDetailsByOrderId(@PathVariable("orderId") Long orderId) {
        log.debug("Controller Request Get Order Details By OrderId");
        DataResponse res = orderDetailsService.getOrderDetailsByOrderId(orderId);
        return res;
    }
    @GetMapping("/get-reveneu")
    public DataResponse getRevenue() {
        log.debug("Controller Request Get Reveneu");
        DataResponse res = orderDetailsService.getRevenue();
        return res;
    }
}