package com.DSTA.PJ_BE.dto.WishList;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class WishListDTO {
    // private Long id;
    // private Long userId;
    private Long productId;
    private BigDecimal price;

    // public Long getId() {
    //     return id;
    // }

    // public void setId(Long id) {
    //     this.id = id;
    // }

    // public Long getUserId() {
    //     return userId;
    // }

    // public void setUserId(Long userId) {
    //     this.userId = userId;
    // }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }


}