
// package com.DSTA.PJ_BE.service.imp;

// import com.DSTA.PJ_BE.dto.Product.ProductADto;
// import com.DSTA.PJ_BE.dto.Product.ProductGetAllDto;
// import com.DSTA.PJ_BE.dto.Product.ProductGetAllInfDto;
// import com.DSTA.PJ_BE.entity.Account;
// import com.DSTA.PJ_BE.entity.Categories;
// import com.DSTA.PJ_BE.entity.Product;
// // import com.DSTA.PJ_BE.entity.ProductColor;
// import com.DSTA.PJ_BE.entity.Brand;
// import com.DSTA.PJ_BE.entity.Promotions;
// // import com.DSTA.PJ_BE.entity.Color;
// import com.DSTA.PJ_BE.repository.ProductRepository;
// import com.DSTA.PJ_BE.repository.CategoryRepository;
// import com.DSTA.PJ_BE.repository.BrandRepository;
// import com.DSTA.PJ_BE.repository.PromotionsRepository;
// // import com.DSTA.PJ_BE.repository.ProductColorRepository;
// // import com.DSTA.PJ_BE.repository.ColorRepository;
// import com.DSTA.PJ_BE.service.ProductService;
// import com.DSTA.PJ_BE.utils.Common;
// import com.DSTA.PJ_BE.utils.Constants;
// import com.DSTA.PJ_BE.utils.DataResponse;
// import org.modelmapper.ModelMapper;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;
// import org.springframework.web.multipart.MultipartFile;
// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.Pageable;


// import java.util.List;

// @Service
// public class ProductServiceImp implements ProductService {
//     private final Logger log = LoggerFactory.getLogger(ProductServiceImp.class);

//     @Autowired
//     private ProductRepository productRepository;

//     @Autowired
//     private CategoryRepository categoryRepository;

//     @Autowired
//     private BrandRepository brandRepository;

//     @Autowired
//     private PromotionsRepository promotionsRepository;

//     // @Autowired
//     // private ProductColorRepository productColorRepository;

//     // @Autowired
//     // private ColorRepository colorRepository;

//     @Autowired
//     private ModelMapper mapper;

//     @Override
    
//     public DataResponse addNewProduct(MultipartFile file1, MultipartFile file2, MultipartFile file3, String str) {
//         log.debug("Request Add New Product");
//         DataResponse res = new DataResponse();
//         Account account = Common.getCurrentUserLogin();
//         Product product = new Product();
//         try {
//             ProductADto productADto = Common.convertStringToObject(str, ProductADto.class);
//             product = mapper.map(productADto, Product.class);

//             if (productADto.getName().length() < 5 || productADto.getSlug().length() < 5) {
//                 res.setStatus(Constants.ERROR);
//                 res.setMessage(Constants.ERROR_ADD_NEW_PRODUCT);
//                 return res;
//             }

//             String imageUrl = Constants.IMG_PRODUCT_SAVE + account.getId() + "/" + Common.currentDate() + "/";
//             String img1 = Common.saveFile(file1, imageUrl, account.getId(), product.getName());
//             String img2 = Common.saveFile(file2, imageUrl, account.getId(), product.getName() + "2");
//             String img3 = Common.saveFile(file3, imageUrl, account.getId(), product.getName() + "3");
//             if (img1 != null) {
//                 product.setImage(img1);
//             }
//             if (img2 != null) {
//                 product.setImage2(img2);
//             }
//             if (img3 != null) {
//                 product.setImage3(img3);
//             }

//             Categories categories = categoryRepository.findById(productADto.getCategoriesId()).orElse(null);
//             Brand brand = brandRepository.findById(productADto.getBrandsId()).orElse(null);
//             Promotions promotion = promotionsRepository.findById(productADto.getPromotionId()).orElse(null);

//             product.setCategoriesId(categories);
//             product.setBrandsId(brand);
//             product.setPromotion(promotion);
//             product.setName(productADto.getName());
//             product.setSlug(productADto.getSlug());
//             product.setDescription(productADto.getDescription());
//             product.setInformation(productADto.getInformation());
//             product.setSummary(productADto.getSummary());
//             product.setStock(productADto.getStock());
//             product.setPrice(productADto.getPrice());
//             product.setDiscountedPrice(productADto.getDiscountedPrice());
//             product.setStatus(productADto.getStatus());

//             productRepository.save(product);
//             res.setStatus(Constants.SUCCESS);
//             res.setMessage(Constants.ADD_PRODUCT_SUCCESS);
//             res.setResult(product);
//             return res;
//         } catch (Exception ex) {
//             res.setStatus(Constants.ERROR);
//             res.setMessage(Constants.SYSTEM_ERROR);
//             return res;
//         }
//     }


    


//     @Override
//     public DataResponse getAllProducts() {
//         log.debug("Request Get All Products");
//         DataResponse res = new DataResponse();
//         try {
//             List<Product> listProduct = productRepository.getAllProducts();
//             if (listProduct == null || listProduct.isEmpty()) {
//                 res.setStatus(Constants.NOT_FOUND);
//                 res.setMessage(Constants.PRODUCTS_NOT_FOUND);
//                 return res;
//             }
//             res.setStatus(Constants.SUCCESS);
//             res.setResult(listProduct);
//             return res;
//         } catch (Exception ex) {
//             res.setStatus(Constants.ERROR);
//             res.setMessage(Constants.SYSTEM_ERROR);
//             return res;
//         }
//     }



//     @Override
//     public DataResponse deleteProduct(Long id) {
//         log.debug("Request Delete Product");
//         DataResponse res = new DataResponse();
//         Account account = Common.getCurrentUserLogin();
//         try {
//             Product product = productRepository.getProductByID(id);
//             if (product == null) {
//                 res.setStatus(Constants.NOT_FOUND);
//                 res.setMessage(Constants.PRODUCTS_NOT_FOUND);
//                 return res;
//             }
//             String imgPath = Constants.IMG_PRODUCT_SAVE + account.getId();
//             productRepository.delete(product);
//             Common.deleteImageFolder(imgPath);

//             res.setStatus(Constants.SUCCESS);
//             res.setMessage(Constants.DELETE_SUCCESS);
//             return res;
//         } catch (Exception ex) {
//             res.setStatus(Constants.ERROR);
//             res.setMessage(Constants.SYSTEM_ERROR);
//             return res;
//         }
//     }



//     @Override
//     public DataResponse updateProduct(MultipartFile file1, MultipartFile file2, MultipartFile file3, String str, Long id) {
//         log.debug("Request Update Product");
//         DataResponse res = new DataResponse();
//         Account account = Common.getCurrentUserLogin();
//         try {
//             ProductADto productADto = Common.convertStringToObject(str, ProductADto.class);
//             Product product = productRepository.getProductByID(id);
//             if (productADto.getName().length() < 5 || productADto.getSlug().length() < 5) {
//                 res.setStatus(Constants.ERROR);
//                 res.setMessage(Constants.ERROR_ADD_NEW_PRODUCT);
//                 return res;
//             }

//             String imageUrl = Constants.IMG_PRODUCT_SAVE + account.getId() + "/" + Common.currentDate() + "/";
            
//             if (file1 != null && !file1.isEmpty()) {
//                 String img1 = Common.saveFile(file1, imageUrl, product.getId(), product.getName());
//                 if (img1 != null) {
//                     product.setImage(img1);
//                 }
//             } else {
//                 product.setImage(product.getImage());
//             }
//             if (file2 != null && !file2.isEmpty()) {
//                 String img2 = Common.saveFile(file2, imageUrl, product.getId(), product.getName() + "2");
//                 if (img2 != null) {
//                     product.setImage2(img2);
//                 }
//             } else {
//                 product.setImage2(product.getImage2());
//             }
//             if (file3 != null && !file3.isEmpty()) {
//                 String img3 = Common.saveFile(file3, imageUrl, product.getId(), product.getName() + "3");
//                 if (img3 != null) {
//                     product.setImage3(img3);
//                 }
//             } else {
//                 product.setImage3(product.getImage3());
//             }

//             Categories categories = categoryRepository.findById(productADto.getCategoriesId()).orElse(null);
//             Brand brand = brandRepository.findById(productADto.getBrandsId()).orElse(null);
//             Promotions promotion = promotionsRepository.findById(productADto.getPromotionId()).orElse(null);

//             product.setCategoriesId(categories);
//             product.setBrandsId(brand);
//             product.setPromotion(promotion);
//             product.setName(productADto.getName());
//             product.setSlug(productADto.getSlug());
//             product.setDescription(productADto.getDescription());
//             product.setInformation(productADto.getInformation());
//             product.setSummary(productADto.getSummary());
//             product.setStock(productADto.getStock());
//             product.setPrice(productADto.getPrice());
//             product.setDiscountedPrice(productADto.getDiscountedPrice());
//             product.setStatus(productADto.getStatus());

//             productRepository.save(product);

//             res.setStatus(Constants.SUCCESS);
//             res.setMessage(Constants.UPDATE_SUCCESS);
//             res.setResult(product);
//             return res;
//         } catch (Exception ex) {
//             res.setStatus(Constants.ERROR);
//             res.setMessage(Constants.SYSTEM_ERROR);
//             return res;
//         }
//     }
   


// }

package com.DSTA.PJ_BE.service.imp;

import com.DSTA.PJ_BE.dto.Product.ProductADto;
import com.DSTA.PJ_BE.dto.Product.ProductDetailDto;
import com.DSTA.PJ_BE.dto.Product.ProductGetAllDto;
import com.DSTA.PJ_BE.dto.Product.ProductGetAllInfDto;
import com.DSTA.PJ_BE.dto.Product.ProductGetByIdDto;
import com.DSTA.PJ_BE.dto.Product.ProductGetByIdInfDto;
import com.DSTA.PJ_BE.dto.ProductColorDto.ProductColorGetDto;
import com.DSTA.PJ_BE.dto.ProductColorDto.ProductColorGetInf;
import com.DSTA.PJ_BE.entity.*;
import com.DSTA.PJ_BE.repository.*;
import com.DSTA.PJ_BE.service.ProductService;
import com.DSTA.PJ_BE.utils.Common;
import com.DSTA.PJ_BE.utils.Constants;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class ProductServiceImp implements ProductService {
    private final Logger log = LoggerFactory.getLogger(ProductServiceImp.class);

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private BrandRepository brandRepository;

    @Autowired
    private PromotionsRepository promotionsRepository;

    @Autowired
    private ProductColorRepository productColorRepository;

    @Autowired
    private ColorRepository colorRepository;

    @Autowired
    private ModelMapper mapper;

    @Override
    public DataResponse addNewProduct(MultipartFile file1, MultipartFile file2, MultipartFile file3, String str) {
        log.debug("Request Add New Product");
        DataResponse res = new DataResponse();
        Account account = Common.getCurrentUserLogin();
        Product product = new Product();
        try {
            log.debug("Received str: {}", str);

            ProductADto productADto = Common.convertStringToObject(str, ProductADto.class);
            log.debug("Converted ProductADto: {}", productADto);

            // Check for null fields
            if (productADto.getCategoriesId() == null) {
                log.error("Category ID is null");
                throw new IllegalArgumentException("Category ID cannot be null");
            }
            if (productADto.getBrandsId() == null) {
                log.error("Brand ID is null");
                throw new IllegalArgumentException("Brand ID cannot be null");
            }

            product = mapper.map(productADto, Product.class);
            log.debug("Mapped Product: {}", product);

            if (productADto.getName().length() < 5 || productADto.getSlug().length() < 5) {
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.ERROR_ADD_NEW_PRODUCT);
                log.debug("Validation failed: name or slug too short");
                return res;
            }

            String imageUrl = Constants.IMG_PRODUCT_SAVE + account.getId() + "/" + Common.currentDate() + "/";
            log.debug("Image URL: {}", imageUrl);

            String img1 = Common.saveFile(file1, imageUrl, account.getId(), product.getName());
            String img2 = Common.saveFile(file2, imageUrl, account.getId(), product.getName() + "2");
            String img3 = Common.saveFile(file3, imageUrl, account.getId(), product.getName() + "3");
            log.debug("Saved images: img1={}, img2={}, img3={}", img1, img2, img3);

            if (img1 != null) {
                product.setImage(img1);
            }
            if (img2 != null) {
                product.setImage2(img2);
            }
            if (img3 != null) {
                product.setImage3(img3);
            }

            Categories categories = categoryRepository.findById(productADto.getCategoriesId()).orElse(null);
            Brand brand = brandRepository.findById(productADto.getBrandsId()).orElse(null);
            Promotions promotion = promotionsRepository.findById(productADto.getPromotionId()).orElse(null);

            product.setCategoriesId(categories);
            product.setBrandsId(brand);
            product.setPromotion(promotion);
            product.setName(productADto.getName());
            product.setSlug(productADto.getSlug());
            product.setDescription(productADto.getDescription());
            product.setInformation(productADto.getInformation());
            product.setSummary(productADto.getSummary());
            product.setStock(productADto.getStock());
            product.setPrice(productADto.getPrice());
            product.setDiscountedPrice(productADto.getDiscountedPrice());
            product.setStatus(productADto.getStatus());

            log.debug("Final Product: {}", product);

            productRepository.save(product);
            log.debug("Product saved");

            for (Long colorId : productADto.getColorId()) {
                Color color = colorRepository.findById(colorId).orElse(null);
                if (color != null) {
                    ProductColor productColor = new ProductColor();
                    productColor.setProduct(product);
                    productColor.setColor(color);
                    productColorRepository.save(productColor);
                    log.debug("ProductColor saved: {}", productColor);
                }
            }

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.ADD_PRODUCT_SUCCESS);
            res.setResult(product);
            log.debug("Response: {}", res);
            return res;
        } catch (Exception ex) {
            log.error("Exception occurred while adding new product", ex);
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }





    public DataResponse getAllProducts(Pageable pageable) {
        log.debug("Request Get All Product");
        DataResponse res = new DataResponse();
        try {
            Page<ProductGetAllInfDto> listProduct = productRepository.getAllProductInf(pageable);
            if (!listProduct.hasContent()) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            Page<ProductGetAllDto> productGetAll = Common.mapPage(listProduct, ProductGetAllDto.class);
            res.setStatus(Constants.SUCCESS);
            res.setResult(productGetAll);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    @Override
    public DataResponse getProductId(Long id) {
        log.debug("Request Get Product By Id");
        DataResponse res = new DataResponse();
        try {
            ProductGetByIdInfDto productInf = productRepository.getProductByIDInf(id);
            
            List<ProductColorGetInf> productColorListInf = productColorRepository.getColor(id);
            if (productInf == null) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            
            ProductGetByIdDto productGetAll = mapper.map(productInf, ProductGetByIdDto.class);
            List<ProductColorGetDto> colorGetDto = Common.mapList(productColorListInf, ProductColorGetDto.class);

            ProductDetailDto productDetailDto = new ProductDetailDto(productGetAll, colorGetDto);
            res.setStatus(Constants.SUCCESS);
            res.setResult(productDetailDto);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }

    

    @Override
public DataResponse deleteProduct(Long id) {
    log.debug("Request Delete Product");
    DataResponse res = new DataResponse();
    Account account = Common.getCurrentUserLogin();
    try {
        Product product = productRepository.getProductByID(id);
        if (product == null) {
            res.setStatus(Constants.NOT_FOUND);
            res.setMessage(Constants.PRODUCTS_NOT_FOUND);
            return res;
        }
        List<ProductColor> productColors = productColorRepository.getProductColorByProductId(product.getId());
            for (ProductColor productColor : productColors) {
                productColorRepository.delete(productColor);
            }
        
        // Xóa Product
       // String imgPath = Constants.IMG_PRODUCT_SAVE + account.getId();
        productRepository.delete(product);
       // Common.deleteImageFolder(imgPath);

        res.setStatus(Constants.SUCCESS);
        res.setMessage(Constants.DELETE_SUCCESS);
        return res;
    } catch (Exception ex) {
        res.setStatus(Constants.ERROR);
        res.setMessage(Constants.SYSTEM_ERROR);
        return res;
    }
}


    @Override
    public DataResponse updateProduct(MultipartFile file1, MultipartFile file2, MultipartFile file3, String str, Long id) {
        log.debug("Request Update Product");
        DataResponse res = new DataResponse();
        Account account = Common.getCurrentUserLogin();
        try {
            log.debug("Received product data string: {}", str);
            ProductADto productADto = Common.convertStringToObject(str, ProductADto.class);
            Product product = productRepository.getProductByID(id);

            if (productADto.getName().length() < 5 || productADto.getSlug().length() < 5) {
                res.setStatus(Constants.ERROR);
                res.setMessage(Constants.ERROR_ADD_NEW_PRODUCT);
                return res;
            }

            String imageUrl = Constants.IMG_PRODUCT_SAVE + account.getId() + "/" + Common.currentDate() + "/";

            if (file1 != null && !file1.isEmpty()) {
                String img1 = Common.saveFile(file1, imageUrl, product.getId(), product.getName());
                if (img1 != null) {
                    product.setImage(img1);
                }
            } else {
                product.setImage(product.getImage());
            }
            if (file2 != null && !file2.isEmpty()) {
                String img2 = Common.saveFile(file2, imageUrl, product.getId(), product.getName() + "2");
                if (img2 != null) {
                    product.setImage2(img2);
                }
            } else {
                product.setImage2(product.getImage2());
            }
            if (file3 != null && !file3.isEmpty()) {
                String img3 = Common.saveFile(file3, imageUrl, product.getId(), product.getName() + "3");
                if (img3 != null) {
                    product.setImage3(img3);
                }
            } else {
                product.setImage3(product.getImage3());
            }

            Categories categories = categoryRepository.findById(productADto.getCategoriesId()).orElse(null);
            Brand brand = brandRepository.findById(productADto.getBrandsId()).orElse(null);
            Promotions promotion = promotionsRepository.findById(productADto.getPromotionId()).orElse(null);

            product.setCategoriesId(categories);
            product.setBrandsId(brand);
            product.setPromotion(promotion);
            product.setName(productADto.getName());
            product.setSlug(productADto.getSlug());
            product.setDescription(productADto.getDescription());
            product.setInformation(productADto.getInformation());
            product.setSummary(productADto.getSummary());
            product.setStock(productADto.getStock());
            product.setPrice(productADto.getPrice());
            product.setDiscountedPrice(productADto.getDiscountedPrice());
            product.setStatus(productADto.getStatus());
            productRepository.save(product);

            List<ProductColor> productColor = productColorRepository.getProductColorByProductId(product.getId());

            if (productADto.getColorId() != null) {
                // Xóa các ProductColor hiện có
                for (ProductColor pc : productColor) {
                    productColorRepository.delete(pc);
                }

                // Thêm các ProductColor mới
                for (Long colorId : productADto.getColorId()) {
                    Color color = colorRepository.findById(colorId).orElse(null);
                    if (color != null) {
                        ProductColor newProductColor = new ProductColor();
                        newProductColor.setProduct(product);
                        newProductColor.setColor(color);
                        productColorRepository.save(newProductColor);
                    }
                }
            }

            res.setStatus(Constants.SUCCESS);
            res.setMessage(Constants.UPDATE_SUCCESS);
            res.setResult(product);
            return res;
        } catch (Exception ex) {
            log.error("Exception occurred while updating product", ex);
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }
    public DataResponse getProductsPopular() {
        log.debug("Request Get All Product Popular");
        DataResponse res = new DataResponse();
        try {
            List<ProductGetAllInfDto> listProduct = productRepository.getAllProductPpl();
            if (listProduct == null || listProduct.isEmpty()) {
                res.setStatus(Constants.NOT_FOUND);
                res.setMessage(Constants.LIST_NOT_FOUND);
                return res;
            }
            List<ProductGetAllDto> productGetAll = Common.mapList(listProduct, ProductGetAllDto.class);
            res.setStatus(Constants.SUCCESS);
            res.setResult(productGetAll);
            return res;
        } catch (Exception ex) {
            res.setStatus(Constants.ERROR);
            res.setMessage(Constants.SYSTEM_ERROR);
            return res;
        }
    }



}

