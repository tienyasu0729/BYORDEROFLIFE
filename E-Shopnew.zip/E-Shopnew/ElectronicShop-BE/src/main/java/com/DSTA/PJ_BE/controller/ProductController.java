
package com.DSTA.PJ_BE.controller;

import com.DSTA.PJ_BE.service.ProductService;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.slf4j.Logger;
import org.springframework.data.domain.Pageable;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@RestController
@RequestMapping("/api/product")
public class ProductController {
    private final Logger log = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private ProductService productService;

    @PostMapping("/create-product")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse createProduct(MultipartHttpServletRequest data) {
        log.debug("Controller Request Create New Product");
        MultipartFile file1 = data.getFile("image");
        MultipartFile file2 = data.getFile("image2");
        MultipartFile file3 = data.getFile("image3");
        String str = data.getParameter("product");
        DataResponse res = productService.addNewProduct(file1, file2, file3, str);
        return res;
    }
    @GetMapping("/get-all-product-popular")
    public DataResponse getProductsPopular() {
        log.debug("Controller Request Get All Products");
        DataResponse res = productService.getProductsPopular();
        return res;
    }
    @GetMapping("/get-all-product")
    public DataResponse getAllProducts(@PageableDefault(page = 0, size = 8) Pageable pageable) {
        log.debug("Controller Request Get All Products");
        DataResponse res = productService.getAllProducts(pageable);
        return res;
    }

    @GetMapping("/get-product-id/{id}")
    public DataResponse getProductById(@PathVariable("id") Long id){
        log.debug("Controller Get Product By Id");
        DataResponse res = productService.getProductId(id);
        return res;
    }

    @DeleteMapping("/delete-product/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse deleteProduct(@PathVariable("id") Long id) {
        log.debug("Controller Request Delete Product");
        DataResponse res = productService.deleteProduct(id);
        return res;
    }

    @PutMapping("/update-product/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse updateProduct(MultipartHttpServletRequest data, @PathVariable("id") Long id) {
        log.debug("Controller Request Update Product");
        MultipartFile file1 = data.getFile("image");
        MultipartFile file2 = data.getFile("image2");
        MultipartFile file3 = data.getFile("image3");
        String str = data.getParameter("product");
        DataResponse res = productService.updateProduct(file1, file2, file3, str, id);
        return res;
    }
}
