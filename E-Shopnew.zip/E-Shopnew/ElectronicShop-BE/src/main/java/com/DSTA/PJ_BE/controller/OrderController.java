package com.DSTA.PJ_BE.controller;

import com.DSTA.PJ_BE.dto.Order.OrderDTO;
import com.DSTA.PJ_BE.service.OrderService;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final Logger log = LoggerFactory.getLogger(OrderController.class);

    @Autowired
    private OrderService orderService;

    @PostMapping("/create-order")

    public DataResponse createOrder(@RequestBody OrderDTO orderDTO) {
        log.debug("Controller Request Create Order");
        DataResponse res = orderService.createOrder(orderDTO);
        return res;
    }

    @GetMapping("/get-all-orders")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse getAllOrders() {
        log.debug("Controller Request Get All Orders");
        DataResponse res = orderService.getAllOrders();
        return res;
    }

    @GetMapping("/get-orders-by-user")

    public DataResponse getOrdersByUserId() {
        log.debug("Controller Request Get Orders By UserId");
        DataResponse res = orderService.getOrdersByUserId();
        return res;
    }

    @PutMapping("/update-order/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public DataResponse updateOrder(@PathVariable("id") Long id, @RequestBody OrderDTO orderDTO) {
        log.debug("Controller Request Update Order");
        DataResponse res = orderService.updateOrder(id, orderDTO);
        return res;
    }


}