package com.DSTA.PJ_BE.service;

import com.DSTA.PJ_BE.dto.WishList.WishListDTO;
import com.DSTA.PJ_BE.utils.DataResponse;

public interface WishListService {
    DataResponse createWishList(WishListDTO wishListDTO);
    DataResponse getAllWishLists();
    // DataResponse updateWishList(Long id, WishListDTO wishListDTO);
    DataResponse deleteWishList(Long id);
}