package com.DSTA.PJ_BE.controller;
import com.DSTA.PJ_BE.entity.Product;
import com.DSTA.PJ_BE.dto.Review.ReviewDTO;
import com.DSTA.PJ_BE.service.ReviewService;
import com.DSTA.PJ_BE.utils.DataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {
    private final Logger log = LoggerFactory.getLogger(ReviewController.class);

    @Autowired
    private ReviewService reviewService;

    @PostMapping("/create-review")

    public DataResponse createReview(@RequestBody ReviewDTO reviewDTO) {
        log.debug("Controller Request Create Review");
        DataResponse res = reviewService.createReview(reviewDTO);
        return res;
    }

    @GetMapping("/get-all-reviews-by-product/{id}")
    public DataResponse getAllReviewsByProduct(@PathVariable("id") Long id) {
        log.debug("Controller Request Get All Reviews By Product");
        DataResponse res = reviewService.getAllReviewsByProduct(id);
        return res;
    }

    @GetMapping("/get-all-reviews-by-user")
    public DataResponse getAllReviewsByUser() {
        log.debug("Controller Request Get All Reviews By User");
        DataResponse res = reviewService.getAllReviewsByUser();
        return res;
    }

    @PutMapping("/update-review/{id}")
    public DataResponse updateReview(@PathVariable("id") Long id, @RequestBody ReviewDTO reviewDTO) {
        log.debug("Controller Request Update Review");
        DataResponse res = reviewService.updateReview(id, reviewDTO);
        return res;
    }

    @DeleteMapping("/delete-review/{id}")

    public DataResponse deleteReview(@PathVariable("id") Long id) {
        log.debug("Controller Request Delete Review");
        DataResponse res = reviewService.deleteReview(id);
        return res;
    }

    @GetMapping("/get-all")
    public DataResponse getAll() {
        log.debug("Controller Request Get All");
        DataResponse res = reviewService.getAll();
        return res;
    }
}
