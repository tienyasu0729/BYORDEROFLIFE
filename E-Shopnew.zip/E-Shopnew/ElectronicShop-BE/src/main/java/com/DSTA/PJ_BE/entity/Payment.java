package com.DSTA.PJ_BE.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;

@Entity
@Table(name = "payment")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    @ManyToOne
//    @JoinColumn(name = "order_id")
//    private Order order;

//    @ManyToOne
//    @JoinColumn(name = "user_id")
//    private Account user;

    @Column(name = "payment_type", length = 50)
    private String paymentType;

    @Column(name = "amount", precision = 10, scale = 2)
    private Integer amount;

    @Column(name = "transaction_id", columnDefinition = "VARCHAR(20)", nullable = false, unique = true)
    private String transactionId;

    @Column(name = "orderInfo", columnDefinition = "VARCHAR(20)", nullable = false)
    private String orderInfo;

//    @Column(name = "payment_status", length = 20)
//    private String paymentStatus;

    @Column(name = "created_at")
    private Timestamp createdAt;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

//    public Order getOrder() {
//        return order;
//    }
//
//    public void setOrder(Order order) {
//        this.order = order;
//    }
//
//    public Account getUser() {
//        return user;
//    }
//
//    public void setUser(Account user) {
//        this.user = user;
//    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }
    public String getOrderInfo() {
        return orderInfo;
    }

    // Setter
    public void setOrderInfo(String orderInfo) {
        this.orderInfo = orderInfo;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

//    public String getPaymentStatus() {
//        return paymentStatus;
//    }
//
//    public void setPaymentStatus(String paymentStatus) {
//        this.paymentStatus = paymentStatus;
//    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

}