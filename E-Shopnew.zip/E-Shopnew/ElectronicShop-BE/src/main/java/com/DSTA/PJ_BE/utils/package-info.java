/**
 * common of project
 */
/**
 * @author ACER
 *
 */
package DSTA.Cos.Cosmetics.utils;