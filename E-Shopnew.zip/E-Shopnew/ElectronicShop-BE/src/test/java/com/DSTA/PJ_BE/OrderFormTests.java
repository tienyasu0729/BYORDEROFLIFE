package com.DSTA.PJ_BE;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class OrderFormTests {

    @Test
    public void testValidFullName() {
        String fullName = "John Doe";
        boolean result = validateFullName(fullName);
        assertTrue(result, "The system should accept a valid full name");
    }

    @Test
    public void testEmptyFullName() {
        String fullName = "";
        boolean result = validateFullName(fullName);
        assertFalse(result, "The system should not accept an empty full name");
    }

    @Test
    public void testFullNameWithSpecialCharacters() {
        String fullName = "John Doe Jr.";
        boolean result = validateFullName(fullName);
        assertTrue(result, "The system should accept a full name with special characters");
    }

    @Test
    public void testLongFullName() {
        String fullName = "John Jacob Jingleheimer Schmidt";
        boolean result = validateFullName(fullName);
        assertTrue(result, "The system should accept a very long full name");
    }

    @Test
    public void testValidPhoneNumber() {
        String phoneNumber = "123-456-7890";
        boolean result = validatePhoneNumber(phoneNumber);
        assertTrue(result, "The system should accept a valid phone number");
    }

    @Test
    public void testEmptyPhoneNumber() {
        String phoneNumber = "";
        boolean result = validatePhoneNumber(phoneNumber);
        assertFalse(result, "The system should not accept an empty phone number");
    }

    @Test
    public void testInvalidPhoneNumberFormat() {
        String phoneNumber = "12345";
        boolean result = validatePhoneNumber(phoneNumber);
        assertFalse(result, "The system should not accept an invalid phone number format");
    }

    @Test
    public void testValidCity() {
        String city = "Hanoi";
        boolean result = validateCity(city);
        assertTrue(result, "The system should accept a valid city name");
    }

    @Test
    public void testEmptyCity() {
        String city = "";
        boolean result = validateCity(city);
        assertFalse(result, "The system should not accept an empty city name");
    }

    @Test
    public void testValidDistrict() {
        String district = "Hoan Kiem";
        boolean result = validateDistrict(district);
        assertTrue(result, "The system should accept a valid district name");
    }

    @Test
    public void testEmptyDistrict() {
        String district = "";
        boolean result = validateDistrict(district);
        assertFalse(result, "The system should not accept an empty district name");
    }

    @Test
    public void testValidWard() {
        String ward = "Phuc Tan";
        boolean result = validateWard(ward);
        assertTrue(result, "The system should accept a valid ward name");
    }

    @Test
    public void testEmptyWard() {
        String ward = "";
        boolean result = validateWard(ward);
        assertFalse(result, "The system should not accept an empty ward name");
    }

    @Test
    public void testValidAddress() {
        String address = "123 Main St";
        boolean result = validateAddress(address);
        assertTrue(result, "The system should accept a valid address");
    }

    @Test
    public void testEmptyAddress() {
        String address = "";
        boolean result = validateAddress(address);
        assertFalse(result, "The system should not accept an empty address");
    }

    @Test
    public void testAddressWithSpecialCharacters() {
        String address = "123 Main St, Apt #5!";
        boolean result = validateAddress(address);
        assertTrue(result, "The system should accept an address with special characters");
    }

    @Test
    public void testValidOrderNote() {
        String orderNote = "Leave at the front door.";
        boolean result = validateOrderNote(orderNote);
        assertTrue(result, "The system should accept a valid order note");
    }

    @Test
    public void testEmptyOrderNote() {
        String orderNote = "";
        boolean result = validateOrderNote(orderNote);
        assertTrue(result, "The system should accept an empty order note");
    }

    @Test
    public void testNullOrderNote() {
        String orderNote = null;
        boolean result = validateOrderNote(orderNote);
        assertTrue(result, "The system should accept a null order note");
    }

    private boolean validateFullName(String fullName) {
        return fullName != null && !fullName.trim().isEmpty();
    }

    private boolean validatePhoneNumber(String phoneNumber) {
        return phoneNumber != null && phoneNumber.matches("^\\d{3}-\\d{3}-\\d{4}$");
    }

    private boolean validateCity(String city) {
        return city != null && !city.trim().isEmpty();
    }

    private boolean validateDistrict(String district) {
        return district != null && !district.trim().isEmpty();
    }

    private boolean validateWard(String ward) {
        return ward != null && !ward.trim().isEmpty();
    }

    private boolean validateAddress(String address) {
        return address != null && !address.trim().isEmpty();
    }

    private boolean validateOrderNote(String orderNote) {
        return true; // Any order note, including null, is considered valid.
    }
}
