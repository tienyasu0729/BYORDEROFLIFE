package com.DSTA.PJ_BE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PjBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
