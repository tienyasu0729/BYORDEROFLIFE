package com.DSTA.PJ_BE;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class UserProfileFormTests {

    @Test
    public void testValidFullName() {
        String fullName = "Hai Quyen";
        boolean result = validateFullName(fullName);
        assertTrue(result, "The system should accept a valid full name");
    }

    @Test
    public void testEmptyFullName() {
        String fullName = "";
        boolean result = validateFullName(fullName);
        assertFalse(result, "The system should not accept an empty full name");
    }

    @Test
    public void testValidGenderSelection() {
        String gender = "Female";
        boolean result = validateGender(gender);
        assertTrue(result, "The system should accept a valid gender selection");
    }

    @Test
    public void testValidDateOfBirth() {
        String dob = "01/01/1990";
        boolean result = validateDateOfBirth(dob);
        assertTrue(result, "The system should accept a valid date of birth");
    }

    @Test
    public void testInvalidDateOfBirthFormat() {
        String dob = "1990/01/01";
        boolean result = validateDateOfBirth(dob);
        assertFalse(result, "The system should not accept an invalid date of birth format");
    }

    @Test
    public void testEmptyDateOfBirth() {
        String dob = "";
        boolean result = validateDateOfBirth(dob);
        assertFalse(result, "The system should not accept an empty date of birth");
    }

    @Test
    public void testValidPhoneNumber() {
        String phone = "0326558386";
        boolean result = validatePhone(phone);
        assertTrue(result, "The system should accept a valid phone number");
    }

    @Test
    public void testInvalidPhoneNumberFormat() {
        String phone = "12345";
        boolean result = validatePhone(phone);
        assertFalse(result, "The system should not accept an invalid phone number format");
    }

    @Test
    public void testEmptyPhoneNumber() {
        String phone = "";
        boolean result = validatePhone(phone);
        assertFalse(result, "The system should not accept an empty phone number");
    }

    @Test
    public void testValidAddress() {
        String address = "Con Cuông Nghệ An";
        boolean result = validateAddress(address);
        assertTrue(result, "The system should accept a valid address");
    }

    @Test
    public void testEmptyAddress() {
        String address = "";
        boolean result = validateAddress(address);
        assertFalse(result, "The system should not accept an empty address");
    }

    private boolean validateFullName(String fullName) {
        return fullName != null && !fullName.trim().isEmpty();
    }

    private boolean validateGender(String gender) {
        return gender != null && (gender.equals("Male") || gender.equals("Female") || gender.equals("Other"));
    }

    private boolean validateDateOfBirth(String dob) {
        // Basic format check: dd/MM/yyyy
        return dob != null && dob.matches("^\\d{2}/\\d{2}/\\d{4}$");
    }

    private boolean validatePhone(String phone) {
        return phone != null && phone.matches("^\\d{10}$");
    }

    private boolean validateAddress(String address) {
        return address != null && !address.trim().isEmpty();
    }
}
