package com.DSTA.PJ_BE;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class LoginTests {

    @Test
    public void testValidLogin() {
        String username = "Admin@gmail.com";
        String password = "admin123";
        boolean result = login(username, password);
        assertTrue(result, "The user should be able to login with valid credentials");
        System.out.println("testValidLogin passed: The user was able to login with valid credentials.");
    }

    @Test
    public void testInvalidLogin() {
        String username = "Admin@gmail.com";
        String password = "invalidPass";
        boolean result = login(username, password);
        assertFalse(result, "The user should not be able to login with invalid credentials");
        System.out.println("testInvalidLogin passed: The user was not able to login with invalid credentials.");
    }

    @Test
    public void testInvalidUsername() {
        String username = "InvalidUser@gmail.com";
        String password = "admin123";
        boolean result = login(username, password);
        assertFalse(result, "The user should not be able to login with an invalid username");
        System.out.println("testInvalidUsername passed: The user was not able to login with an invalid username.");
    }

    @Test
    public void testInvalidPassword() {
        String username = "Admin@gmail.com";
        String password = "invalidPass";
        boolean result = login(username, password);
        assertFalse(result, "The user should not be able to login with an invalid password");
        System.out.println("testInvalidPassword passed: The user was not able to login with an invalid password.");
    }

    @Test
    public void testNullUsername() {
        String username = null;
        String password = "admin123";
        boolean result = login(username, password);
        assertFalse(result, "The user should not be able to login with a null username");
        System.out.println("testNullUsername passed: The user was not able to login with a null username.");
    }

    @Test
    public void testNullPassword() {
        String username = "Admin@gmail.com";
        String password = null;
        boolean result = login(username, password);
        assertFalse(result, "The user should not be able to login with a null password");
        System.out.println("testNullPassword passed: The user was not able to login with a null password.");
    }

    @Test
    public void testEmptyUsername() {
        String username = "";
        String password = "admin123";
        boolean result = login(username, password);
        assertFalse(result, "The user should not be able to login with an empty username");
        System.out.println("testEmptyUsername passed: The user was not able to login with an empty username.");
    }

    @Test
    public void testEmptyPassword() {
        String username = "Admin@gmail.com";
        String password = "";
        boolean result = login(username, password);
        assertFalse(result, "The user should not be able to login with an empty password");
        System.out.println("testEmptyPassword passed: The user was not able to login with an empty password.");
    }

    @Test
    public void testUsernameCaseSensitivity() {
        String username = "admin@gmail.com";
        String password = "admin123";
        boolean result = login(username, password);
        assertFalse(result, "The login should be case sensitive for username");
        System.out.println("testUsernameCaseSensitivity passed: The login was case sensitive for username.");
    }

    @Test
    public void testWhitespaceInUsername() {
        String username = " Admin@gmail.com ";
        String password = "admin123";
        boolean result = login(username.trim(), password);
        assertTrue(result, "The system should trim whitespace from the username and password");
        System.out.println("testWhitespaceInUsername passed: The system trimmed whitespace from the username.");
    }

    @Test
    public void testWhitespaceInPassword() {
        String username = "Admin@gmail.com";
        String password = " admin123 ";
        boolean result = login(username, password.trim());
        assertTrue(result, "The system should trim whitespace from the username and password");
        System.out.println("testWhitespaceInPassword passed: The system trimmed whitespace from the password.");
    }

    private boolean login(String username, String password) {
        if (username == null || password == null) {
            return false;
        }
        if (username.trim().isEmpty() || password.trim().isEmpty()) {
            return false;
        }
        return "Admin@gmail.com".equals(username.trim()) && "admin123".equals(password.trim());
    }
}
