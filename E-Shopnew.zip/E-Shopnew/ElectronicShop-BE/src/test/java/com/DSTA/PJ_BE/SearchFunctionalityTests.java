package com.DSTA.PJ_BE;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SearchFunctionalityTests {

    private List<Product> productList;
    private SearchService searchService;

    @BeforeEach
    void setUp() {
        productList = new ArrayList<>();
        productList.add(new Product(1, "Laptop"));
        productList.add(new Product(2, "Smartphone"));
        productList.add(new Product(3, "Headphones"));
        productList.add(new Product(4, "Laptop Bag"));
        productList.add(new Product(5, "Smartwatch"));

        searchService = new SearchService(productList);
    }

    @Test
    void testSearchWithValidKeyword() {
        String keyword = "Laptop";
        List<Product> results = searchService.search(keyword);
        assertEquals(2, results.size(), "There should be 2 products matching the keyword 'Laptop'");
        System.out.println("testSearchWithValidKeyword passed: There are 2 products matching the keyword 'Laptop'");
    }

    @Test
    void testSearchWithInvalidKeyword() {
        String keyword = "InvalidKeyword";
        List<Product> results = searchService.search(keyword);
        assertTrue(results.isEmpty(), "There should be no products matching the keyword 'InvalidKeyword'");
        System.out.println("testSearchWithInvalidKeyword passed: There are no products matching the keyword 'InvalidKeyword'");
    }

    @Test
    void testSearchWithEmptyKeyword() {
        String keyword = "";
        List<Product> results = searchService.search(keyword);
        assertTrue(results.isEmpty(), "There should be no search results for an empty keyword");
        System.out.println("testSearchWithEmptyKeyword passed: There are no search results for an empty keyword");
    }

    @Test
    void testSearchWithKeywordContainingOnlySpaces() {
        String keyword = "   ";
        List<Product> results = searchService.search(keyword.trim());
        assertTrue(results.isEmpty(), "There should be no search results for a keyword containing only spaces");
        System.out.println("testSearchWithKeywordContainingOnlySpaces passed: There are no search results for a keyword containing only spaces");
    }

    @Test
    void testSearchWithKeywordContainingSpecialCharacters() {
        String keyword = "!@#Laptop$%^";
        List<Product> results = searchService.search(keyword.replaceAll("[^a-zA-Z0-9]", ""));
        assertEquals(2, results.size(), "There should be 2 products matching the keyword 'Laptop' after removing special characters");
        System.out.println("testSearchWithKeywordContainingSpecialCharacters passed: There are 2 products matching the keyword 'Laptop' after removing special characters");
    }

    @Test
    void testSearchWithMultipleMatchingProducts() {
        String keyword = "Smart";
        List<Product> results = searchService.search(keyword);
        assertEquals(2, results.size(), "There should be 2 products matching the keyword 'Smart'");
        System.out.println("testSearchWithMultipleMatchingProducts passed: There are 2 products matching the keyword 'Smart'");
    }

    @Test
    void testSearchWithLongKeyword() {
        String keyword = "VeryLongKeywordThatExceedsNormalLength";
        List<Product> results = searchService.search(keyword);
        assertTrue(results.isEmpty(), "There should be no products matching the long keyword");
        System.out.println("testSearchWithLongKeyword passed: There are no products matching the long keyword");
    }

    @Test
    void testCaseInsensitiveSearch() {
        String keyword1 = "laptop";
        String keyword2 = "LAPTOP";
        List<Product> results1 = searchService.search(keyword1);
        List<Product> results2 = searchService.search(keyword2);
        assertEquals(results1.size(), results2.size(), "Search results should be case insensitive");
        System.out.println("testCaseInsensitiveSearch passed: Search results are case insensitive");
    }

}

// Sample Product class
class Product {
    private int id;
    private String name;

    public Product(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}

// Sample SearchService class
class SearchService {
    private List<Product> products;

    public SearchService(List<Product> products) {
        this.products = products;
    }

    public List<Product> search(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return new ArrayList<>();
        }

        keyword = keyword.trim().toLowerCase();
        List<Product> result = new ArrayList<>();
        for (Product product : products) {
            if (product.getName().toLowerCase().contains(keyword)) {
                result.add(product);
            }
        }
        return result;
    }
}
