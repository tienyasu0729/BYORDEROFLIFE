﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net.M.A005.Excercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            //// Update your comment
            Console.WriteLine("Net.M.A005.Excercise2");

            //// Update your comment
            Console.Write("Enter integer number: ");

            //// Update your comment
            int input = Convert.ToInt32(Console.ReadLine());

            //// Update your comment
            PrintFibonacci(input);

            //// Update your comment
            Console.ReadLine();
        }

        //// Update your comment
        private static void PrintFibonacci(int input)
        {
            //// Your code here
        }
    }
}
