﻿using Microsoft.AspNetCore.SignalR;

namespace Web_.Hubs
{
    public class AppHub:Hub
    {
    }
}
