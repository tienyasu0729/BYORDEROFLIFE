using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web_.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
